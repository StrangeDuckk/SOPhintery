#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 3 | 0 | 0 | 4 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Napisz skrypt, który pobierze dwa argumenty, pierwszym będzie nazwa pakietu języka JAVA, a drugim nazwa klasy i na ich podstawie w odpowiednim miejscu na dysku utworzy prawidłową klasą języka JAVA z odpowiednią klasa publiczną i funkcją main wyświetlająca tekst Hello world."
  echo 
  echo "Write a script that will take two arguments, the first will be the name of the JAVA language package and the second will be the name of the class, and based on them in the appropriate place on disk, create a valid JAVA language class with the corresponding public class and main function displaying the text Hello world."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "W tym przykładzie najpierw stopniowo pokażę rozwiązania, a potem będę je wyjaśniał.\nIn this example, I will first partially show the solutions and then explain them.\n"
}

hint2() {
  printf " 1 ...........\n 2 \n 3 . . .... ... . . .. . .... ....... .. ............ ................ .... .... .. .\n 4 \n 5 .................\n 6 ....................\n 7 \n 8 . .. ............... . .. . .... ........ .... .. ........ . .... ..  .\n 9 . .. .................. . .. . .... ...... .... .. ........ . .... ..  .\n10 \n11 .......... ............... . .. ... ....\n12 ............................\n13 \n14 ..... .. ...... .. .........\n15 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint3() {
  printf " 1 #!/bin/bash\n 2 \n 3 . . .... ... . . .. . .... ....... .. ............ ................ .... .... .. .\n 4 \n 5 .................\n 6 ....................\n 7 \n 8 . .. ............... . .. . .... ........ .... .. ........ . .... ..  .\n 9 . .. .................. . .. . .... ...... .... .. ........ . .... ..  .\n10 \n11 .......... ............... . .. ... ....\n12 ............................\n13 \n14 ..... .. ...... .. .........\n15 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint4() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 .................\n 6 ....................\n 7 \n 8 . .. ............... . .. . .... ........ .... .. ........ . .... ..  .\n 9 . .. .................. . .. . .... ...... .... .. ........ . .... ..  .\n10 \n11 .......... ............... . .. ... ....\n12 ............................\n13 \n14 ..... .. ...... .. .........\n15 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint5() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 . .. ............... . .. . .... ........ .... .. ........ . .... ..  .\n 9 . .. .................. . .. . .... ...... .... .. ........ . .... ..  .\n10 \n11 .......... ............... . .. ... ....\n12 ............................\n13 \n14 ..... .. ...... .. .........\n15 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint6() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 .......... ............... . .. ... ....\n12 ............................\n13 \n14 ..... .. ...... .. .........\n15 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint7() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 ..... .. ...... .. .........\n15 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint8() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 mkdir -p \"\$DIR\" 2> /dev/null\n15 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint9() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 mkdir -p \"\$DIR\" 2> /dev/null\n15 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n16 \n17 echo \"package \$PACKAGE_NAME;\"\n18 echo \"\"\n19 echo \"public class \$JAVA_CLASS_NAME {\"\n20 echo \"\"\n21 echo \"  public static void main(String[]args) {\"\n22 echo \"\"\n23 echo \"    System.out.println(\"Hello world\")\"\n24 echo \"\"\n25 echo \"  }\"\n26 echo \"\"\n27 echo \"}\"\n"
}

hint10() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 mkdir -p \"\$DIR\" 2> /dev/null\n15 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n16 \n17 echo \"package \$PACKAGE_NAME;\" > \"\$DIR/\$FILE\"\n18 echo \"\" >> \"\$DIR/\$FILE\"\n19 echo \"public class \$JAVA_CLASS_NAME {\" >> \"\$DIR/\$FILE\"\n20 echo \"\" >> \"\$DIR/\$FILE\"\n21 echo \"  public static void main(String[]args) {\" >> \"\$DIR/\$FILE\"\n22 echo \"\" >> \"\$DIR/\$FILE\"\n23 echo \"    System.out.println(\"Hello world\")\" >> \"\$DIR/\$FILE\"\n24 echo \"\" >> \"\$DIR/\$FILE\"\n25 echo \"  }\" >> \"\$DIR/\$FILE\"\n26 echo \"\" >> \"\$DIR/\$FILE\"\n27 echo \"}\" >> \"\$DIR/\$FILE\"\n"
}

hint11() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 mkdir -p \"\$DIR\" 2> /dev/null\n15 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n16 \n17 (\n18 echo \"package \$PACKAGE_NAME;\"\n19 echo\n20 echo \"public class \$JAVA_CLASS_NAME {\"\n21 echo\n22 echo \"  public static void main(String[]args) {\"\n23 echo\n24 echo \"    System.out.println(\"Hello world\")\"\n25 echo\n26 echo \"  }\"\n27 echo\n28 echo \"}\"\n29 ) > \"\$DIR/\$FILE\"\n"
}

hint12() {
  printf "Znamy już rozwiązanie, możemy je uruchomić, przetestować, a teraz je wytłumaczę.\nWe already know the solution, we can run it, test it, and now I will explain it.\n"
}

hint13() {
  printf " 1 #!/bin/bash\n 2 \n 3 . . .... ... . . .. . .... ....... .. ............ ................ .... .... .. .\n 4 \n 5 .................\n 6 ....................\n 7 \n 8 . .. ............... . .. . .... ........ .... .. ........ . .... ..  .\n 9 . .. .................. . .. . .... ...... .... .. ........ . .... ..  .\n10 \n11 .......... ............... . .. ... ....\n12 ............................\n13 \n14 ..... .. ...... .. .........\n15 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint14() {
  printf "Pierwsza linia nie wymaga już chyba wyjaśnienia.\nThe first line probably needs no further explanation.\n"
}

hint15() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 .................\n 6 ....................\n 7 \n 8 . .. ............... . .. . .... ........ .... .. ........ . .... ..  .\n 9 . .. .................. . .. . .... ...... .... .. ........ . .... ..  .\n10 \n11 .......... ............... . .. ... ....\n12 ............................\n13 \n14 ..... .. ...... .. .........\n15 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint16() {
  printf "W trzeciej linii sprawdzamy, czy zostały podane dwa argumenty (\$# - liczba argumentów, ! - zaprzeczenie). Jeżeli nie mamy dwóch argumentów to na standardowym wyjściu diagnostycznym wyświetlamy informację, o tym jak uruchomić nasz skrypt, i kończymy skrypt z kodem błędu 1.\nIn the third line we check if two arguments are given (\$# - number of arguments, ! - negation). If we do not have two arguments, we display information on the standard diagnostic output, how to run our script, and end the script with the error code 1.\n"
}

hint17() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 . .. ............... . .. . .... ........ .... .. ........ . .... ..  .\n 9 . .. .................. . .. . .... ...... .... .. ........ . .... ..  .\n10 \n11 .......... ............... . .. ... ....\n12 ............................\n13 \n14 ..... .. ...... .. .........\n15 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint18() {
  printf "W piątej i szóstej linii przepisujemy nasze argumenty wejściowe znajdujące się w zmiennych \$1 i \$2  do zmiennych mających bardziej opisowe nazwy.\nIn the fifth and sixth lines, we rewrite our input arguments found in variables \$1 and \$2 to variables that have more descriptive names.\n"
}

hint19() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 .......... ............... . .. ... ....\n12 ............................\n13 \n14 ..... .. ...... .. .........\n15 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint20() {
  printf "W siódmej i ósmej linii sprawdzamy, nazwa pakietu i nazwa klasy nie jest prypadkiem pusta. Raczej nie będą puste bo wcześniej sprawdziliśmty czy te argumenty istnieją. A może zaproponujesz jakieś inne sensowne sprawdzenie w tym miejscu.\nIn the seventh and eighth lines we check, the package name and the class name are not empty by chance. Rather, they won't be empty because we checked beforehand if these arguments exist. Or maybe you can suggest some other sensible check here.\n"
}

hint21() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 ..... .. ...... .. .........\n15 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint22() {
  printf "W kolejnych dwóch liniach przekształcamy nazwę pakietu i nazwę klasy, tak aby dało się utworzyć odpowiedni katalog, a w nim plik o odpowiedniej nazwie.\nIn the next two lines, we transform the name of the package and the name of the class, so that we can create the appropriate directory, and in it a file with the appropriate name.\n"
}

hint23() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 mkdir -p \"\$DIR\" 2> /dev/null\n15 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n16 \n17 .... ........ ...............\n18 .... ..\n19 .... ....... ..... ................ ..\n20 .... ..\n21 .... .  ...... ...... .... .................. ..\n22 .... ..\n23 .... .    .......................... .........\n24 .... ..\n25 .... .  ..\n26 .... ..\n27 .... ...\n"
}

hint24() {
  printf "Teraz dowiemy się, czy nazwa pakietu przekształcona na ścieżkę może zostać wykorzystana do utworzenia katalogów. Jeżeli funkcja mkdir zwróci błąd, wyświetlony zostanie komunikat o błędzie i skrypt zakończy się z kodem błędu 7.\nNow we will find out whether the package name converted to a path can be used to create directories. If the mkdir function returns an error, an error message will be displayed and the script will end with error code 7.\n"
}

hint25() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 mkdir -p \"\$DIR\" 2> /dev/null\n15 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n16 \n17 echo \"package \$PACKAGE_NAME;\"\n18 echo \"\"\n19 echo \"public class \$JAVA_CLASS_NAME {\"\n20 echo \"\"\n21 echo \"  public static void main(String[]args) {\"\n22 echo \"\"\n23 echo \"    System.out.println(\"Hello world\")\"\n24 echo \"\"\n25 echo \"  }\"\n26 echo \"\"\n27 echo \"}\"\n"
}

hint26() {
  printf "Doszliśmy prawie do końca naszego skryptu, mamy sekwencje funkcji echo, która na standardowe wyjście przekaże sformatowaną zawartość pliku java z odpowiednią nazwą pakietu i oczywiście klasy.\nWe have almost reached the end of our script, we have a sequence of echo functions that will pass to the standard output the formatted contents of the java file with the corresponding package name and, of course, the class.\n"
}

hint27() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 mkdir -p \"\$DIR\" 2> /dev/null\n15 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n16 \n17 echo \"package \$PACKAGE_NAME;\"\n18 echo \"\"\n19 echo \"public class \$JAVA_CLASS_NAME {\"\n20 echo \"\"\n21 echo \"  public static void main(String[]args) {\"\n22 echo \"\"\n23 echo \"    System.out.println(\"Hello world\")\"\n24 echo \"\"\n25 echo \"  }\"\n26 echo \"\"\n27 echo \"}\"\n"
}

hint28() {
  printf "Jeżeli tak zostawimy nasz skrypt to zawartość, która miała zostać zapisana do pliku, zostanie wyświetlona na konsoli. Chyba że zrobimy coś takiego: \nIf we leave our script like this, the content that was supposed to be written to the file will be displayed on the console. Unless we do something like this: \n"
}

hint29() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 mkdir -p \"\$DIR\" 2> /dev/null\n15 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n16 \n17 echo \"package \$PACKAGE_NAME;\" > \"\$DIR/\$FILE\"\n18 echo \"\" >> \"\$DIR/\$FILE\"\n19 echo \"public class \$JAVA_CLASS_NAME {\" >> \"\$DIR/\$FILE\"\n20 echo \"\" >> \"\$DIR/\$FILE\"\n21 echo \"  public static void main(String[]args) {\" >> \"\$DIR/\$FILE\"\n22 echo \"\" >> \"\$DIR/\$FILE\"\n23 echo \"    System.out.println(\"Hello world\")\" >> \"\$DIR/\$FILE\"\n24 echo \"\" >> \"\$DIR/\$FILE\"\n25 echo \"  }\" >> \"\$DIR/\$FILE\"\n26 echo \"\" >> \"\$DIR/\$FILE\"\n27 echo \"}\" >> \"\$DIR/\$FILE\"\n"
}

hint30() {
  printf "Bardzo dużo tych zmian, łatwo się pomylić, zamienić >> w > i zamiast dopisania do pliku konkretnego tekstu, nadpiszemy plik tym tekstem. Zapiszmy to tak:\nVery many of these changes, it's easy to get confused, turn >> into > and instead of adding specific text to the file, we overwrite the file with this text. Let's write it like this:\n"
}

hint31() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 mkdir -p \"\$DIR\" 2> /dev/null\n15 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n16 \n17 (\n18 echo \"package \$PACKAGE_NAME;\"\n19 echo\n20 echo \"public class \$JAVA_CLASS_NAME {\"\n21 echo\n22 echo \"  public static void main(String[]args) {\"\n23 echo\n24 echo \"    System.out.println(\"Hello world\")\"\n25 echo\n26 echo \"  }\"\n27 echo\n28 echo \"}\"\n29 ) > \"\$DIR/\$FILE\"\n"
}

hint32() {
  printf "Aby zrozumieć sens wywołania poleceń w nawiasach (), posłużmy się poleceniem pstree.\nTo understand the meaning of the command call in parentheses (), let's use the pstree command.\n"
}

hint33() {
  printf " 1 asmyk@msh:~/H/Test\$ pstree -acp\n 2 ?,1\n 3  └─?,2421\n 4     └─sshd,2430\n 5         └─shell,2431\n 6             └─pstree,9903 -acp\n 7 ................... ...... .... . ...... .... . ...... ....\n 8 ...\n 9  ........\n10     ...........\n11         ............\n12             ............. ....\n13 ...\n14  ........\n15     ...........\n16         ............\n17             ............. ....\n18 ...\n19  ........\n20     ...........\n21         ............\n22             ............. ....\n23 ................... ....... .... . ...... .... . ...... .... .\n24 ...\n25  ........\n26     ...........\n27         ............\n28             ............\n29                 ............. ....\n30 ...\n31  ........\n32     ...........\n33         ............\n34             ............\n35                 ............. ....\n36 ...\n37  ........\n38     ...........\n39         ............\n40             ............\n41                 ............. ....\n42 ...................\n"
}

hint34() {
  printf "To co widzimy, to drzewo procesów. Zwróć uwagę na to ile tam jest procesów o nazwie shell.\nWhat we see is the process tree. Notice how many shell-named processes there are.\n"
}

hint35() {
  printf "Rozmnóżmy je trochę: \nLet's multiply them a bit:\n"
}

hint36() {
  printf " 1 asmyk@msh:~/H/Test\$ pstree -acp\n 2 ?,1\n 3  └─?,2421\n 4     └─sshd,2430\n 5         └─shell,2431\n 6             └─pstree,9903 -acp\n 7 asmyk@msh:~/H/Test\$ pstree -acp ; pstree -acp ; pstree -acp\n 8 ?,1\n 9  └─?,2421\n10     └─sshd,2430\n11         └─shell,2431\n12             └─pstree,9907 -acp\n13 ?,1\n14  └─?,2421\n15     └─sshd,2430\n16         └─shell,2431\n17             └─pstree,9908 -acp\n18 ?,1\n19  └─?,2421\n20     └─sshd,2430\n21         └─shell,2431\n22             └─pstree,9909 -acp\n23 ................... ....... .... . ...... .... . ...... .... .\n24 ...\n25  ........\n26     ...........\n27         ............\n28             ............\n29                 ............. ....\n30 ...\n31  ........\n32     ...........\n33         ............\n34             ............\n35                 ............. ....\n36 ...\n37  ........\n38     ...........\n39         ............\n40             ............\n41                 ............. ....\n42 ...................\n"
}

hint37() {
  printf "A ile tam jest procesów shell? \nAnd how many shell processes are there?\n"
}

hint38() {
  printf "Wywołajmy ten sam ciąg poleceń w nawiasch.\nLet's call the same command string in parentheses.\n"
}

hint39() {
  printf " 1 asmyk@msh:~/H/Test\$ pstree -acp\n 2 ?,1\n 3  └─?,2421\n 4     └─sshd,2430\n 5         └─shell,2431\n 6             └─pstree,9903 -acp\n 7 asmyk@msh:~/H/Test\$ pstree -acp ; pstree -acp ; pstree -acp\n 8 ?,1\n 9  └─?,2421\n10     └─sshd,2430\n11         └─shell,2431\n12             └─pstree,9907 -acp\n13 ?,1\n14  └─?,2421\n15     └─sshd,2430\n16         └─shell,2431\n17             └─pstree,9908 -acp\n18 ?,1\n19  └─?,2421\n20     └─sshd,2430\n21         └─shell,2431\n22             └─pstree,9909 -acp\n23 asmyk@msh:~/H/Test\$ (pstree -acp ; pstree -acp ; pstree -acp )\n24 ?,1\n25  └─?,2421\n26     └─sshd,2430\n27         └─shell,2431\n28             └─shell,9918\n29                 └─pstree,9919 -acp\n30 ?,1\n31  └─?,2421\n32     └─sshd,2430\n33         └─shell,2431\n34             └─shell,9918\n35                 └─pstree,9920 -acp\n36 ?,1\n37  └─?,2421\n38     └─sshd,2430\n39         └─shell,2431\n40             └─shell,9918\n41                 └─pstree,9921 -acp\n42 asmyk@msh:~/H/Test\$\n"
}

hint40() {
  printf "I na koniec jeszcze raz nasze rozwiązanie.\nAnd finally, once again our solution.\n"
}

solution() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 PACKAGE_NAME=\"\$1\"\n 6 JAVA_CLASS_NAME=\"\$2\"\n 7 \n 8 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n 9 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n10 \n11 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n12 FILE=\"\$JAVA_CLASS_NAME.java\"\n13 \n14 mkdir -p \"\$DIR\" 2> /dev/null\n15 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n16 \n17 (\n18 echo \"package \$PACKAGE_NAME;\"\n19 echo\n20 echo \"public class \$JAVA_CLASS_NAME {\"\n21 echo\n22 echo \"  public static void main(String[]args) {\"\n23 echo\n24 echo \"    System.out.println(\"Hello world\")\"\n25 echo\n26 echo \"  }\"\n27 echo\n28 echo \"}\"\n29 ) > \"\$DIR/\$FILE\"\n"
}



homework1() {
  printf "Praca domowa numer #3004_1: Dodaj do naszego generatora możliwość generowania komentarza, kto, kiedy i w jakim celu ten program wygenerował.\nHomework #3004_1: Add to our generator the ability to generate a comment on who generated this program, when and for what purpose.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'hint30' 'hint31' 'hint32' 'hint33' 'hint34' 'hint35' 'hint36' 'hint37' 'hint38' 'hint39' 'hint40' 'solution' 'homework1' 

exit 0