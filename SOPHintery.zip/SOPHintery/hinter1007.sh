#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 1 | 0 | 0 | 7 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Do katalogu /tmp/numerIndeksu skopiuj 4 najmniejsze pliki z katalogu /usr/bin, które nie są łączami symbolicznymi, a następnie zmień ich nazwy odpowiednio na p1, p2, p3 i p4"
  echo 
  echo "To the /tmp/numberIndex directory, copy the 4 smallest files from the /usr/bin directory that are not symbolic links, and rename them p1, p2, p3 and p4, respectively"
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Na początku wyświetlmy katalog /usr/bin\nFirst, let's display the /usr/bin directory\n"
}

hint2() {
  printf "ls /usr/bin\n"
}

hint3() {
  printf "Mamy tu zainstalowane aplikacje, które wykorzystujemy w systemie\nHere we have installed applications that we use in the system\n"
}

hint4() {
  printf "Teraz, zajrzyj do podręcznika, aby dowiedzieć się jak posortować pliki od największego do najmniejszego (lub odwrotnie).\nTake a look at the manual to learn how to sort files by length.\n"
}

hint5() {
  printf "man ls\n"
}

hint6() {
  printf "Jak będziesz w podręczniku, wpisz /sort by file size - W ten sposób otrzymasz informację o potrzebnej opcji\nOnce you're in the manual, type /sort by file size - This will give you information about the option you need\n"
}

hint7() {
  printf "Użyjemy dwóch -S aby posortować po rozmiarza, -l aby temu uwierzyć i czasami przydatna opcja -r, aby odwrócić wyniki\nWe'll use two -S to sort by size, -l to believe it, and the sometimes useful -r option to reverse the results\n"
}

hint8() {
  printf "ls -Sr\n"
}

hint9() {
  printf "Dodajmy opcję -l\nAdd the -l option\n"
}

hint10() {
  printf "ls -Srl\n"
}

hint11() {
  printf "Ręcznie odnajdujemy nasze najmniejsze pliki - omijamy łącza symboliczne, które łatwo jest rozpoznać po nazeiw lub po atrybucie l jak link\nWe manually find our smallest files - we omit symbolic links, which are easy to identify by their names or by the l attribute like link\n"
}

hint12() {
  printf "W przypadku komputera msh,  pliki które będą kopiował maja nazwy odpowiedni: rgrep docbook2ps docbook2txt docbook2tex, a informację o tych plikach możemy uzyskać poprzez wywołanie potokowe 3 poleceń:\nIn the case of the msh computer, the files it will copy have names respectively: rgrep docbook2ps docbook2txt docbook2tex, and we can get the information about these files by calling pipelines of 3 commands\n"
}

hint13() {
  printf "ls -Sl | egrep -v ^l | tail -4\n"
}

hint14() {
  printf "Wyświetlmy teraz informacje o katalogu docelowym, aby sprawdzić czy on istnieje i czy mamy prawo zapisu do tego katalogu\nLet's display information concerning the destination directory to see if it exists and if we have the right to write to it\n"
}

hint15() {
  printf "ls -ld /tmp/asmyk\n"
}

hint16() {
  printf "Jeżeli nie ma tego katalogu (oczywiście Państwo sprawdzacie czy isnieje Wasz katalog a nie asmyk), dostaliśmy błąd: ls: cannot access /tmp/asmyk: No such file or directory to go tworzymy.\nIf there is no such directory (of course you check if there is your directory and not asmyk), we get the error: ls: cannot access /tmp/asmyk: No such file or directory then we create it.\n"
}

hint17() {
  printf "mkdir /tmp/asmyk\n"
}

hint18() {
  printf "Kopiujemy pliki: rgrep docbook2ps docbook2txt docbook2tex.\nCopy files: rgrep docbook2ps docbook2txt docbook2texy.\n"
}

hint19() {
  printf "cp /usr/bin/{rgrep,docbook2ps,docbook2txt,docbook2tex} /tmp/asmyk\n"
}

hint20() {
  printf "Lub inaczej kopiujemy pliki: rgrep docbook2ps docbook2txt docbook2tex.\nIn another way we copy files: rgrep docbook2ps docbook2txt docbook2texy.\n"
}

hint21() {
  printf "cd /usr/bin/ ; cp {rgrep,docbook2ps,docbook2txt,docbook2tex} /tmp/asmyk\n"
}

hint22() {
  printf "Lub jeszcze inaczej kopiujemy pliki: rgrep docbook2ps docbook2txt docbook2tex.\nIn yet another way, we copy the files: rgrep docbook2ps docbook2txt docbook2texy.\n"
}

hint23() {
  printf "cd /tmp/asmyk ; cp /usr/bin/{rgrep,docbook2ps,docbook2txt,docbook2tex} .\n"
}

hint24() {
  printf "Zmieniamy nazwy i to wszystko\nWe change the names and that's all\n"
}

hint25() {
  printf "mv /tmp/asmyk/rgrep /tmp/asmyk/p1\nmv /tmp/asmyk/docbook2ps /tmp/asmyk/p2\nmv /tmp/asmyk/docbook2txt /tmp/asmyk/p3\nmv /tmp/asmyk/docbook2tex /tmp/asmyk/p4\n"
}

solution() {
  printf "cp /usr/bin/{rgrep,docbook2ps,docbook2txt,docbook2tex} /tmp/asmyk\nmv /tmp/asmyk/rgrep /tmp/asmyk/p1\nmv /tmp/asmyk/docbook2ps /tmp/asmyk/p2\nmv /tmp/asmyk/docbook2txt /tmp/asmyk/p3\nmv /tmp/asmyk/docbook2tex /tmp/asmyk/p4\n"
}



homework1() {
  printf "Praca domowa #1007_1: Jak byś skopiował jeden plik do dwóch różnych lokalizacji. Ja mam jakiś pomysł, ale może masz lepszy, chętnie go poznam.\nHomework #1007_1: How would you copy one file to two different locations. I have an idea, but maybe you have a better one, I'd love to know.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'solution' 'homework1' 

exit 0