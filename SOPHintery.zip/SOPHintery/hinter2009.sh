#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 2 | 0 | 0 | 9 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Użytkownik z klawiatury podaje nazwę katalogu, który chcemy skasować. Jeżeli nam się to udało powinniśmy wyświetlić komunikat OK, a jak nie to komunikat NOK."
  echo 
  echo "The user enters the name of the directory we want to delete from the keyboard. If we succeeded, we should display an OK message, and if not, a NOK message."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Zadanie wydaje się dość proste. Ale w dowolny sposób możemy je skomplikować. Tak naprawdę to te zadania to już wstęp do skryptów, ale jeszcze sobie bez nich poradzimy.\nThe task seems quite simple. But in any way we can complicate it. In fact, these tasks are already an introduction to scripts, but we can still manage without them.\n"
}

hint2() {
  printf "Jak zwykle stopniowo bedziemy budować rozwiązanie. Zaczniemy od wpisanie danych z klawiatury.\nAs usual, we will gradually build a solution. We'll start with keyboard input.\n"
}

hint3() {
  printf "read DIRECTORY_NAME\n"
}

hint4() {
  printf "Użytkownik wprowadził dane, wyświetlmy je.\nThe user has entered data, let's display it.\n"
}

hint5() {
  printf "echo \"\$DIRECTORY_NAME\"\n"
}

hint6() {
  printf "Zgrupujmy nasze operacje. Utworzymy coś w rodzaju podprogramu - prostego skryptu.\nLet's group our operations. We will create something like a subroutine - a simple script.\n"
}

hint7() {
  printf "read \$DIRECTORY_NAME ; echo \"\$DIRECTORY_NAME\"\n"
}

hint8() {
  printf "{ read \$DIRECTORY_NAME ; echo \"\$DIRECTORY_NAME\" }\n"
}

hint9() {
  printf "Już wiemy, że aby utworzyć katalog potrzebujemy użyć polecenia mkdir z parametrem lub parametrami przekazanymi jako argumenty.\nWe already know that to create a directory we need to use the mkdir command with a parameter or parameters passed as arguments.\n"
}

hint10() {
  printf "mkdir \"\$DIRECTORY_NAME\"\n"
}

hint11() {
  printf "Spróbujmy przekazać dane z polecenia read do polecenia mkdir.\nLet's try passing data from the read command to the mkdir command.\n"
}

hint12() {
  printf "{ read \$DIRECTORY_NAME ; echo \"\$DIRECTORY_NAME\" } | mkdir \"\$DIRECTORY_NAME\"\n"
}

hint13() {
  printf "Polecenie echo zmieniło zawartość nasze zmiennej \$DIRECTORY_NAME w strumień, który zostanie przekzany do polecenia mkdir.\nThe echo command turned the contents of our \$DIRECTORY_NAME variable into a stream to be redirected to the mkdir command.\n"
}

hint14() {
  printf "Oczywiście to nie zadziałało poprawnie, ponieważ jak wiemy polecenie mkdir przyjmuje swoje parametry jak argumenty, a nie odczytuje ich z klawiatury, czyli w tym momencie ze strumienia.\nOf course, this didn't work correctly, because as we know the mkdir command takes its parameters like arguments, and doesn't read them from the keyboard, that is, from the stream at this point.\n"
}

hint15() {
  printf "Wykorzystajmy znane nam już polecenie xargs, ktre odczytuje dane z klawiatury (w tym przypadku z potoku) i uruchamie wskazane jako argument polecenie z tymi argumentami. Technicznie robi bardzo prostą operację.\nLet's use the already familiar xargs command, which reads data from the keyboard (in this case, from the pipeline) and runs the command indicated as an argument with those arguments. Technically, it does a very simple operation.\n"
}

hint16() {
  printf "{ read \$DIRECTORY_NAME ; echo \"\$DIRECTORY_NAME\" } | xargs mkdir\n"
}

hint17() {
  printf "Zauważcie, że zniknęła nazwa katalogu. Zostanie ona automatycznie wstawiona przez polecenia xargs.\nNotice that the directory name has disappeared. It will be automatically inserted by xargs commands.\n"
}

hint18() {
  printf "W systemach operacyjnych łatwo możemy sprawdzić, czy ostatnio wykonane polecenie zakończyło się błędem, czy nie. Każde polecenie zwraca do systemu wartość liczbową. Jeżeli zróci 0 to uznajemy że zakończyło się sukcesem, a jak wartość inną od zera to że jest błąd (ale nie zawsze musi tak być, zależy to od polecenia więc trzeba czytać instrukcję).\nIn operating systems, we can easily check whether the last command executed ended in an error or not. Each command returns a numerical value to the system. If it returns 0 then we consider it successful, and if a value other than zero then that there is an error (but it doesn't always have to be so, it depends on the command so you have to read the instruction).\n"
}

hint19() {
  printf "Aby to sprawdzić, potrzebowalibyśmy instrukcji if lub czegoś co potrafi sprawdzić co zostało zwrócone przez ostatnie polecenie. Tym czymś są dwa operatory && i ||.\nTo check this, we would need an if statement or something that can check what was returned by the last command. That something is the two operators && and ||.\n"
}

hint20() {
  printf "{ read \$DIRECTORY_NAME ; echo \"\$DIRECTORY_NAME\" } | xargs mkdir && echo \"OK\"\n"
}

hint21() {
  printf "Działa to bardzo prosto, jak polecenie z lewej strony operatora && zakończy się sukcesem, to wykonywane jest polecenie z prawej strony tego operatora.\nIt works very simply, as the command on the left side of the && operator succeeds, the command on the right side of this operator is executed.\n"
}

hint22() {
  printf "{ read \$DIRECTORY_NAME ; echo \"\$DIRECTORY_NAME\" } | xargs mkdir || echo \"NOK\"\n"
}

hint23() {
  printf "To równiez działa bardzo prosto, jak polecenie z lewej strony operatora || zakończy się niepowodzeniem, to wykonywane jest polecenie z prawej strony tego operatora.\nThis also works very simply, as the command to the left of the || operator fails, the command to the right of that operator is executed.\n"
}

hint24() {
  printf "Możemy to połączyć, na zasadzie if...else.\nWe can combine it, something like if...else.\n"
}

hint25() {
  printf "{ read \$DIRECTORY_NAME ; echo \"\$DIRECTORY_NAME\" } | xargs mkdir && echo \"OK\"|| echo \"NOK\"\n"
}

hint26() {
  printf "Zwróć uwagę, że w przypadku wystąpienia błędu, polecenie mkdir wyswietla swój komunikat. Pozbądźmy się go.\nNote that if an error occurs, the mkdir command displays its message. Let's get rid of it.\n"
}

hint27() {
  printf "{ read \$DIRECTORY_NAME ; echo \"\$DIRECTORY_NAME\" } | xargs mkdir 2> /dev/null && echo \"OK\"|| echo \"NOK\"\n"
}

hint28() {
  printf "Można to oczywiście zapisać w osobnych liniach bez potoku.\nThis can, of course, be written on separate lines without a pipeline.\n"
}

hint29() {
  printf "\n\nread \$DIRECTORY_NAME\nmkdir \$DIRECTORY_NAME 2> /dev/null && echo \"OK\"|| echo \"NOK\"\n"
}

solution() {
  printf "{ read \$DIRECTORY_NAME ; echo \"\$DIRECTORY_NAME\" } | xargs mkdir 2> /dev/null && echo \"OK\"|| echo \"NOK\"\n\n\nread \$DIRECTORY_NAME\nmkdir \$DIRECTORY_NAME 2> /dev/null && echo \"OK\"|| echo \"NOK\"\n"
}



homework1() {
  printf "Praca domowa 2009_1: Tak zmodyfikuj ten program, aby usuwał plik, którego nazwa jest podana z klawiatury. Dodatkowo słowa OK lub NOK mają być wyświetlone z użyciem plecenia banner.\nHomework 2009_1: Modify this program so that it deletes the file whose name is given from the keyboard. In addition, the words OK or NOK are to be displayed using the banner command.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'solution' 'homework1' 

exit 0