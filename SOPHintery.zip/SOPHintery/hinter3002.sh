#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 3 | 0 | 0 | 2 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Napisz skrypt, który pobierze z klawiatury tekst w formacie 0:1:1:2:3:5:8:13:21:34. Jak widać jest to ciąg Fibonacciego. Skrypt ma wyznaczyć kolejną liczbę Fibonacciego i dokleić ją na końcu do otrzymanego ciągu (po dwukropku), a wynik wyświetlić na konsoli. Zakładając, że skrypt nazywa się f.sh, chciałbym go uruchomić w następujący sposób: echo \"0:1\" | ./f.sh  | ./f.sh  | ./f.sh | ./f.sh ... "
  echo 
  echo "Write a script that takes from the keyboard the text in the format 0:1:1:2:3:5:8:13:21:34. As you can see, it is a Fibonacci sequence. The script is to determine the next Fibonacci number and glue it at the end to the received string (after the colon), and display the result on the console. Assuming the script is called f.sh, I would like to run it as follows: echo \"0:1\" | ./f.sh  | ./f.sh  | ./f.sh | ./f.sh ... "
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "To będzie bardzo krótkie zadanie. A być może wiesz bez moich podpowiedzi jak to zrobić?\nThis will be a very short task. And perhaps you know without my hints how to do it?\n"
}

hint2() {
  printf "Skoro, jesteś tutaj to znaczy, że jednak potrzebujesz podpowiedzi.\nSince, you are here it means that you need a hint though.\n"
}

hint3() {
  printf "Zaczynamy od początku, czyli: \nWe start from the beginning, that is:\n"
}

hint4() {
  printf "#!/bin/bash\n\n.....\n\nexit 0\n"
}

hint5() {
  printf "Odczytajmy ciąg wejściowy z klawiatury: \nLet's read the input string from the keyboard: \n"
}

hint6() {
  printf "#!/bin/bash\n\nread FIBO\n.....\n\nexit 0\n"
}

hint7() {
  printf "Teraz czas na zabawę z otrzymanym tekstem. Zakładamy, że ciąg ma poprawny format, musimy wyodrębnić z niego dwie ostatnie wartości: \nNow it's time to play with the received text. We assume that the string has the correct format, we need to extract the last two values from it:\n"
}

hint8() {
  printf "Nie wiemy ile mamy znaków, więc nie bardzo wiemy, które wartości mamy wyciąć. Ale jest na to rada. Odwróćmy tekst. \nWe don't know how many characters we have, so we don't really know which values to cut. But there's a tip for that. Let's reverse the text.\n"
}

hint9() {
  printf "#!/bin/bash\n\nread FIBO\necho \"\$FIBO\" | rev.....\n\nexit 0\n"
}

hint10() {
  printf "Dwie ostatnie, potrzebne nam wartości, z końca tekstu są teraz na początku, więc potrzebujemy pierwszej i drugiej z nich:\nThe last two values we need, from the end of the text, are now at the beginning, so we need the first and second of them:\n"
}

hint11() {
  printf "#!/bin/bash\n\nread FIBO\necho \"\$FIBO\" | rev | cut d':' -f1\necho \"\$FIBO\" | rev | cut d':' -f2\n.....\n\nexit 0\n"
}

hint12() {
  printf "Może jeszcze teraz tego nie widzisz, ale skoro odwróciliśmy cały tekst to nasze wartości są również odwrócone (w sensie kolejności cyfr)), musimy odwrócić je raz jeszcze:\nMaybe you don't see it yet now, but since we inverted all the text then our values are also inverted (in the sense of the order of the digits)), we have to invert them again:\n"
}

hint13() {
  printf "#!/bin/bash\n\nread FIBO\necho \"\$FIBO\" | rev | cut d':' -f1 | rev\necho \"\$FIBO\" | rev | cut d':' -f2 | rev\n.....\n\nexit 0\n"
}

hint14() {
  printf "Zapiszmy te uzyskane liczby do zmiennych:\nLet's write these obtained numbers into variables:\n"
}

hint15() {
  printf "#!/bin/bash\n\nread FIBO\nA=\$(echo \"\$FIBO\" | rev | cut d':' -f1 | rev)\nB=\$(echo \"\$FIBO\" | rev | cut d':' -f2 | rev)\n.....\n\nexit 0\n"
}

hint16() {
  printf "Dodajmy A do B:\nLet's add A to B:\n"
}

hint17() {
  printf "#!/bin/bash\n\nread FIBO\nA=\$(echo \"\$FIBO\" | rev | cut d':' -f1 | rev)\nB=\$(echo \"\$FIBO\" | rev | cut d':' -f2 | rev)\nlet C=A+B\n.....\n\nexit 0\n"
}

hint18() {
  printf "Doklejmy otrzymaną wartość do otrzymanego ciągu i wyświetlmy ten ciąg:\nLet's paste the resulting value to the received string and display the string:\n"
}

hint19() {
  printf "#!/bin/bash\n\nread FIBO\nA=\$(echo \"\$FIBO\" | rev | cut d':' -f1 | rev)\nB=\$(echo \"\$FIBO\" | rev | cut d':' -f2 | rev)\nlet C=A+B\necho \"\$FIBO:\$C\"\n\nexit 0\n"
}

hint20() {
  printf "Zauważ, że nie sprawdzamy nigdzie błędów. Tak jest łatwiej się uczyć. Niestety błędy są częścią naszego życia i będziemy musieli nauczyć je obsługiwać.\nNote that we don't check for errors anywhere. It's easier to learn that way. Unfortunately, errors are part of our lives and we will have to learn to handle them.\n"
}

solution() {
  printf "#!/bin/bash\n\nread FIBO\nA=\$(echo \"\$FIBO\" | rev | cut d':' -f1 | rev)\nB=\$(echo \"\$FIBO\" | rev | cut d':' -f2 | rev)\nlet C=A+B\necho \"\$FIBO:\$C\"\n\nexit 0\n"
}



homework1() {
  printf "Praca domowa #3002_1: Zmień nasze rozwiązanie, aby zamiast ciągu Fibonacciego generowany był ciąg arytmetyczny.\nHomework #3002: Change our solution so that an arithmetic sequence is generated instead of the Fibonacci sequence.\n"
}

homework2() {
  printf "Praca domowa #3002_2: Zmień nasze rozwiązanie, aby zamiast ciągu Fibonacciego generowane były kolejne silnie.\nHomework #3002: Change our solution so that an next factorial is generated instead of the Fibonacci sequence.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'solution' 'homework1' 'homework2' 

exit 0