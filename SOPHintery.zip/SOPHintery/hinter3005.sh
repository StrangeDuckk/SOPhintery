#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 3 | 0 | 0 | 5 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Jest to kontynuacja zadania 3004. Umiemy już napisać prosty skrypt, który utworzy plik java w odpowiednim pakiecie. Dodajmy teraz funkcjonalność warunkowego budowania elementów klasy: może ona zawierać (lub nie) funkcję main i może zawierać (lub nie) kod wyświetlający tekst Hello world."
  echo 
  echo "This is a continuation of task 3004. We already know how to write a simple script that will create a java file in the appropriate package. Now let's add the functionality of conditionally building the elements of the class: it may (or may not) contain the main function and it may (or may not) contain code that displays the text Hello world."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Utwórzmy plik konfiguracyjny (gen.conf), z którego nasz skrypt odczyta ustawianie i wykorzysta je do utworzenia klasy.\nLet's create a configuration file (gen.conf), from which our script will read the settings and use them at runtime.\n"
}

hint2() {
  printf "asmyk@msh:~/gen\$ cat gen.conf\nMAIN=TRUE\nHELLO_WORLD=TRUE\n\nasmyk@msh:~/gen\$\n"
}

hint3() {
  printf "Teraz przetworzymy przedstawiony plik konfiguracyjny, a ustawienia w nim zawarte wykorzystamy przy budowie plików źródłowych JAVA. Teraz szybkie przejście przez cały, niedługi proces przetwarzania. Wyjaśnienia później.\nNow we will process the presented configuration file, and use the settings in it to build JAVA source files. Now a quick run-through of the entire, short processing. Explanations later.\n"
}

hint4() {
  printf " 1 #!/bin/bash\n 2 \n 3 ......................\n 4 \n 5 . . .. .............. . .. . . .. .............. . ..\n 6           . .... ....... .... .. ... .......... ... . .... . . .\n 7 \n 8 ........ .............\n 9 ............... ........... .............. . ......... ..\n10                 .... ... .. .... ... .\n11 ................ .................. .............. . .........  ..\n12                 .... ... .. .... ... .\n13 \n14 . ........... . ... . ..\n15                  .... .......... .... ...... .... ........ .\n16 . ........... . ... .. ............ . ... . ..\n17                  .... .......... .... ...... ..... ..... .....\n18 \n19 .\n20 .... ........ ...............\n21 ....\n22 .... ....... ..... ................ ..\n23 ....\n24 .. . ........... . ... . . ....\n25   .... .  ...... ...... .... .................. ..\n26   .. . ............ . ... . .....\n27     ....\n28     .... .    .......................... .........\n29     ....\n30   ..\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint5() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 . . .. .............. . .. . . .. .............. . ..\n 6           . .... ....... .... .. ... .......... ... . .... . . .\n 7 \n 8 ........ .............\n 9 ............... ........... .............. . ......... ..\n10                 .... ... .. .... ... .\n11 ................ .................. .............. . .........  ..\n12                 .... ... .. .... ... .\n13 \n14 . ........... . ... . ..\n15                  .... .......... .... ...... .... ........ .\n16 . ........... . ... .. ............ . ... . ..\n17                  .... .......... .... ...... ..... ..... .....\n18 \n19 .\n20 .... ........ ...............\n21 ....\n22 .... ....... ..... ................ ..\n23 ....\n24 .. . ........... . ... . . ....\n25   .... .  ...... ...... .... .................. ..\n26   .. . ............ . ... . .....\n27     ....\n28     .... .    .......................... .........\n29     ....\n30   ..\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint6() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 ........ .............\n 9 ............... ........... .............. . ......... ..\n10                 .... ... .. .... ... .\n11 ................ .................. .............. . .........  ..\n12                 .... ... .. .... ... .\n13 \n14 . ........... . ... . ..\n15                  .... .......... .... ...... .... ........ .\n16 . ........... . ... .. ............ . ... . ..\n17                  .... .......... .... ...... ..... ..... .....\n18 \n19 .\n20 .... ........ ...............\n21 ....\n22 .... ....... ..... ................ ..\n23 ....\n24 .. . ........... . ... . . ....\n25   .... .  ...... ...... .... .................. ..\n26   .. . ............ . ... . .....\n27     ....\n28     .... .    .......................... .........\n29     ....\n30   ..\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint7() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 #setting configuration\n 9 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null &&\n10                 echo 'T' || echo 'F' )\n11 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  &&\n12                 echo 'T' || echo 'F' )\n13 \n14 . ........... . ... . ..\n15                  .... .......... .... ...... .... ........ .\n16 . ........... . ... .. ............ . ... . ..\n17                  .... .......... .... ...... ..... ..... .....\n18 \n19 .\n20 .... ........ ...............\n21 ....\n22 .... ....... ..... ................ ..\n23 ....\n24 .. . ........... . ... . . ....\n25   .... .  ...... ...... .... .................. ..\n26   .. . ............ . ... . .....\n27     ....\n28     .... .    .......................... .........\n29     ....\n30   ..\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint8() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 #setting configuration\n 9 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null &&\n10                 echo 'T' || echo 'F' )\n11 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  &&\n12                 echo 'T' || echo 'F' )\n13 \n14 [ \"\$GEN_MAIN\" = 'T' ] &&\n15                  echo \"Generator will create main function \"\n16 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] &&\n17                  echo \"Generator will create hello world code\"\n18 \n19 .\n20 .... ........ ...............\n21 ....\n22 .... ....... ..... ................ ..\n23 ....\n24 .. . ........... . ... . . ....\n25   .... .  ...... ...... .... .................. ..\n26   .. . ............ . ... . .....\n27     ....\n28     .... .    .......................... .........\n29     ....\n30   ..\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint9() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 #setting configuration\n 9 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null &&\n10                 echo 'T' || echo 'F' )\n11 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  &&\n12                 echo 'T' || echo 'F' )\n13 \n14 [ \"\$GEN_MAIN\" = 'T' ] &&\n15                  echo \"Generator will create main function \"\n16 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] &&\n17                  echo \"Generator will create hello world code\"\n18 \n19 (\n20 echo \"package \$PACKAGE_NAME;\"\n21 echo\n22 echo \"public class \$JAVA_CLASS_NAME {\"\n23 echo\n24 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n25   echo \"  public static void main(String[]args) {\"\n26   .. . ............ . ... . .....\n27     ....\n28     .... .    .......................... .........\n29     ....\n30   ..\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint10() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 #setting configuration\n 9 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null &&\n10                 echo 'T' || echo 'F' )\n11 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  &&\n12                 echo 'T' || echo 'F' )\n13 \n14 [ \"\$GEN_MAIN\" = 'T' ] &&\n15                  echo \"Generator will create main function \"\n16 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] &&\n17                  echo \"Generator will create hello world code\"\n18 \n19 (\n20 echo \"package \$PACKAGE_NAME;\"\n21 echo\n22 echo \"public class \$JAVA_CLASS_NAME {\"\n23 echo\n24 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n25   echo \"  public static void main(String[]args) {\"\n26   if [ \"\$GEN_HELLO\" = \"T\" ] ;then\n27     echo\n28     echo \"    System.out.println(\"Hello world\")\"\n29     echo\n30   fi\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint11() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 #setting configuration\n 9 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null &&\n10                 echo 'T' || echo 'F' )\n11 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  &&\n12                 echo 'T' || echo 'F' )\n13 \n14 [ \"\$GEN_MAIN\" = 'T' ] &&\n15                  echo \"Generator will create main function \"\n16 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] &&\n17                  echo \"Generator will create hello world code\"\n18 \n19 (\n20 echo \"package \$PACKAGE_NAME;\"\n21 echo\n22 echo \"public class \$JAVA_CLASS_NAME {\"\n23 echo\n24 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n25   echo \"  public static void main(String[]args) {\"\n26   if [ \"\$GEN_HELLO\" = \"T\" ] ;then\n27     echo\n28     echo \"    System.out.println(\"Hello world\")\"\n29     echo\n30   fi\n31   echo \"  }\"\n32 fi\n33 echo\n34 echo \"}\"\n35 ) > \"\$DIR/\$FILE\"\n"
}

hint12() {
  printf "Jak widzicie, nie wygląda to na zbyt skomplikowany proces. No to teraz od poczatku. \nAs you can see, it doesn't look like a very complex process. Well, now from the beginning. \n"
}

hint13() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 . . .. .............. . .. . . .. .............. . ..\n 6           . .... ....... .... .. ... .......... ... . .... . . .\n 7 \n 8 ........ .............\n 9 ............... ........... .............. . ......... ..\n10                 .... ... .. .... ... .\n11 ................ .................. .............. . .........  ..\n12                 .... ... .. .... ... .\n13 \n14 . ........... . ... . ..\n15                  .... .......... .... ...... .... ........ .\n16 . ........... . ... .. ............ . ... . ..\n17                  .... .......... .... ...... ..... ..... .....\n18 \n19 .\n20 .... ........ ...............\n21 ....\n22 .... ....... ..... ................ ..\n23 ....\n24 .. . ........... . ... . . ....\n25   .... .  ...... ...... .... .................. ..\n26   .. . ............ . ... . .....\n27     ....\n28     .... .    .......................... .........\n29     ....\n30   ..\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint14() {
  printf "Tworzymy zmienną, zawierającą nazwę naszego pliku konfiguracyjnego. \nWe create a variable containing the name of our configuration file.\n"
}

hint15() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 ........ .............\n 9 ............... ........... .............. . ......... ..\n10                 .... ... .. .... ... .\n11 ................ .................. .............. . .........  ..\n12                 .... ... .. .... ... .\n13 \n14 . ........... . ... . ..\n15                  .... .......... .... ...... .... ........ .\n16 . ........... . ... .. ............ . ... . ..\n17                  .... .......... .... ...... ..... ..... .....\n18 \n19 .\n20 .... ........ ...............\n21 ....\n22 .... ....... ..... ................ ..\n23 ....\n24 .. . ........... . ... . . ....\n25   .... .  ...... ...... .... .................. ..\n26   .. . ............ . ... . .....\n27     ....\n28     .... .    .......................... .........\n29     ....\n30   ..\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint16() {
  printf "Obowiązkowo sprawdzamy, czy podana nazwa faktycznie odwołuje sie do regularnego pliku i czy mamy prawo odczytu tego pliku. Jeżeli nie ma tego pliku lub nie jest on do odczytu to skrypt wyświetla komunikat i kończy wykonywanie z kodem błędu 2.\nIt is mandatory to check whether the given name actually refers to a regular file and whether we have the right to read this file. If there is no this file or it is not readable then the script displays a message and terminates execution with error code 2.\n"
}

hint17() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 #setting configuration\n 9 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null &&\n10                 echo 'T' || echo 'F' )\n11 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  &&\n12                 echo 'T' || echo 'F' )\n13 \n14 . ........... . ... . ..\n15                  .... .......... .... ...... .... ........ .\n16 . ........... . ... .. ............ . ... . ..\n17                  .... .......... .... ...... ..... ..... .....\n18 \n19 .\n20 .... ........ ...............\n21 ....\n22 .... ....... ..... ................ ..\n23 ....\n24 .. . ........... . ... . . ....\n25   .... .  ...... ...... .... .................. ..\n26   .. . ............ . ... . .....\n27     ....\n28     .... .    .......................... .........\n29     ....\n30   ..\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint18() {
  printf "Okazuje się, że plik konfiguracyjny istnieje, możemy go czytać, więc czytamy. Poleceniem grep staramy się odnaleźć w tym pliku tekst MAIN=TRUE. Jeżeli ten tekst istnieje to zmiennej GEN_MAIN przypisana zostanie wartość T, w przeciwnym przypadku F. Podobnie przetwarzamy zmienną HELLO_WORLD.\nIt turns out that the configuration file exists, we can read it, so we read it. With the grep command we try to find the text MAIN=TRUE in this file. If this text exists then the variable GEN_MAIN will be assigned the value T, otherwise F. Similarly, we process the variable HELLO_WORLD\n"
}

hint19() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 #setting configuration\n 9 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null &&\n10                 echo 'T' || echo 'F' )\n11 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  &&\n12                 echo 'T' || echo 'F' )\n13 \n14 [ \"\$GEN_MAIN\" = 'T' ] &&\n15                  echo \"Generator will create main function \"\n16 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] &&\n17                  echo \"Generator will create hello world code\"\n18 \n19 .\n20 .... ........ ...............\n21 ....\n22 .... ....... ..... ................ ..\n23 ....\n24 .. . ........... . ... . . ....\n25   .... .  ...... ...... .... .................. ..\n26   .. . ............ . ... . .....\n27     ....\n28     .... .    .......................... .........\n29     ....\n30   ..\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint20() {
  printf "Następnie, sprawdzamy, czy dwie wspomniane zmienne mają wartość T i jak tak to skrypt wyświetli odpowiednie komunikaty.\nThen, we check whether the two mentioned variables have a value of T and if so, the script will display the appropriate messages.\n"
}

hint21() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 #setting configuration\n 9 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null &&\n10                 echo 'T' || echo 'F' )\n11 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  &&\n12                 echo 'T' || echo 'F' )\n13 \n14 [ \"\$GEN_MAIN\" = 'T' ] &&\n15                  echo \"Generator will create main function \"\n16 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] &&\n17                  echo \"Generator will create hello world code\"\n18 \n19 (\n20 echo \"package \$PACKAGE_NAME;\"\n21 echo\n22 echo \"public class \$JAVA_CLASS_NAME {\"\n23 echo\n24 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n25   echo \"  public static void main(String[]args) {\"\n26   .. . ............ . ... . .....\n27     ....\n28     .... .    .......................... .........\n29     ....\n30   ..\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint22() {
  printf "Korzystając z instrukcji if sprawdzimy jakie ustawienia ma zmienna GEN_MAIN i albo wygenerujemy funkcję main albo nie.\nUsing the if statement, we will check what setting the GEN_MAIN variable has and either generate the main function or not.\n"
}

hint23() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 #setting configuration\n 9 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null &&\n10                 echo 'T' || echo 'F' )\n11 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  &&\n12                 echo 'T' || echo 'F' )\n13 \n14 [ \"\$GEN_MAIN\" = 'T' ] &&\n15                  echo \"Generator will create main function \"\n16 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] &&\n17                  echo \"Generator will create hello world code\"\n18 \n19 (\n20 echo \"package \$PACKAGE_NAME;\"\n21 echo\n22 echo \"public class \$JAVA_CLASS_NAME {\"\n23 echo\n24 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n25   echo \"  public static void main(String[]args) {\"\n26   if [ \"\$GEN_HELLO\" = \"T\" ] ;then\n27     echo\n28     echo \"    System.out.println(\"Hello world\")\"\n29     echo\n30   fi\n31   .... .  ..\n32 ..\n33 ....\n34 .... ...\n35 . . ............\n"
}

hint24() {
  printf "Podobnie robimy ze zmienną GEN_HELLO i również, albo konkretny test zostanie dodany do pliku wynikowego albo nie.\nWe do the same with the GEN_HELLO variable and also, either a particular test will be added to the result file or not.\n"
}

hint25() {
  printf " 1 #!/bin/bash\n 2 \n 3 CONFIG_FILE=\"gen.conf\"\n 4 \n 5 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] &&\n 6           { echo \"Config file is not available\" >&2 ; exit 2 ; }\n 7 \n 8 #setting configuration\n 9 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null &&\n10                 echo 'T' || echo 'F' )\n11 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  &&\n12                 echo 'T' || echo 'F' )\n13 \n14 [ \"\$GEN_MAIN\" = 'T' ] &&\n15                  echo \"Generator will create main function \"\n16 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] &&\n17                  echo \"Generator will create hello world code\"\n18 \n19 (\n20 echo \"package \$PACKAGE_NAME;\"\n21 echo\n22 echo \"public class \$JAVA_CLASS_NAME {\"\n23 echo\n24 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n25   echo \"  public static void main(String[]args) {\"\n26   if [ \"\$GEN_HELLO\" = \"T\" ] ;then\n27     echo\n28     echo \"    System.out.println(\"Hello world\")\"\n29     echo\n30   fi\n31   echo \"  }\"\n32 fi\n33 echo\n34 echo \"}\"\n35 ) > \"\$DIR/\$FILE\"\n"
}

hint26() {
  printf "No to mamy kompletne rozwiązanie. Zanurzmy to teraz w skrypt napisany w zadaniu 3004. Zrób to samodzielnie bez mojej pomocy. Oczywiście jeżeli jej potrzebujesz, to rozwiązanie jest na następnym hincie.\nWell, we have a complete solution. Now let's dive it into the script written in task 3004. Do it yourself without my help. Of course, if you need it, the solution is on the next hint.\n"
}

hint27() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 CONFIG_FILE=\"gen.conf\"\n 6 PACKAGE_NAME=\"\$1\"\n 7 JAVA_CLASS_NAME=\"\$2\"\n 8 \n 9 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n10 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n11 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] && { echo \"Config file is not available\" >&2 ; exit 2 ; }\n12 \n13 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null && echo 'T' || echo 'F' )\n14 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  && echo 'T' || echo 'F' )\n15 \n16 [ \"\$GEN_MAIN\" = 'T' ] && echo \"Generator will create main fynction \"\n17 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] && echo \"Generator will create hello world code\"\n18 \n19 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n20 FILE=\"\$JAVA_CLASS_NAME.java\"\n21 \n22 mkdir -p \"\$DIR\" 2> /dev/null\n23 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n24 \n25 (\n26 echo \"package \$PACKAGE_NAME;\"\n27 echo\n28 echo \"public class \$JAVA_CLASS_NAME {\"\n29 echo\n30 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n31   echo \"  public static coid main(String[]args) {\"\n32   if [ \"\$GEN_HELLO\" = \"T\" ] ;then\n33     echo\n34     echo \"    System.out.println(\"Hello world\")\"\n35     echo\n36   fi\n37   echo \"  }\"\n38 fi\n39 echo\n40 echo \"}\"\n41 ) > \"\$DIR/\$FILE\"\n"
}

solution() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 CONFIG_FILE=\"gen.conf\"\n 6 PACKAGE_NAME=\"\$1\"\n 7 JAVA_CLASS_NAME=\"\$2\"\n 8 \n 9 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n10 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n11 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] && { echo \"Config file is not available\" >&2 ; exit 2 ; }\n12 \n13 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null && echo 'T' || echo 'F' )\n14 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  && echo 'T' || echo 'F' )\n15 \n16 [ \"\$GEN_MAIN\" = 'T' ] && echo \"Generator will create main fynction \"\n17 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] && echo \"Generator will create hello world code\"\n18 \n19 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n20 FILE=\"\$JAVA_CLASS_NAME.java\"\n21 \n22 mkdir -p \"\$DIR\" 2> /dev/null\n23 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n24 \n25 (\n26 echo \"package \$PACKAGE_NAME;\"\n27 echo\n28 echo \"public class \$JAVA_CLASS_NAME {\"\n29 echo\n30 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n31   echo \"  public static coid main(String[]args) {\"\n32   if [ \"\$GEN_HELLO\" = \"T\" ] ;then\n33     echo\n34     echo \"    System.out.println(\"Hello world\")\"\n35     echo\n36   fi\n37   echo \"  }\"\n38 fi\n39 echo\n40 echo \"}\"\n41 ) > \"\$DIR/\$FILE\"\n"
}



homework1() {
  printf "Praca domowa numer #3005_1: Wzbogać nasz generator o możliwość generowania pól (powiedzmy dla kilku podstawowych typów prostych), getterów i setterów.\nHomework #3005_1: Enrich our generator with the ability to generate fields (say, for a few basic simple types), getters and setters.\n"
}

homework2() {
  printf "Praca domowa numer #3005_2: Wzbogać nasz generator o możliwość generowania metody toString.\nHomework #3005_2: Enrich our generator with the ability to generate the toString method.\n"
}

homework3() {
  printf "Praca domowa numer #3005_3: Wzbogać nasz generator o możliwość generowania kodu wywołującego konstruktor i metodę toString.\nHomework #3005_3: Enrich our generator with the ability to generate code that calls the constructor and the toString method.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'solution' 'homework1' 'homework2' 'homework3' 

exit 0