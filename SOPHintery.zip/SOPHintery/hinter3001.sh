#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 3 | 0 | 0 | 1 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Napisz skrpt, który wyświetli ile mamy ścieżek w zmienne systemowej PATH."
  echo 
  echo "Write a script that displays how many paths we have in the PATH system variable."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Zaczynamy pisać skrypty, czyli proste tekstowe aplikacje, które często są wykorzytywane do różnych celów.\nWe are starting to write scripts, which are simple text applications that are often used for various purposes.\n"
}

hint2() {
  printf "Wykorzystajmy dowolny edytor tekstowy (pico, nano, vi, vim...) i utwórzmy plik script.sh.\nLet's use any text editor (pico, nano, vi, vim...) and create a pllik script.sh.\n"
}

hint3() {
  printf "pico script.sh\n"
}

hint4() {
  printf "Wpiszmy następujący tekst do tego pliku:\nLet's type the following text into this file:\n"
}

hint5() {
  printf "#!/bin/bash\n\necho \"Hello\"\n\nexit 0\n"
}

hint6() {
  printf "Wyjdźmy z edytora [CTRL+X] zapisując nasze zmiany.\nLet's exit the editor [CTRL+X] by saving our changes.\n"
}

hint7() {
  printf "Możemy teraz uruchomić nasz skrypt.\nWe can now run our script.\n"
}

hint8() {
  printf "ala@dziab: ~ bash script.sh\n"
}

hint9() {
  printf "Zobaczymy po prostu napis Hello.\nWe will simply see the text Hello.\n"
}

hint10() {
  printf "Ustawmy uprawnienia do wykonywania dla naszego pliku (poprzednio nie potrzebowaliśmy tego robić, po prostu do uruchomienia wykorzystaliśmy komendę bash).\nLet's set execution permissions for our file (previously we didn't need to do this, we simply used the bash command to run).\n"
}

hint11() {
  printf "ala@dziab: ~ chmod +x script.sh\n"
}

hint12() {
  printf "Możemy teraz uruchomić nasz skrypt, ale inaczej.\nWe can now run our script, but in a different way.\n"
}

hint13() {
  printf "ala@dziab: ~ ./script.sh\n"
}

hint14() {
  printf "Działa, ale ale .... czy wszystko jest jasne i oczywiste?\nIt works, but but .... is everything clear and obvious?\n"
}

hint15() {
  printf "Czemu napisałem ./script.sh, a nie po prostu script.sh.\nWhy did I write ./script.sh and not simply script.sh.\n"
}

hint16() {
  printf "Bardzo pomocne tutaj są zmienne systemowe, które dają możliwość skonfigurowania aplikacji i poleceń systemowych. Wyświetlmy je.\nVery helpful here are system variables, which give you the ability to configure applications and system commands. Let's display them.\n"
}

hint17() {
  printf "set | less\n"
}

hint18() {
  printf "Jest ich bardzo dużo, a my dzisiaj zajmiemy się jedną z nich, a mianowicie zmienną PATH.\nThere are a lot of them, and today we will deal with one of them, namely the PATH variable.\n"
}

hint19() {
  printf "echo \"\$PATH\"\n"
}

hint20() {
  printf "Jest ona wykorzystywane w większości systemów operacyjnych. Jak widzimy, składa się ona z katalogów oddzielonych dwukropkiem.\nIt is used in most operating systems. As we can see, it consists of directories separated by a colon.\n"
}

hint21() {
  printf "Do uruchomienia dowolnego polecenia (aplikacji) system operacyjny potrzebuje dwóch rzeczy: nazwy tej aplikacji i ścieżki jak do niej dotrzeć.\nIn order to run any command (application), the operating system needs two things: the name of that application and the path how to get to it.\n"
}

hint22() {
  printf "Jak napisałem ./script.sh, to mam i jedno i drugie. Nazwa aplikacji to script.sh a ścieżka to ./, czyli katalog bieżący.\nAs I wrote ./script.sh, I have both. The application name is script.sh and the path is ./, which is the current directory.\n"
}

hint23() {
  printf "Jak napisałem script.sh, to mam tylko nazwę aplikacji czyli script.sh ale brakuje mi ścieżki. Co więc dzieje się w systemie w takim przypadku?\nAs I wrote script.sh, I only have the name of the application that is script.sh but the path is missing. So what happens in the system in such a case?\n"
}

hint24() {
  printf "System, wykorzystuje zmienną PATH i stara się odnaleźć plik o wpisanej nazwie we wpisanych tam katalogach. Jak mu się to uda, to wykorzystuje znalezioną ścieżką do uruchomienia komendy, polecenia, aplikacji, a jak nie to zwraca komunikat, że taka nazwa jest niepoprawne.\nThe system, uses the PATH variable and tries to find a file with the entered name in the directories entered there. If it succeeds, it uses the found path to run a command, command, application, and if not, it returns a message that such a name is invalid.\n"
}

hint25() {
  printf "Bardzo dużo teorii dzisiaj, ale warto to wiedzieć, już kończymy. Policzmy ściezki. Ale musiałem wytłumaczyć po co one właściwie są.\nVery much theory today, but it's worth knowing, we're about to finish. Let's count the paths. But I had to explain what they are actually for.\n"
}

hint26() {
  printf "Wyświetlmy ponownie te ścieżki ....\nLet's display these paths again ....\n"
}

hint27() {
  printf "echo \"\$PATH\"\n"
}

hint28() {
  printf "Zamieńmy dwukropek w enter.\nLet's turn a colon into an enter.\n"
}

hint29() {
  printf "echo \"\$PATH\" | tr ':' '\\\n'\n"
}

hint30() {
  printf "Policzmy znaki końca linii.\nLet's count the end-of-line characters.\n"
}

hint31() {
  printf "echo \"\$PATH\" | tr ':' '\\\n' | wc -l\n"
}

hint32() {
  printf "Wstawmy to polecenie do naszego skryptu.\nLet's insert this command into our script.\n"
}

hint33() {
  printf "#!/bin/bash\n\necho \"\$PATH\" | tr ':' '\\\n' | wc -l\n\nexit 0\n"
}

solution() {
  printf "#!/bin/bash\n\necho \"\$PATH\" | tr ':' '\\\n' | wc -l\n\nexit 0\n"
}



homework1() {
  printf "Praca domowa #3001_1: Napisz skrypt, który pobierze od użytkownika ścieżkę, a nasz skrypt doda to do zmiennej systemowej PATH i wyświetli tak zmodyfikowaną zmienną PATH.\nHomework #3001_1: Write a script that takes a path from the user, and our script will add this to the PATH system variable and display the PATH variable so modified.\n"
}

homework2() {
  printf "Praca domowa #3001_2: Ta praca domowa, jest dokładnie taka sama jak #30031_1, ale z tą różnicą, że zmienna PATH ma istotnie zmieniać swoją wartość w systemie. Uwaga, nie tylko ma być ta zmiana widoczna w czasie działania skryptu, ale również po jego zakończeniu. \nHomework #3001_2: This homework, is exactly the same as #30031_1, but with the difference that the PATH variable is to significantly change its value on the system. Note, not only is this change to be visible while the script is running, but also after the script is finished.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'hint30' 'hint31' 'hint32' 'hint33' 'solution' 'homework1' 'homework2' 

exit 0