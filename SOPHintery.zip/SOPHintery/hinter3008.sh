#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 3 | 0 | 0 | 8 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Zapewne znasz polecenie mv - służy ono do zmiany nazwy plików lub przenoszenia ich między katalogami. Zaimplementuj własną wersję tego polecenia. Ma ono oczywiście dotyczyć naszych plików java, a jego zadaniem ma być zarówno przeniesienie pliku z katalogu do katalogu, jak również zmiana nazwy pakietu wewnątrz pliku."
  echo 
  echo "You probably know the mv command - it is used to rename files or move them between directories. Implement your own version of this command. It is, of course, supposed to apply to our java files, and it is supposed to both move a file from directory to directory, as well as rename a package name within a file."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Kolejna modyfikacja naszego ciągu zadań. Uczulam, że jest to rozwiązanie uproszczone, które nie obsługuje wielu wyjątków, komentarzy, literałów tekstowych itd... Pokazuje za to jak zaimplementować obsługę takich problemów.\nAnother modification of our sequence of tasks. I am sensitizing that this is a simplified solution that does not handle many exceptions, comments, text literals, etc.... Instead, it shows how to implement handling such problems.\n"
}

hint2() {
  printf "Rozwiązanie będzie pełne testów, sprawdzeń, walidacji, które będzie można w dowolny sposób zmieniać i rozszerzać.\nThe solution will be full of tests, checks, validations that can be changed and extended in any way.\n"
}

hint3() {
  printf "Na początku, szybka ścieżka prowadząca do rozwiązania, a później tłumaczenie, co robię i dlaczego.\nAt first, a fast way to a solution, and then explaining what I'm doing and why.\n"
}

hint4() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 ........\n 4 ........\n 5 ...................\n 6 \n 7 . . .. ...... . .. . . .. ...... . .. .... .\n 8 . . .. ...... . .. . . .. ...... . .. .... .\n 9 \n10 ....................... .. .......\n11 ....................... .. .......\n12 .. . ............... .. .............. .. .. .... .\n13 .. . ............... .. .............. .. .. .... .\n14 \n15 .. . ...... .. ...... .. .. .... .\n16 \n17 .................. ...... . ..... .. . ............ . .... .. . . ... ..... ....\n18 . .. ............... . .. .... .\n19 .. . ............... .. ............. .. .. .... .\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint5() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 . . .. ...... . .. . . .. ...... . .. .... .\n 8 . . .. ...... . .. . . .. ...... . .. .... .\n 9 \n10 ....................... .. .......\n11 ....................... .. .......\n12 .. . ............... .. .............. .. .. .... .\n13 .. . ............... .. .............. .. .. .... .\n14 \n15 .. . ...... .. ...... .. .. .... .\n16 \n17 .................. ...... . ..... .. . ............ . .... .. . . ... ..... ....\n18 . .. ............... . .. .... .\n19 .. . ............... .. ............. .. .. .... .\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint6() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 ....................... .. .......\n11 ....................... .. .......\n12 .. . ............... .. .............. .. .. .... .\n13 .. . ............... .. .............. .. .. .... .\n14 \n15 .. . ...... .. ...... .. .. .... .\n16 \n17 .................. ...... . ..... .. . ............ . .... .. . . ... ..... ....\n18 . .. ............... . .. .... .\n19 .. . ............... .. ............. .. .. .... .\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint7() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 .. . ...... .. ...... .. .. .... .\n16 \n17 .................. ...... . ..... .. . ............ . .... .. . . ... ..... ....\n18 . .. ............... . .. .... .\n19 .. . ............... .. ............. .. .. .... .\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint8() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 .................. ...... . ..... .. . ............ . .... .. . . ... ..... ....\n18 . .. ............... . .. .... .\n19 .. . ............... .. ............. .. .. .... .\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint9() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint10() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint11() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint12() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 NUMBER_OF_LINES=\$(cat \"\$SRC\" | wc -l)\n29 let LINE_PACKAGE_BEFORE=LINE_PACKAGE-1\n30 let LINE_PACKAGE_AFTER=NUMBER_OF_LINES-LINE_PACKAGE\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint13() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 NUMBER_OF_LINES=\$(cat \"\$SRC\" | wc -l)\n29 let LINE_PACKAGE_BEFORE=LINE_PACKAGE-1\n30 let LINE_PACKAGE_AFTER=NUMBER_OF_LINES-LINE_PACKAGE\n31 \n32 if [[ \"\$DST\" =~ /\$ ]] ; then\n33   LINE_LENGTH=\$(echo -n \"\$DST\" | wc -c)\n34   let LINE_LENGTH--\n35   DST=\$(echo -n \"\$DST\" | cut -c1-\"\$LINE_LENGTH\")\n36 fi\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint14() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 NUMBER_OF_LINES=\$(cat \"\$SRC\" | wc -l)\n29 let LINE_PACKAGE_BEFORE=LINE_PACKAGE-1\n30 let LINE_PACKAGE_AFTER=NUMBER_OF_LINES-LINE_PACKAGE\n31 \n32 if [[ \"\$DST\" =~ /\$ ]] ; then\n33   LINE_LENGTH=\$(echo -n \"\$DST\" | wc -c)\n34   let LINE_LENGTH--\n35   DST=\$(echo -n \"\$DST\" | cut -c1-\"\$LINE_LENGTH\")\n36 fi\n37 \n38 head -n \"\$LINE_PACKAGE_BEFORE\" \"\$SRC\" > \"\$DST/\$SRC_FILENAME\"\n39 echo \"package \$(echo \$DST | tr '/' '.');\">> \"\$DST/\$SRC_FILENAME\"\n40 tail -n \"\$LINE_PACKAGE_AFTER\" \"\$SRC\" >> \"\$DST/\$SRC_FILENAME\"\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint15() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 NUMBER_OF_LINES=\$(cat \"\$SRC\" | wc -l)\n29 let LINE_PACKAGE_BEFORE=LINE_PACKAGE-1\n30 let LINE_PACKAGE_AFTER=NUMBER_OF_LINES-LINE_PACKAGE\n31 \n32 if [[ \"\$DST\" =~ /\$ ]] ; then\n33   LINE_LENGTH=\$(echo -n \"\$DST\" | wc -c)\n34   let LINE_LENGTH--\n35   DST=\$(echo -n \"\$DST\" | cut -c1-\"\$LINE_LENGTH\")\n36 fi\n37 \n38 head -n \"\$LINE_PACKAGE_BEFORE\" \"\$SRC\" > \"\$DST/\$SRC_FILENAME\"\n39 echo \"package \$(echo \$DST | tr '/' '.');\">> \"\$DST/\$SRC_FILENAME\"\n40 tail -n \"\$LINE_PACKAGE_AFTER\" \"\$SRC\" >> \"\$DST/\$SRC_FILENAME\"\n41 \n42 rm \"\$SRC\" || exit 11\n43 \n44 .... .\n"
}

hint16() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 NUMBER_OF_LINES=\$(cat \"\$SRC\" | wc -l)\n29 let LINE_PACKAGE_BEFORE=LINE_PACKAGE-1\n30 let LINE_PACKAGE_AFTER=NUMBER_OF_LINES-LINE_PACKAGE\n31 \n32 if [[ \"\$DST\" =~ /\$ ]] ; then\n33   LINE_LENGTH=\$(echo -n \"\$DST\" | wc -c)\n34   let LINE_LENGTH--\n35   DST=\$(echo -n \"\$DST\" | cut -c1-\"\$LINE_LENGTH\")\n36 fi\n37 \n38 head -n \"\$LINE_PACKAGE_BEFORE\" \"\$SRC\" > \"\$DST/\$SRC_FILENAME\"\n39 echo \"package \$(echo \$DST | tr '/' '.');\">> \"\$DST/\$SRC_FILENAME\"\n40 tail -n \"\$LINE_PACKAGE_AFTER\" \"\$SRC\" >> \"\$DST/\$SRC_FILENAME\"\n41 \n42 rm \"\$SRC\" || exit 11\n43 \n44 exit 0\n"
}

hint17() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 ........\n 4 ........\n 5 ...................\n 6 \n 7 . . .. ...... . .. . . .. ...... . .. .... .\n 8 . . .. ...... . .. . . .. ...... . .. .... .\n 9 \n10 ....................... .. .......\n11 ....................... .. .......\n12 .. . ............... .. .............. .. .. .... .\n13 .. . ............... .. .............. .. .. .... .\n14 \n15 .. . ...... .. ...... .. .. .... .\n16 \n17 .................. ...... . ..... .. . ............ . .... .. . . ... ..... ....\n18 . .. ............... . .. .... .\n19 .. . ............... .. ............. .. .. .... .\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint18() {
  printf "Początek bardzo podobny do poprzednich, ale zwróć uwagę na opcję x. Potrafi ona zastąpić debugger, co w takich zadaniach potrafi być bardzo użyteczne.\nThe beginning is very similar to the previous ones, but pay attention to the x option. It can replace the debugger, which can be very useful in such tasks.\n"
}

hint19() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 . . .. ...... . .. . . .. ...... . .. .... .\n 8 . . .. ...... . .. . . .. ...... . .. .... .\n 9 \n10 ....................... .. .......\n11 ....................... .. .......\n12 .. . ............... .. .............. .. .. .... .\n13 .. . ............... .. .............. .. .. .... .\n14 \n15 .. . ...... .. ...... .. .. .... .\n16 \n17 .................. ...... . ..... .. . ............ . .... .. . . ... ..... ....\n18 . .. ............... . .. .... .\n19 .. . ............... .. ............. .. .. .... .\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint20() {
  printf "Oczywiście pobieramy argumenty, czyli co przenosimy i gdzie. Ale również zakładamy, że przenosimy to w ramach jakiegoś projektu, więc musimy znać katalog projektu, w którym te nasze pakiety są umieszczone.\nOf course, we take arguments, that is, what we are moving and where. But we also assume that we are moving this within a project, so we need to know the project directory where these packages of ours are placed.\n"
}

hint21() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 ....................... .. .......\n11 ....................... .. .......\n12 .. . ............... .. .............. .. .. .... .\n13 .. . ............... .. .............. .. .. .... .\n14 \n15 .. . ...... .. ...... .. .. .... .\n16 \n17 .................. ...... . ..... .. . ............ . .... .. . . ... ..... ....\n18 . .. ............... . .. .... .\n19 .. . ............... .. ............. .. .. .... .\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint22() {
  printf "Sprawdzamy czy nasze źródło jest plikiem, do którego mamy prawo odczytu, a cel katalogiem do którego mamy prawo zapisu. Jeżeli któryś z tych warunków nie jest spełniony, to skrypt kończy się z odpowiednim kodem błędu.\nWe check whether our source is a file to which we have read permission, and the target a directory to which we have write permission. If either of these conditions is not met, the script ends with the appropriate error code.\n"
}

hint23() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 .. . ...... .. ...... .. .. .... .\n16 \n17 .................. ...... . ..... .. . ............ . .... .. . . ... ..... ....\n18 . .. ............... . .. .... .\n19 .. . ............... .. ............. .. .. .... .\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint24() {
  printf "Tutaj jest coś nowego. Wykorzystujemy ścieżki absolutne do sprawdzenia, czy nasze źródło i nasz cel znajdują się w odpowienim projekcie. Prefiks ścieżki absolutnej powinien odpowiadać wartości zmiennej PROJECT_ROOT.\nHere is something new. We use absolute paths to check that our source and our target are in the correct project. The absolute path prefix should match the value of the PROJECT_ROOT variable.\n"
}

hint25() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 .................. ...... . ..... .. . ............ . .... .. . . ... ..... ....\n18 . .. ............... . .. .... .\n19 .. . ............... .. ............. .. .. .... .\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint26() {
  printf "Sprawdzamy, czy plik źródłowy ma rozszerzenie java.\nWe check that the source file has a java extension.\n"
}

hint27() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 ................ ...... . ..... .. . ....... ....... . .... .. . . ... ..... ....\n22 . .. ............. . .. .... .\n23 .. . ............. .. ............. .. .. .... .\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint28() {
  printf "Uzyskujemy informację o numerze linii w pliku źródłowym, w której znajduje się informacja o pakiecie. Zwróć uwagę na opcję n polecenia egrep. Wyrażenie regularne jest tutaj dość uproszczone, ale na razie powinno nam wystarczyć.\nWe get information about the line number in the source file where the package information is located. Note the n option of the egrep command. The regular expression here is quite simplified, but it should suffice for now.\n"
}

hint29() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 ....................... .......\n26 . .. .................................. . .. .... ..\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint30() {
  printf "Uzyskujemy informację o numerze linii w pliku źródłowym, w której znajduje się informacja o klasie publicznej. Zwróć uwagę na opcję n polecenia egrep. Wyrażenie regularne jest tutaj dość uproszczone, ale na razie powinno nam wystarczyć.\nWe get information about the line number in the source file where the public class information is located. Note the n option of the egrep command. The regular expression here is quite simplified, but it should suffice for now.\n"
}

hint31() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 ..................... ...... . .. ...\n29 ... ..................................\n30 ... ...............................................\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint32() {
  printf "Pobieramy nazwę pliku żródłowego (bez ścieżki) i sprawdzamy, czy w naszej destynacji istnieje już cokolwiek o tej nazwie. Jak tak to kończymy skrypt.\nWe take the name of the source file (without the path) and check if anything with that name already exists in our destination. If so, we end the script.\n"
}

hint33() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 NUMBER_OF_LINES=\$(cat \"\$SRC\" | wc -l)\n29 let LINE_PACKAGE_BEFORE=LINE_PACKAGE-1\n30 let LINE_PACKAGE_AFTER=NUMBER_OF_LINES-LINE_PACKAGE\n31 \n32 .. .. ...... .. .. .. . ....\n33   .................. .. ...... . .. ...\n34   ... .............\n35   .......... .. ...... . ... ...................\n36 ..\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint34() {
  printf "Tutaj przygotowujemy się do przenoszenia zawartości pliku. Znamy numer linii z informacją o pakiecie, a teraz wyznaczamy ile jest linii w tym pliku przed tą linią i za tą linią.\nHere we are preparing to move the contents of the file. We know the line number with the package information, and now we determine how many lines there are in this file before this line and after this line.\n"
}

hint35() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 NUMBER_OF_LINES=\$(cat \"\$SRC\" | wc -l)\n29 let LINE_PACKAGE_BEFORE=LINE_PACKAGE-1\n30 let LINE_PACKAGE_AFTER=NUMBER_OF_LINES-LINE_PACKAGE\n31 \n32 if [[ \"\$DST\" =~ /\$ ]] ; then\n33   LINE_LENGTH=\$(echo -n \"\$DST\" | wc -c)\n34   let LINE_LENGTH--\n35   DST=\$(echo -n \"\$DST\" | cut -c1-\"\$LINE_LENGTH\")\n36 fi\n37 \n38 .... .. ...................... ...... . ....................\n39 .... ........ ...... .... . .. ... ........ ....................\n40 .... .. ..................... ...... .. ....................\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint36() {
  printf "Będziemy potrzebowali nazwy pakietu docelowego. Oczywiście uzyskamy tę nazwę ze ścieżki DST, ale musimy sprawdzić, czy ostatnim znakiem jest /. Jak tak do musimy go usunąć.\nWe will need the name of the target package. Of course, we will get this name from the DST path, but we need to check if the last character is /. If yes to we need to remove it.\n"
}

hint37() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 NUMBER_OF_LINES=\$(cat \"\$SRC\" | wc -l)\n29 let LINE_PACKAGE_BEFORE=LINE_PACKAGE-1\n30 let LINE_PACKAGE_AFTER=NUMBER_OF_LINES-LINE_PACKAGE\n31 \n32 if [[ \"\$DST\" =~ /\$ ]] ; then\n33   LINE_LENGTH=\$(echo -n \"\$DST\" | wc -c)\n34   let LINE_LENGTH--\n35   DST=\$(echo -n \"\$DST\" | cut -c1-\"\$LINE_LENGTH\")\n36 fi\n37 \n38 head -n \"\$LINE_PACKAGE_BEFORE\" \"\$SRC\" > \"\$DST/\$SRC_FILENAME\"\n39 echo \"package \$(echo \$DST | tr '/' '.');\">> \"\$DST/\$SRC_FILENAME\"\n40 tail -n \"\$LINE_PACKAGE_AFTER\" \"\$SRC\" >> \"\$DST/\$SRC_FILENAME\"\n41 \n42 .. ...... .. .... ..\n43 \n44 .... .\n"
}

hint38() {
  printf "W trzech fazach przenosimy zawartość pliku źródłowego do pliku docelowego. Pierwsza faza przenosi linie do informacji o pakiecie, druga informacje o pakiecie i trzecia resztę linii, aż do końca pliku.\nIn three phases, we transfer the contents of the source file to the destination file. The first phase moves the lines to the package information, the second the package information and the third the rest of the lines until the end of the file.\n"
}

hint39() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 NUMBER_OF_LINES=\$(cat \"\$SRC\" | wc -l)\n29 let LINE_PACKAGE_BEFORE=LINE_PACKAGE-1\n30 let LINE_PACKAGE_AFTER=NUMBER_OF_LINES-LINE_PACKAGE\n31 \n32 if [[ \"\$DST\" =~ /\$ ]] ; then\n33   LINE_LENGTH=\$(echo -n \"\$DST\" | wc -c)\n34   let LINE_LENGTH--\n35   DST=\$(echo -n \"\$DST\" | cut -c1-\"\$LINE_LENGTH\")\n36 fi\n37 \n38 head -n \"\$LINE_PACKAGE_BEFORE\" \"\$SRC\" > \"\$DST/\$SRC_FILENAME\"\n39 echo \"package \$(echo \$DST | tr '/' '.');\">> \"\$DST/\$SRC_FILENAME\"\n40 tail -n \"\$LINE_PACKAGE_AFTER\" \"\$SRC\" >> \"\$DST/\$SRC_FILENAME\"\n41 \n42 rm \"\$SRC\" || exit 11\n43 \n44 .... .\n"
}

hint40() {
  printf "W końcu kasujemy plik źródłowy. Jeżeli się nie udało tego zrobić, skrypt kończy się błędem.\nFinally, we delete the source file. If you failed to do so, the script ends with an error.\n"
}

hint41() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 NUMBER_OF_LINES=\$(cat \"\$SRC\" | wc -l)\n29 let LINE_PACKAGE_BEFORE=LINE_PACKAGE-1\n30 let LINE_PACKAGE_AFTER=NUMBER_OF_LINES-LINE_PACKAGE\n31 \n32 if [[ \"\$DST\" =~ /\$ ]] ; then\n33   LINE_LENGTH=\$(echo -n \"\$DST\" | wc -c)\n34   let LINE_LENGTH--\n35   DST=\$(echo -n \"\$DST\" | cut -c1-\"\$LINE_LENGTH\")\n36 fi\n37 \n38 head -n \"\$LINE_PACKAGE_BEFORE\" \"\$SRC\" > \"\$DST/\$SRC_FILENAME\"\n39 echo \"package \$(echo \$DST | tr '/' '.');\">> \"\$DST/\$SRC_FILENAME\"\n40 tail -n \"\$LINE_PACKAGE_AFTER\" \"\$SRC\" >> \"\$DST/\$SRC_FILENAME\"\n41 \n42 rm \"\$SRC\" || exit 11\n43 \n44 exit 0\n"
}

hint42() {
  printf "Kończymy wykonanie skryptu.\nWe finish the execution of the script.\n"
}

solution() {
  printf " 1 #!/bin/bash -x\n 2 \n 3 SRC=\"\$1\"\n 4 DST=\"\$2\"\n 5 PROJECT_ROOT=\$(pwd)\n 6 \n 7 [ ! -f \"\$SRC\" ] && [ ! -r \"\$SRC\" ] && exit 1\n 8 [ ! -d \"\$DST\" ] && [ ! -w \"\$DST\" ] && exit 2\n 9 \n10 SRC_ABSOLUTE=\$(readlink -f \"\$SRC\")\n11 DST_ABSOLUTE=\$(readlink -f \"\$DST\")\n12 [[ ! \"\$SRC_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 3\n13 [[ ! \"\$DST_ABSOLUTE\" =~ ^\$PROJECT_ROOT ]] && exit 4\n14 \n15 [[ ! \"\$SRC\" =~ \.java ]] && exit 5\n16 \n17 LINE_PACKAGE=\$(cat \"\$SRC\" | egrep -n \" *package.+;\" | head -n 1 | cut -d\":\" -f1)\n18 [ -z \"\$LINE_PACKAGE\" ] && exit 6\n19 [[ ! \"\$LINE_PACKAGE\" =~ ^[0-9][0-9]*\$ ]] && exit 7\n20 \n21 LINE_CLASS=\$(cat \"\$SRC\" | egrep -n \" *public +class\" | head -n 1 | cut -d\":\" -f1)\n22 [ -z \"\$LINE_CLASS\" ] && exit 8\n23 [[ ! \"\$LINE_CLASS\" =~ ^[0-9][0-9]*\$ ]] && exit 9\n24 \n25 SRC_FILENAME=\$(basename \"\$SRC\")\n26 [ -e \"\$PROJECT_ROOT/\$DST/\$SRC_FILENAME\" ] && exit 10\n27 \n28 NUMBER_OF_LINES=\$(cat \"\$SRC\" | wc -l)\n29 let LINE_PACKAGE_BEFORE=LINE_PACKAGE-1\n30 let LINE_PACKAGE_AFTER=NUMBER_OF_LINES-LINE_PACKAGE\n31 \n32 if [[ \"\$DST\" =~ /\$ ]] ; then\n33   LINE_LENGTH=\$(echo -n \"\$DST\" | wc -c)\n34   let LINE_LENGTH--\n35   DST=\$(echo -n \"\$DST\" | cut -c1-\"\$LINE_LENGTH\")\n36 fi\n37 \n38 head -n \"\$LINE_PACKAGE_BEFORE\" \"\$SRC\" > \"\$DST/\$SRC_FILENAME\"\n39 echo \"package \$(echo \$DST | tr '/' '.');\">> \"\$DST/\$SRC_FILENAME\"\n40 tail -n \"\$LINE_PACKAGE_AFTER\" \"\$SRC\" >> \"\$DST/\$SRC_FILENAME\"\n41 \n42 rm \"\$SRC\" || exit 11\n43 \n44 exit 0\n"
}



homework1() {
  printf "Praca domowa #3008_1: Zmień to rozwiązanie na podprogramy. To już robiłeś, ale przy tej liczbie operacji, aż się prosi o taki sensowny, przemyślany podział.\nHomework #3008_1: Change this solution into subroutines. It's something you've already done, but with this number of operations, it begs for such a sensible, thoughtful division.\n"
}

homework2() {
  printf "Praca domowa #3008_1: W powyższym rozwiązaniu założyłem, że przenosimy plik java do innego pakietu, czyli do innego katalogu, ale nie zmieniamy samej nazwy tego pliku. Wprowadź zmianę w skrypcie aby obsługiwał on również przypadek przeniesienia klasy z pakietu do pakietu z jednoczesną zmianą nazwy. Uwaga, oprócz zmiany nazwy pliku, musisz zmienić nazwę klasy publicznej w tym pliku. Obsłuż tylko najprostsze przypadki.\nHomework #3008_1: In the above solution, I assumed that we are moving a java file to a different package, i.e. to a different directory, but not renaming the file name itself. Make a change in the script so that it also handles the case of moving a class from a package to a package with a simultaneous name change. Note, in addition to renaming the file, you must rename the public class in that file. Support only the simplest cases.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'hint30' 'hint31' 'hint32' 'hint33' 'hint34' 'hint35' 'hint36' 'hint37' 'hint38' 'hint39' 'hint40' 'hint41' 'hint42' 'solution' 'homework1' 'homework2' 

exit 0