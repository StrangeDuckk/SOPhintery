#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 4 | 0 | 0 | 2 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Napisz skrypt, który wczyta z klawiatury liczbę całkowitą i tekstowo na konsoli "narysuje" kopertę."
  echo 
  echo "Write a script that reads an integer from the keyboard and textually on the console to "draw" an envelope."
  echo "--------------------------"
  echo 
  echo "Enter envelope size: 20"
  echo "XXXXXXXXXXXXXXXXXXXX"
  echo "XX...............X.X"
  echo "X.X.............X..X"
  echo "X..X...........X...X"
  echo "X...X.........X....X"
  echo "X....X.......X.....X"
  echo "X.....X.....X......X"
  echo "X......X...X.......X"
  echo "X.......X.X........X"
  echo "X........X.........X"
  echo "X.......X.X........X"
  echo "X......X...X.......X"
  echo "X.....X.....X......X"
  echo "X....X.......X.....X"
  echo "X...X.........X....X"
  echo "X..X...........X...X"
  echo "X.X.............X..X"
  echo "XX...............X.X"
  echo "X.................XX"
  echo "XXXXXXXXXXXXXXXXXXXX"
}

my_clear() {
  clear
}


hint1() {
  printf "W rozwiązaniu wykorzystam: if, for, podprogram, zmienne, echo, instrukcję read i seq.\nIn the solution I will use: if, for, subroutine, variables, echo, eval, read and seq statements.\n"
}

hint2() {
  printf "Na wstępie, jak zwykle szybkie przedstawienie rozwiązania. A później będę to tłumaczył.\nFirst, as usual, a quick presentation of the solution. And later I will explain it.\n"
}

hint3() {
  printf " 1 ...........\n 2 \n 3 ............................. .\n 4   ......\n 5   ......\n 6   ......\n 7 \n 8   . .... ... . . .. .... ... .. ...... .\n 9   . .... ... .... . .. .... ... .. ...... .\n10   . .... ... . . .. .... ... .. ...... .\n11   . .... ... .... . .. .... ... .. ...... .\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   .... ...\n15   ...... .\n16 .\n17 \n18 .... .. ...... ........ ..... . .\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint4() {
  printf " 1 #!/bin/bash\n 2 \n 3 ............................. .\n 4   ......\n 5   ......\n 6   ......\n 7 \n 8   . .... ... . . .. .... ... .. ...... .\n 9   . .... ... .... . .. .... ... .. ...... .\n10   . .... ... . . .. .... ... .. ...... .\n11   . .... ... .... . .. .... ... .. ...... .\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   .... ...\n15   ...... .\n16 .\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint5() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   ......\n 5   ......\n 6   ......\n 7 \n 8   . .... ... . . .. .... ... .. ...... .\n 9   . .... ... .... . .. .... ... .. ...... .\n10   . .... ... . . .. .... ... .. ...... .\n11   . .... ... .... . .. .... ... .. ...... .\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   .... ...\n15   ...... .\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint6() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   . .... ... . . .. .... ... .. ...... .\n 9   . .... ... .... . .. .... ... .. ...... .\n10   . .... ... . . .. .... ... .. ...... .\n11   . .... ... .... . .. .... ... .. ...... .\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   .... ...\n15   ...... .\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint7() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   . .... ... . . .. .... ... .. ...... .\n 9   . .... ... .... . .. .... ... .. ...... .\n10   . .... ... . . .. .... ... .. ...... .\n11   . .... ... .... . .. .... ... .. ...... .\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint8() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   . .... ... . . .. .... ... .. ...... .\n11   . .... ... .... . .. .... ... .. ...... .\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint9() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint10() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint11() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 for I in \$(seq 1 \$N) ; do\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 done\n"
}

hint12() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 for I in \$(seq 1 \$N) ; do\n21   for J in \$(seq 1 \$N) ; do\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   done\n28   ....\n29 done\n"
}

hint13() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 for I in \$(seq 1 \$N) ; do\n21   for J in \$(seq 1 \$N) ; do\n22     if [ \$(is_printed_part_of_envelope \$I \$J \$N) = 'T' ] ; then\n23       .... .. ...\n24     else\n25       .... .. ...\n26     fi\n27   done\n28   ....\n29 done\n"
}

hint14() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 for I in \$(seq 1 \$N) ; do\n21   for J in \$(seq 1 \$N) ; do\n22     if [ \$(is_printed_part_of_envelope \$I \$J \$N) = 'T' ] ; then\n23       echo -n \"X\"\n24     else\n25       echo -n \".\"\n26     fi\n27   done\n28   ....\n29 done\n"
}

hint15() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 for I in \$(seq 1 \$N) ; do\n21   for J in \$(seq 1 \$N) ; do\n22     if [ \$(is_printed_part_of_envelope \$I \$J \$N) = 'T' ] ; then\n23       echo -n \"X\"\n24     else\n25       echo -n \".\"\n26     fi\n27   done\n28   echo\n29 done\n"
}

hint16() {
  printf "No to teraz zaczynam tłumaczyć co się tutaj dzieje, chociaż pewnie większość z Państwa już wie i może napisać ten skrypt samodzielnie i samodzielnie wykonać prace domowe. \nWell, now I begin to explain what is going on here, although probably most of you already know and can write this script yourself and also do the homework yourself.\n"
}

hint17() {
  printf " 1 #!/bin/bash\n 2 \n 3 ............................. .\n 4   ......\n 5   ......\n 6   ......\n 7 \n 8   . .... ... . . .. .... ... .. ...... .\n 9   . .... ... .... . .. .... ... .. ...... .\n10   . .... ... . . .. .... ... .. ...... .\n11   . .... ... .... . .. .... ... .. ...... .\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   .... ...\n15   ...... .\n16 .\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint18() {
  printf "W linii 18tej wczytujemy rozmiar naszej koperty. Opcja p polecenia read pozwala wyświetlić tekst zachęty.\nIn line 18t we read the size of our envelope. The p option of the read command helps to display the prompt text.\n"
}

hint19() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   ......\n 5   ......\n 6   ......\n 7 \n 8   . .... ... . . .. .... ... .. ...... .\n 9   . .... ... .... . .. .... ... .. ...... .\n10   . .... ... . . .. .... ... .. ...... .\n11   . .... ... .... . .. .... ... .. ...... .\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   .... ...\n15   ...... .\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint20() {
  printf "Do określenia, czy na wydruku ma się pojawić wypełniony piksel, czy niewypełniony będzie użyty podprogram is_printed_part_of_envelope.\nThe is_printed_part_of_envelope subroutine will be used to determine whether a filled pixel or unfilled pixel should appear on the printout.\n"
}

hint21() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   . .... ... . . .. .... ... .. ...... .\n 9   . .... ... .... . .. .... ... .. ...... .\n10   . .... ... . . .. .... ... .. ...... .\n11   . .... ... .... . .. .... ... .. ...... .\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   .... ...\n15   ...... .\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint22() {
  printf "Podprogram ten pobiera trzy parametry: informacje o współrzędnych aktualnego piksela oraz rozmiar całej koperty.\nThis subroutine takes three parameters: information about the coordinates of the currently printed pixel and the size of the entire envelope.\n"
}

hint23() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   . .... ... . . .. .... ... .. ...... .\n 9   . .... ... .... . .. .... ... .. ...... .\n10   . .... ... . . .. .... ... .. ...... .\n11   . .... ... .... . .. .... ... .. ...... .\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint24() {
  printf "Podprogram domyślnie wyświetla wartość 'F' i zwraca 0\nThe subroutine displays the value 'F' by default and returns 0\n"
}

hint25() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   . .... ... . . .. .... ... .. ...... .\n11   . .... ... .... . .. .... ... .. ...... .\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint26() {
  printf "Natomiast wyświetla 'T' i zwraca 1 jak współrzędna X odwołuje się pierwszej lub ostatniej kolumny.\nOn the other hand, it displays 'T' and returns 1 as the X coordinate refers to the first or last column.\n"
}

hint27() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   . .... ... .... . .. .... ... .. ...... .\n13   . .... ... .......... . .. .... ... .. ...... .\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint28() {
  printf "lub jak współrzędna Y odwołuje się pierwszego lub ostatniego wiersza.\nor as the Y coordinate refers to the first or last row.\n"
}

hint29() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 ... . .. ..... . ... . ..\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 ....\n"
}

hint30() {
  printf "lub współrzędne X i Y odwołują się do przekątnych.\nOr X and Y coordinates refer to diagonals.\n"
}

hint31() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 for I in \$(seq 1 \$N) ; do\n21   ... . .. ..... . ... . ..\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   ....\n28   ....\n29 done\n"
}

hint32() {
  printf "Użyjemy pętli for do wykonania N iteracji. Polecenie seq generuje sekwencję elementów od 1 do N, więc pętla for wykona pojedynczą iterację po każdym z tych elementów.\nWe will use a for loop to perform N iterations. The seq command generates a sequence of elements from 1 to N, so the for loop will perform a single iteration over each of these elements.\n"
}

hint33() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 for I in \$(seq 1 \$N) ; do\n21   for J in \$(seq 1 \$N) ; do\n22     .. . ............................. .. .. ... . ... . . ....\n23       .... .. ...\n24     ....\n25       .... .. ...\n26     ..\n27   done\n28   ....\n29 done\n"
}

hint34() {
  printf "Zagnieżdżona pętla for również wykona N iteracji, czyli w sumie wykonanych zostanie NxN iteracji.\nThe nested for loop will also perform N iterations, so a total of NxN iterations will be performed.\n"
}

hint35() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 for I in \$(seq 1 \$N) ; do\n21   for J in \$(seq 1 \$N) ; do\n22     if [ \$(is_printed_part_of_envelope \$I \$J \$N) = 'T' ] ; then\n23       .... .. ...\n24     else\n25       .... .. ...\n26     fi\n27   done\n28   ....\n29 done\n"
}

hint36() {
  printf "W ciele pętli została umieszczona instrukcja if. Sprawdzamy w niej czy podprogram is_printed_part_of_envelope wyświetli tekst 'F' czy 'T'.\nAn if statement has been placed in the body of the loop. In it, we check whether the is_printed_part_of_envelop subroutine will display the text 'F' or 'T'.\n"
}

hint37() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 for I in \$(seq 1 \$N) ; do\n21   for J in \$(seq 1 \$N) ; do\n22     if [ \$(is_printed_part_of_envelope \$I \$J \$N) = 'T' ] ; then\n23       echo -n \"X\"\n24     else\n25       echo -n \".\"\n26     fi\n27   done\n28   ....\n29 done\n"
}

hint38() {
  printf "Od tego co zwróci podprogram is_printed_part_of_envelope, zalezy czy zostanie wyświetlony znak X czy kropka.\nWhat the is_printed_part_of_envelope subroutine returns will determine whether an X or a dot is displayed.\n"
}

hint39() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 for I in \$(seq 1 \$N) ; do\n21   for J in \$(seq 1 \$N) ; do\n22     if [ \$(is_printed_part_of_envelope \$I \$J \$N) = 'T' ] ; then\n23       echo -n \"X\"\n24     else\n25       echo -n \".\"\n26     fi\n27   done\n28   echo\n29 done\n"
}

hint40() {
  printf "Polecenie echo z linii 28 ma za zadanie przejść do nowej linii po zakończeniu wydruku wszystkich znaków w wierszu.\nThe echo command from line 28 is designed to go to a new line after all the characters on the line have finished printing.\n"
}

solution() {
  printf " 1 #!/bin/bash\n 2 \n 3 is_printed_part_of_envelope() {\n 4   X=\"\$1\"\n 5   Y=\"\$2\"\n 6   N=\"\$3\"\n 7 \n 8   [ \"\$X\" -eq 1 ] && echo 'T' && return 1\n 9   [ \"\$X\" -eq \"\$N\" ] && echo 'T' && return 1\n10   [ \"\$Y\" -eq 1 ] && echo 'T' && return 1\n11   [ \"\$Y\" -eq \"\$N\" ] && echo 'T' && return 1\n12   [ \"\$X\" -eq \"\$Y\" ] && echo 'T' && return 1\n13   [ \"\$X\" -eq \"\$((N-Y))\" ] && echo 'T' && return 1\n14   echo 'F'\n15   return 0\n16 }\n17 \n18 read -p \"Enter envelope size: \" N\n19 \n20 for I in \$(seq 1 \$N) ; do\n21   for J in \$(seq 1 \$N) ; do\n22     if [ \$(is_printed_part_of_envelope \$I \$J \$N) = 'T' ] ; then\n23       echo -n \"X\"\n24     else\n25       echo -n \".\"\n26     fi\n27   done\n28   echo\n29 done\n"
}



homework1() {
  printf "Praca domowa #4002_1: Zmodyfikuj napisany skrypt, aby obsługiwał też koperty o kształcie prostokąta.\nHomework #4002_1: Modify the script you wrote to also handle rectangular shaped envelopes.\n"
}

homework2() {
  printf "Praca domowa #4002_2: Zmodyfikuj napisany skrypt, aby sprawdzał wartość zwracaną przez return, a nie to co jest przez co ten podprogram wyświetlane (usuń wywołania typu echo 'T' lub echo 'F' z podprogramu.\nHomework #4002_2: Modify the script you wrote so that it checks the value returned by return, not what is displayed by what this subroutine does (remove calls like echo 'T' or echo 'F' from the subroutine.\n"
}

homework3() {
  printf "Praca domowa #4002_3: Zamień podprogram is_printed_part_of_envelop na print_pixel_of_envelope. Podprogram print_pixel_of_envelope ma drukować konkretny piksel, czyli albo X albo kropkę.\nHomework #4002_3: Replace the is_printed_part_of_envelope subroutine with print_pixel_of_envelope. The print_pixel_of_envelope subroutine is to print a specific pixel, that is, either an X or a dot.\n"
}

homework4() {
  printf "Praca domowa #4002_4: Napisz skrypt drukujący choinkę o podanej wysokości.\nHomework #4002_4: Write a script that prints a Christmas tree of the given height.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'hint30' 'hint31' 'hint32' 'hint33' 'hint34' 'hint35' 'hint36' 'hint37' 'hint38' 'hint39' 'hint40' 'solution' 'homework1' 'homework2' 'homework3' 'homework4' 

exit 0