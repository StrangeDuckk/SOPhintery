#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 1 | 0 | 0 | 3 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Najszybszą znaną sobie metodą utwórz 40 dowolnych katalogów. Skasuj potem te katalogi."
  echo 
  echo "Using the fastest method you know, create 40 arbitrary directories. Then delete those directories."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "To zadanie jest zadaniem ogólnym i może być rozwiązane na wiele sposobów. Hinter przedstawi Ci jeden z nich.\nThis task is a general task and can be solved in many ways. Hinter will introduce you to one of them.\n"
}

hint2() {
  printf "Użyjemy poleceń mkdir do utworzenia katalogów i rm do ich usunięcia.\nWe will use the mkdir commands to create directories and rm to delete them.\n"
}

hint3() {
  printf "Zauważ, że polecenie mkdir może przyjąć jako swoje argumenty wiele nazw katalogów.\nNote that the mkdir command can take multiple directory names as its arguments.\n"
}

hint4() {
  printf "Zanim zaczniesz tworzyć katalogi poleceniem mkdir, może najpierw wyswietl ich nazwy poleceniem echo\nBefore you start creating directories with the mkdir command, why not first display their names with the echo command.\n"
}

hint5() {
  printf "Sprawdź w podręczniku man do czego służą opcje -v -p polecenia mkdir.\nCheck the man page for what the -v -p options of the mkdir command are used for.\n"
}

hint6() {
  printf "Zanim zaczniesz wypisywać różne kombinacje nazw katalogów - uruchom echo {a..d}.\nBefore you start typing out different combinations of directory names - run echo {a..d}.\n"
}

hint7() {
  printf "Masz już wszystkie, niezbędne informacje.  Zacznij od polecenia echo zamiast mkdir.\nYou already have all, necessary information. Now just sit down and write. Start with echo command instead of mkdir.\n"
}

hint8() {
  printf "echo {1..40}\n"
}

hint9() {
  printf "Czy mamy 40 nazw? Jak tak to zamieniamy echo na mkdir.\nDo we have 40 names? If so, replace echo with mkdir\n"
}

hint10() {
  printf "mkdir {1..40}\n"
}

hint11() {
  printf "rm ... {1..40}\n"
}

hint12() {
  printf "rm -rf {1..40}\n"
}

hint13() {
  printf "mkdir {1..40} ; rm -rf {1..40}\n"
}

solution() {
  printf "mkdir {1..40} ; rm -rf {1..40}\n"
}



homework1() {
  printf "Praca domowa #1003_1: W każdym z tych 40 katalogów, utwórz po 10 plików? Oczywiście zweryfikuj czy się udało to zrobić. Najlepiej aby te pliki zawierały jakąś treść, ale jeżeli nie potrafisz tego zrobić, to mogą być i puste, Po ćwiczeniu skasuj i pliki i katalogi.\nHomework #1003_1: In each of these 40 directories, create 10 files each? Verify, of course, whether you succeeded in doing so. Ideally, these files should contain some content, but if you can't do it, they can be empty as well, After the exercise, delete both files and directories.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'solution' 'homework1' 

exit 0