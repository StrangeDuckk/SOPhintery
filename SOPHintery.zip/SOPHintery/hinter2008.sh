#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 2 | 0 | 0 | 8 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "We wskazanym przez użytkownika katalogu, znajdź wszystkie pliki niewykonywalne ale takie które możemy odczytać, są odczytywalne dla człowieka i wyświetl ich nazwy i zawartość, ale w zawartości zamień wszystkie duże litery na małe, a małe na duże."
  echo 
  echo "In the directory indicated by the user, find all non-executable but human-readable files and display their names and contents, but in the contents replace all uppercase letters with lowercase letters and lowercase letters with uppercase letters."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Tak dużo do zrobienia. Będzimy potrzebować komend: bash, find, cat, tr, file,grep, potoków ....\nSo much to do. We will need the commands: bash, find, cat, tr, file,grep, pipe ....\n"
}

hint2() {
  printf "Załóżmy, że pracujemy na katalogu bieżącym czyli . \nLet's assume that we are working on the current directory ie .\n"
}

hint3() {
  printf "Znajdźmy wszystkie pliki w bieżącym katalogu.\nLet's find all the files in the current directory.\n"
}

hint4() {
  printf "find .\n"
}

hint5() {
  printf "Znajdźmy wszystkie pliki wykonywalne i odczytywalne w bieżącym katalogu.\nLet's find all executable and readable files in the current directory.\n"
}

hint6() {
  printf "find . -executable -readable\n"
}

hint7() {
  printf "Znajdźmy wszystkie pliki niewykonywalne i odczytywalne w bieżącym katalogu.\nLet's find all non-executable and readable files in the current directory.\n"
}

hint8() {
  printf "find . ! -executable -readable\n"
}

hint9() {
  printf "Sprawdźmy teraz czy pliki są odczytywalne przez człowieka. To nie jest to samo co atrybut readable wskazany w poleceniu find.\nNow let's check if the files are human readable. This is not the same as the readable attribute indicated in the find command.\n"
}

hint10() {
  printf "Użyjmy polecenia file.\nLet's use the file command.\n"
}

hint11() {
  printf "file nazwa.pliku\n"
}

hint12() {
  printf "Możemy uzyskać następujące komunikaty.\nWe can get the following messages\n"
}

hint13() {
  printf "./a.txt: ASCII text\n./b.txt: empty\n./c.sh: Bourne-Again shell script, ASCII text executable\n./d.txt: UTF-8 Unicode text\n./e.txt: UTF-8 Unicode text, with very long lines\n./m.sh: Bourne-Again shell script, UTF-8 Unicode text executable\n./n.sh: Bourne-Again shell script, UTF-8 Unicode text executable, with very long lines\n./o.sh: Bourne-Again shell script, ASCII text executable, with CRLF line terminators\n./x.txt: ASCII text\n"
}

hint14() {
  printf "Wybierzmy teraz te pliki, które chcemy uznać, za pliki odczytywalne przez człowieka: na przykład pliki ASCII lub UTF-8.\nLet's now select those files that we want to consider as human-readable files: for example ASCII, UTF-8 files\n"
}

hint15() {
  printf "Zacznijmy od prostego przykładu\nLet's start with a simple example\n"
}

hint16() {
  printf "ls\n"
}

hint17() {
  printf "ls | file\n"
}

hint18() {
  printf "Nie działa niestety, bo okazuje się że polecenie file wymaga podania danych jako argumenty. Wypróbujmy polecenie xargs.\nIt doesn't work unfortunately, because it turns out that the file command requires data as arguments. Let's try .... xargs command.\n"
}

hint19() {
  printf "ls | xargs file\n"
}

hint20() {
  printf "Działa. Polecenie xargs odczytało dane z potoku i wykorzystało je do uruchomienia polecenia file z danymi odczytanymi z potoku jako argumenty. Czasami to jest bardzo przydatne.\nIt works. The xargs command read the data from the pipeline and used it to run the file command with the data read from the pipeline as arguments. Sometimes this is very useful.\n"
}

hint21() {
  printf "Przefiltrujmy uzyskane dane: \nLet's filter the resulting data:\n"
}

hint22() {
  printf "ls | xargs file | grep ASCII|UTF-8\n"
}

hint23() {
  printf "Nie działa niestety, bo okazuje się że znak | ma podwójne znaczenie: potok i lub w wyrażeniach regularnych.\nIt doesn't work, unfortunately, because it turns out that the | character has a double meaning: pipe and or in regular expressions\n"
}

hint24() {
  printf "ls | xargs file | grep \"ASCII|UTF-8\"\n"
}

hint25() {
  printf "Lepiej, ale dalej nie działa niestety, bo okazuje się że znak | w wyrażeniach regularnych jest obsługiwany przez egrep ale nie przez grep.\nBetter, but still doesn't work unfortunately, because it turns out that the | character in regular expressions is handled by egrep but not by grep\n"
}

hint26() {
  printf "ls | xargs file | egrep \"ASCII|UTF-8\"\n"
}

hint27() {
  printf "Wykorzystajmy to w poleceniu find\nLet's filter the resulting data:\n"
}

hint28() {
  printf "find | xargs file | egrep \"ASCII|UTF-8\"\n"
}

hint29() {
  printf "Wybierzmy tylko nazwę bez opisu. Interesuje nas tylko i wyłącznie pierwsza kolumna - do dwukropka\nLet's choose only the name without description. We are interested only in the first column - up to the colon\n"
}

hint30() {
  printf "find | xargs file | egrep \"ASCII|UTF-8\" | cut -d: -f1\n"
}

hint31() {
  printf "Nazwa ma się stać argumentem polecenia cat więc ...\nThe name is to become a cat command argument, so ...\n"
}

hint32() {
  printf "find | xargs file | egrep \"ASCII|UTF-8\" | cut -d: -f1 | xargs cat\n"
}

hint33() {
  printf "No i zamiana znaków ...\nWell, and swapping (translating) characters\n"
}

hint34() {
  printf "find | xargs file | egrep \"ASCII|UTF-8\" | cut -d: -f1 | xargs cat | tr 'A-Za-z' 'a-zA-Z\n"
}

hint35() {
  printf "Trochę inne rozwiązanie. Zwróć uwagę na wykorzystanie opcji exec, użycie polecenia bash.  Zwróć uwagę również na nawiasy, cudzysłowy, apostrofy i potoki.\nA slightly different solution. Note the use of the exec option, the use of the bash command. Also pay attention to parentheses, quotation marks, apostrophes, and piplines.\n"
}

hint36() {
  printf "bash -c \"cat \$(find . -executable -readable -exec bash -c \"file {} | egrep 'ASCII|UTF-8'\" \; | cut -d':' -f1) | tr 'A-Za-z' 'a-zA-Z' | tr -d '\r'\"\n"
}

solution() {
  printf "find | xargs file | egrep \"ASCII|UTF-8\" | cut -d: -f1 | xargs cat | tr 'A-Za-z' 'a-zA-Z\nbash -c \"cat \$(find . -executable -readable -exec bash -c \"file {} | egrep 'ASCII|UTF-8'\" \; | cut -d':' -f1) | tr 'A-Za-z' 'a-zA-Z' | tr -d '\r'\"\n"
}



homework1() {
  printf "Praca domowa 2008_1: Dodatkowo usuń z wyniku wszystkie cyfry parzyste.\nHomework 2008_1: In addition, remove all even numbers from the result.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'hint30' 'hint31' 'hint32' 'hint33' 'hint34' 'hint35' 'hint36' 'solution' 'homework1' 

exit 0