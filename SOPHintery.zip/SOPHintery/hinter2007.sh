#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 2 | 0 | 0 | 7 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "We wskazanym przez użytkownika katalogu, znajdź wszystkie pliki Wykonywalne i uruchom je."
  echo 
  echo "In the directory indicated by the user, find all the Executable files and run them."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Ciekawe zadanie. Będzimy potrzebować komend: bash, find, cut i potoków....\nInteresting task. We will need the commands: bash, find, cut, and pipes.\n"
}

hint2() {
  printf "Załóżmy, że pracujemy na katalogu domowym czyli ~ \nLet's assume that we are working on the current directory ie ~\n"
}

hint3() {
  printf "Znajdźmy wszystkie pliki w bieżącym katalogu.\nLet's find all the files in the current directory.\n"
}

hint4() {
  printf "find ~\n"
}

hint5() {
  printf "Znajdźmy wszystkie pliki wykonywalne i odczytywalne w katalogu domowym.\nLet's find all executable and readable files in the home directory.\n"
}

hint6() {
  printf "find ~ -executable -readable\n"
}

hint7() {
  printf "Czasami polecenie find może zakończyć się błędem. Ukryjmy informację o błędzie.\nSometimes the find command may end with an error. Let's hide the error information.\n"
}

hint8() {
  printf "find ~ -executable -readable 2> /dev/null\n"
}

hint9() {
  printf "Co to jest 2>? Co to jest /dev/null? Pytaj jeżeli nie wiesz.\nWhat is 2>? What is /dev/null? Ask if you need.\n"
}

hint10() {
  printf "Widzimy już jakie pliki będziemy chcieli uruchomić. Na tym etapie możemy wyeliminować, o ile wydaje nam się że sa niebezpieczne.\nWe can already see what files we will want to run. At this stage we can eliminate as far as we think they are dangerous.\n"
}

hint11() {
  printf "Pierwsza próba uruchomienia.\nFirst attempt to execute.\n"
}

hint12() {
  printf "\$(find ~ -executable -readable 2> /dev/null)\n"
}

hint13() {
  printf "Coś nie tak. Co się właściwie stało? Pomyśl, może uda Ci się znaleźć odpowiedź.\nSomething is wrong. What actually happened? Think about it, maybe you can find the answer.\n"
}

hint14() {
  printf "Druga próba uruchomienia.\nSecond attempt to execute.\n"
}

hint15() {
  printf "bash -c \"\$(find ~ -executable -readable 2> /dev/null)\"\n"
}

hint16() {
  printf "Przekazaliśmy ten prosty ciąg instrukcji do basha, jakby był zapisany w pliku i bash go wykonał.\nWe passed this simple string of instructions to bash as if it were written in a file and bash executed it\n"
}

hint17() {
  printf "Możemy to jeszcze wzbogacić o opcję -x, aby bash wyświetlał nam informację i wykonywanych instrukcjach. I to wszystko.\nWe can still enrich this with the -x option, so that bash displays us information and executed instructions. And that's it.\n"
}

hint18() {
  printf "bash -xc \"\$(find ~ -executable -readable 2> /dev/null)\"\n"
}

solution() {
  printf "bash -xc \"\$(find ~ -executable -readable 2> /dev/null)\"\n"
}



homework1() {
  printf "Praca domowa 2007_1: Zmodyfikuj rozwiązanie, aby obsługiwało ono więcej katalogów, które będą przeszukiwane. Aktualnie przeszukiwany jest tylko jeden katalog.\nHomework 2007_1: Modify the solution to support more directories to be searched. Currently only one directory is searched.\n"
}

homework2() {
  printf "Praca domowa 2007_2: Zmodyfikuj rozwiązanie, aby obsługiwało ono tyko skrypty i żeby nie były przeszukiwane podkatalogi - użyj polecenia man find.\nHomework 2007_2: Modify the solution so that it handles only scripts and that subdirectories are not searched - use the man find command.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'solution' 'homework1' 'homework2' 

exit 0