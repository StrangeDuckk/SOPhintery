#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 1 | 0 | 0 | 6 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Skopiuj wszystkie pliki z katalogu /etc to katalogu ~/etc (bez podkatalogów), a następnie wyświetl je i następnie usuń wszystkie pliki z rozszerzeniem conf. Nie zwracaj uwagi na komunikaty o błędach, a będzie ich sporo."
  echo 
  echo "Copy all the files from the /etc directory to the ~/etc directory (no subdirectories), then show all the files with the conf extension and next delete all the files with the conf extension. Pay no attention to the error messages, and there will be a lot of them."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Na początku wyświetlmy katalog /etc\nFirst, let's display the /etc directory\n"
}

hint2() {
  printf "ls /etc\n"
}

hint3() {
  printf "Mamy tu dużo różnych plików i katalogów, więc wyświetlmy tylko pliki z rozszerzeniem conf\nWe have a lot of different files and directories here, so let's just display the files with the conf extension\n"
}

hint4() {
  printf "ls /etc/*.conf\n"
}

hint5() {
  printf "Można to zrobić na kilka sposobów, na przykład:\nThis can be done in several ways, for example:\n"
}

hint6() {
  printf "cd /etc\n"
}

hint7() {
  printf "ls *.conf\n"
}

hint8() {
  printf "cd -\n"
}

hint9() {
  printf ", a to z kolei można zapisać jeszcze inaczej, na przykład:\n, which in turn can be written in yet another way, for example:\n"
}

hint10() {
  printf "cd /etc ; ls *.conf ; cd -\n"
}

hint11() {
  printf "Średnik pozwala separować polecenie, gwiazdka reprezentuje wszystkie pliki z danego katalogu, a polecenie cd - powoduje powrót do katalogu w którym byliśmy pierwotnie.\nThe semicolon allows you to separate the command, the asterisk represents all files in a given directory, and the cd - command returns you to the directory where you were originally.\n"
}

hint12() {
  printf "Wróćmy do katalogu domowego\nLet's go back to the home directory\n"
}

hint13() {
  printf "cd ~\n"
}

hint14() {
  printf "Utwórzmy tu katalog etc\nLet's create an etc directory here\n"
}

hint15() {
  printf "mkdir etc\n"
}

hint16() {
  printf "Uważnie analizuj błędy, a może być ich wiele\nCarefully analyze the errors, and there may be many of them\n"
}

hint17() {
  printf "Czasami przydatne mogą być opje danego polecenia -p -v lub -pf. Wykorzystując polecenie man, dowiedz się do czego one służą.\nSometimes the -p -v or -pf options of a given command can be useful. Using the man command, find out what they are for.\n"
}

hint18() {
  printf "man mkdir\n"
}

hint19() {
  printf "Zmieńmy katalog roboczy na nasz katalog docelowy ~/etc.\nLet's change working directory to our target directory ~/etc.\n"
}

hint20() {
  printf "cd ~/etc\n"
}

hint21() {
  printf "Wykonajmy kopię plików z katalogu /etc do katalogu ~/etc.\nLet's make a copy of the files from the /etc directory to the ~/etc directory.\n"
}

hint22() {
  printf "Pierwszy sposób (zakładamy, że jesteśmy w katalogu docelowym)\nThe first way (we assume that we are in the target directory)\n"
}

hint23() {
  printf "cp /etc/* . \n"
}

hint24() {
  printf "Drugi sposób (nie zakładamy, że jesteśmy w katalogu docelowym)\nThe second way (we do not assume that we are in the target directory)\n"
}

hint25() {
  printf "cp /etc/* ~/etc \n"
}

hint26() {
  printf "Wyświetlmy wszystkie pliki z rozszerzeniem conf.\nLet's display all files with the conf extension\n"
}

hint27() {
  printf "Pierwszy sposób (zakładamy, że jesteśmy w katalogu docelowym)\nThe first way (we assume that we are in the target directory)\n"
}

hint28() {
  printf "cat *.conf \n"
}

hint29() {
  printf "Drugi sposób (nie zakładamy, że jesteśmy w katalogu docelowym)\nThe second way (we do not assume that we are in the target directory)\n"
}

hint30() {
  printf "cat ~/etc/*.conf \n"
}

hint31() {
  printf "Usuńmy wszystkie pliki z rozszerzeniem conf.\nLet's delete all files with the conf extension\n"
}

hint32() {
  printf "Pierwszy sposób (zakładamy, że jesteśmy w katalogu docelowym)\nThe first way (we assume that we are in the target directory)\n"
}

hint33() {
  printf "rm *.conf \n"
}

hint34() {
  printf "Drugi sposób (nie zakładamy, że jesteśmy w katalogu docelowym)\nThe second way (we do not assume that we are in the target directory)\n"
}

hint35() {
  printf "rm ~/etc/*.conf \n"
}

hint36() {
  printf "I to wszystko\nThat is all\n"
}

solution() {
  printf "cd ~\nmkdir etc\ncd ~/etc\ncp /etc/* . \ncat *.conf \nrm *.conf \n"
}



homework1() {
  printf "Praca domowa #1006_1: Utwórz spakowane archiwum wszystkich plików conf z katalogu /etc. Archiwum wynikowe ma mieć nazwę /etc_conf.tgz. Do utworzenia archiwum wykorzystaj polecenia tar i gzip Do tego zadania hintera nie będzie.\nHomework #1006_1: Create a zipped archive of all conf files from the /etc directory. The resulting archive is to be named /etc_conf.tgz. Use the tar and gzip commands to create the archive There will be no hinter for this assignment.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'hint30' 'hint31' 'hint32' 'hint33' 'hint34' 'hint35' 'hint36' 'solution' 'homework1' 

exit 0