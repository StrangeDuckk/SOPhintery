#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 1 | 0 | 0 | 8 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Wyświetl wszystkie katalogi z podkatalogami z katalogu /bin i /usr. Zmierz ile czasu zajęła ta operacja."
  echo 
  echo "Display all directories with subdirectories from the /bin and /usr directory. Measure how much time this operation took."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Na początku wykorzystajmy podręcznik man, aby dowiedzieć się jak wyświetlić wszystkie katalogi z podkatalogami\nFirst, let's use the man page to learn how to display all directories with subdirectories\n"
}

hint2() {
  printf "man ls\n"
}

hint3() {
  printf "Słowem kluczowym w tym przypadku jest słowo: recursive\nThe keyword in this case is: recursive\n"
}

hint4() {
  printf "Wciśnij / (slash) wpisz recursive i enter\nPress / (slash) type recursive and enter\n"
}

hint5() {
  printf "Mamy opcję -R. Sprawdźmy ją.\nWe have the -R option. Chceck it.\n"
}

hint6() {
  printf "Pierwszy sposób.\nThe first method\n"
}

hint7() {
  printf "ls -R /bin\nls -R /usr/\n"
}

hint8() {
  printf "Drugi sposób.\nThe second method\n"
}

hint9() {
  printf "ls -R /bin ; ls -R /usr/\n"
}

hint10() {
  printf "Trzeci sposób.\nThe third method\n"
}

hint11() {
  printf "ls -R /bin /usr/\n"
}

hint12() {
  printf "Trudno to kontrolować, dużo tych plików, może warto przetestować to na czymś mniejszym.\nIt's hard to control, a lot of these files, you might want to test it on something smaller\n"
}

hint13() {
  printf "Teraz czas zmierzyć czas wykonania tego polecenia.\nNow it's time to measure the execution time of this command\n"
}

hint14() {
  printf "Do tego celu użyjemy polecenia time. Oczywiście zanim to zrobimy warto zajrzeć tu: man time\nTo do this, we will use the time command. Of course, before doing so, it's worth taking a look here: man time\n"
}

hint15() {
  printf "time ls -R /bin /usr/\n"
}

solution() {
  printf "time ls -R /bin /usr/\n"
}



homework1() {
  printf "Praca domowa #1008_1: To zadanie jest trochę bardziej skomplikowane i wymagać może przejrzenia literatury:\nUruchom polecenie (pewnie domyślasz się co się stanie): asmyk@msh:~\$ sleep 1\n A teraz: asmyk@msh:~\$ time sleep 1\n A teraz uruchommy dwa polecenia sleep i zmierzmy czas ich wykonania: asmyk@msh:~\$ time { sleep 1 ; sleep 1 ; } \n I tutaj jest zadanie: zmieńmy teraz pierwszy średnik w ampersand: asmyk@msh:~\$ time { sleep 1 & sleep 1 ; } \n Potrafisz to wytłumaczyć?\nHomework #1008_1: This assignment is a bit more complicated and may require a literature review: \nRun the command (you can probably guess what will happen): asmyk@msh:~\$ sleep 1\n And now: asmyk@msh:~\$ time sleep 1\n And now let's run two sleep commands and measure their execution time: asmyk@msh:~\$ time { sleep 1 ; sleep 1 ; } \n And here is the task: let's now change the first semicolon in the ampersand: asmyk@msh:~\$ time { sleep 1 & sleep 1 ; } \n Can you explain it?\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'solution' 'homework1' 

exit 0