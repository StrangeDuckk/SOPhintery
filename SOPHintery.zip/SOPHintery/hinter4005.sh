#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 4 | 0 | 0 | 5 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Będzie to bardzo praktyczne, ale i trochę trudne zadanie. Zajmiemy się badaniem wypadków morskich. Niestety zdarzają się one i jeden z nich miał miejsce 19 lipca 2020 w porcie w Gdyni. Holownik Uran uderzył w nabrzeże portowe. Dokładny raport z tego wypadku możecie Państwo znaleźć https://pkbwm.gov.pl/wp-content/uploads/2021/07/Raport-uproszczony-050_20-Uran.pdf. Każda jednostka pływająca wyposażona jest (powinna być) w urządzenie GNSS, raportujące położenie w określonym czasie. Takie urządzenie jest też na holowniku Uran. Przed kolizją zbierało ono współrzędnej położenia statku i czas kiedy pomiar został wykonany. Na potrzeby tego raportu został napisany program w języku Pyton, który na podstawie zebranych współrzędnych i czasów, wyznaczył drogę przebytą przed kolizją i prędkość z jaką poruszał się holownik. Przepisz ten program na basha. Nic nie zmieniaj, po prostu przepisz i przetestuj."
  echo 
  echo "It will be a very practical, but also a bit difficult task. We will investigate maritime accidents. Unfortunately, they happen and one of them took place on July 19, 2020 in the port of Gdynia. The tugboat Uran hit the port wharf. You can find a detailed report of this accident at https://pkbwm.gov.pl/wp-content/uploads/2021/07/Raport-uproszczony-050_20-Uran.pdf. Every vessel is (should be) equipped with a GNSS device, reporting the position at a certain time. Such a device is also on the tug Uranus. Before the collision, it collected the coordinates of the vessel's position and the time when the measurement was taken. For this report, a program was written in the Python language that, based on the collected coordinates and times, calculated the distance traveled before the collision and the speed at which the tug was moving. Rewrite this program into bash. Don't change anything, just rewrite and test.  Compare the results with those provided in the task."
  echo "--------------------------"
  echo 
  echo "Dodatkowe materiały w języku polskim"
  echo ""
  echo "  https://pkbwm.gov.pl/wp-content/uploads/2021/07/Raport-uproszczony-050_20-Uran.pdf"
  echo "  https://pl.wikipedia.org/wiki/Ortodroma"
  echo "  https://pl.wikipedia.org/wiki/Bc_(Unix)"
  echo ""
  echo "Additional materials in English"
  echo ""
  echo "  https://en.wikipedia.org/wiki/Great-circle_distance"
  echo "  https://stackoverflow.com/questions/22437319/how-to-calculate-arccos-in-bash"
  echo "  https://en.wikipedia.org/wiki/Bc_(programming_language)"
}

my_clear() {
  clear
}


hint1() {
  printf "Tak jak napisałem, zadanie nie jest łatwe, ale też nie jest trudne. Wszystko da się napisać.\nAs I wrote, the task is not easy, but it is not difficult either.All can be written.\n"
}

hint2() {
  printf "Popatrzmy na dane wejściowe. Mamy dwa zestawy, jeden po polsku, a drugi po angielsku.\nLet's look at the input data. We have two sets, one in Polish and one in English.\n"
}

hint3() {
  printf " 1 Tabela 1. Tabela zanotowanych wartości pozycji geograficznej holownika w badanym interwale czasu\n 2 LP Szerokość geograficzna [°] Długość geograficzna [°]  Czas wykonania pomiaru pozycji geograficznej [UTC]\n 3 0 54.5415399999945 18.5155166666667 2020-07-19 00:42:49.409185\n 4 1 54.5414899999954 18.5156399985475 2020-07-19 00:42:50.602314\n 5 2 54.5414649996888 18.5156983341175 2020-07-19 00:42:51.773262\n 6 3 54.5414066663375 18.5158233323343 2020-07-19 00:42:53.276554\n 7 4 54.5413533336795 18.5159483351543 2020-07-19 00:42:54.444401\n 8 5 54.5413283332889 18.5160099987932 2020-07-19 00:42:57.008958\n 9 6 54.5412783330292 18.5161316689411 2020-07-19 00:43:00.133719\n10 7 54.5412500000892 18.516194998916 2020-07-19 00:43:01.635874\n11 8 54.5411999997332 18.5163166644608 2020-07-19 00:43:02.963746\n12 9 54.5411766675374 18.5163783327028 2020-07-19 00:43:04.472155\n13 10 54.5411283333478 18.5165033355228 2020-07-19 00:43:06.976943\n14 11 54.5410833336524 18.5166300000757 2020-07-19 00:43:07.517412\n15 12 54.5410583330956 18.5166900019816 2020-07-19 00:43:10.326281\n16 13 54.5410083325036 18.5168150001985 2020-07-19 00:43:11.005441\n17 14 54.5409049991713 18.5170583312882 2020-07-19 00:43:12.059957\n18 15 54.5408566666929 18.5171833341081 2020-07-19 00:43:13.504156\n19 16 54.5408066658527 18.517304999653 2020-07-19 00:43:14.967508\n20 17 54.5407816671602 18.517368334231 2020-07-19 00:43:16.350002\n21 18 54.5407299999547 18.5174916661118 2020-07-19 00:43:17.684374\n22 19 54.540706667489 18.5175516680178 2020-07-19 00:43:20.195617\n23 20 54.5406800004254 18.5176149979927 2020-07-19 00:43:21.190689\n24 21 54.5406049990997 18.5177983317795 2020-07-19 00:43:22.719966\n25 22 54.5405800002831 18.5178633326935 2020-07-19 00:43:24.038723\n26 23 54.5405549994165 18.5179250009355 2020-07-19 00:43:26.540148\n27 24 54.5405083328039 18.5180483328163 2020-07-19 00:43:30.885198\n28 25 54.5404833339278 18.5181100010583 2020-07-19 00:43:32.722326\n29 26 54.5404066659528 18.5182933348451 2020-07-19 00:43:34.236572\n30 27 54.5403583328815 18.518418333062 2020-07-19 00:43:36.174149\n31 28 54.5403333339131 18.518478334968 2020-07-19 00:43:37.571748\n32 29 54.5403083328947 18.5185399986068 2020-07-19 00:43:40.418709\n33 30 54.5402850001868 18.5186049995208 2020-07-19 00:43:43.425432\n34 31 54.5402366669708 18.5187299977377 2020-07-19 00:43:44.819868\n35 32 54.5401883336973 18.5188533342217 2020-07-19 00:43:46.771391\n36 33 54.5401650009205 18.5189166687997 2020-07-19 00:43:48.442111\n37 34 54.5401383335013 18.5189783324385 2020-07-19 00:43:50.785531\n38 35 54.5400866675122 18.5190999979833 2020-07-19 00:43:51.286644\n39 36 54.5400383340602 18.5192233344673 2020-07-19 00:43:53.295764\n40 37 54.5400100002553 18.5192849981062 2020-07-19 00:43:54.124934\n41 38 54.5399316671159 18.519469998229 2020-07-19 00:43:57.308578\n42 39 54.5399066658503 18.519530000135 2020-07-19 00:43:58.141199\n43 40 54.5398816666039 18.519591668377 2020-07-19 00:44:00.478768\n44 41 54.5398300002884 18.5197133339218 2020-07-19 00:44:01.650046\n45 42 54.5397800002191 18.5198333331306 2020-07-19 00:44:03.672619\n46 43 54.5397283337742 18.5199549986754 2020-07-19 00:44:05.658974\n47 44 54.5396766672636 18.5200733315482 2020-07-19 00:44:06.162039\n48 45 54.5395999998008 18.520249999991 2020-07-19 00:44:09.007489\n49 46 54.5395750003657 18.5203100018969 2020-07-19 00:44:10.846194\n50 47 54.5395216673376 18.5204300011058 2020-07-19 00:44:12.013129\n51 48 54.5394716668888 18.5205500003146 2020-07-19 00:44:14.353421\n52 49 54.539418333725 18.5206650005153 2020-07-19 00:44:16.028147\n53 50 54.5393450004691 18.5208483343021 2020-07-19 00:44:17.195838\n54 51 54.5393216672079 18.520909997941 2020-07-19 00:44:18.197112\n55 52 54.539300000265 18.520971666183 2020-07-19 00:44:20.542407\n56 53 54.539279999643 18.521035000761 2020-07-19 00:44:21.212484\n57 54 54.539255000011 18.5210933317278 2020-07-19 00:44:23.715173\n58 55 54.539210000275 18.5212183345478 2020-07-19 00:44:26.560206\n59 56 54.5391866669363 18.5212783318506 2020-07-19 00:44:27.892708\n60 57 54.5391400007864 18.5214033346706 2020-07-19 00:44:29.957365\n61 58 54.5391166674075 18.5214649983095 2020-07-19 00:44:31.075719\n62 59 54.5390933340151 18.5215250002155 2020-07-19 00:44:32.415464\n63 60 54.5390149991081 18.5217066676663 2020-07-19 00:44:35.875974\n64 61 54.538989999313 18.5217666649691 2020-07-19 00:44:37.756093\n65 62 54.5389400002445 18.5218900014531 2020-07-19 00:44:40.440123\n66 63 54.5388883327313 18.5220133333339 2020-07-19 00:44:41.436889\n67 64 54.538798332965 18.5222049988008 2020-07-19 00:44:43.027747\n68 65 54.5387749993899 18.5222650007068 2020-07-19 00:44:45.618906\n69 66 54.53875333419 18.5223266643456 2020-07-19 00:44:46.458412\n70 67 54.5387049991517 18.5224466681576 2020-07-19 00:44:48.034621\n71 68 54.5386583324486 18.5225666673664 2020-07-19 00:44:50.969289\n72 69 54.5386166668058 18.5226883329112 2020-07-19 00:44:51.470208\n73 70 54.5385900004049 18.5227950014319 2020-07-19 00:44:52.640704\n"
}

hint4() {
  printf " 1 Table 1. Table of recorded values of the geographic position of the tug during the time interval studied\n 2 LP Latitude [°] Longitude [°]  The time when the measurement of the geographical position is made [UTC]\n 3 0 54.5415399999945 18.5155166666667 2020-07-19 00:42:49.409185\n 4 1 54.5414899999954 18.5156399985475 2020-07-19 00:42:50.602314\n 5 2 54.5414649996888 18.5156983341175 2020-07-19 00:42:51.773262\n 6 3 54.5414066663375 18.5158233323343 2020-07-19 00:42:53.276554\n 7 4 54.5413533336795 18.5159483351543 2020-07-19 00:42:54.444401\n 8 5 54.5413283332889 18.5160099987932 2020-07-19 00:42:57.008958\n 9 6 54.5412783330292 18.5161316689411 2020-07-19 00:43:00.133719\n10 7 54.5412500000892 18.516194998916 2020-07-19 00:43:01.635874\n11 8 54.5411999997332 18.5163166644608 2020-07-19 00:43:02.963746\n12 9 54.5411766675374 18.5163783327028 2020-07-19 00:43:04.472155\n13 10 54.5411283333478 18.5165033355228 2020-07-19 00:43:06.976943\n14 11 54.5410833336524 18.5166300000757 2020-07-19 00:43:07.517412\n15 12 54.5410583330956 18.5166900019816 2020-07-19 00:43:10.326281\n16 13 54.5410083325036 18.5168150001985 2020-07-19 00:43:11.005441\n17 14 54.5409049991713 18.5170583312882 2020-07-19 00:43:12.059957\n18 15 54.5408566666929 18.5171833341081 2020-07-19 00:43:13.504156\n19 16 54.5408066658527 18.517304999653 2020-07-19 00:43:14.967508\n20 17 54.5407816671602 18.517368334231 2020-07-19 00:43:16.350002\n21 18 54.5407299999547 18.5174916661118 2020-07-19 00:43:17.684374\n22 19 54.540706667489 18.5175516680178 2020-07-19 00:43:20.195617\n23 20 54.5406800004254 18.5176149979927 2020-07-19 00:43:21.190689\n24 21 54.5406049990997 18.5177983317795 2020-07-19 00:43:22.719966\n25 22 54.5405800002831 18.5178633326935 2020-07-19 00:43:24.038723\n26 23 54.5405549994165 18.5179250009355 2020-07-19 00:43:26.540148\n27 24 54.5405083328039 18.5180483328163 2020-07-19 00:43:30.885198\n28 25 54.5404833339278 18.5181100010583 2020-07-19 00:43:32.722326\n29 26 54.5404066659528 18.5182933348451 2020-07-19 00:43:34.236572\n30 27 54.5403583328815 18.518418333062 2020-07-19 00:43:36.174149\n31 28 54.5403333339131 18.518478334968 2020-07-19 00:43:37.571748\n32 29 54.5403083328947 18.5185399986068 2020-07-19 00:43:40.418709\n33 30 54.5402850001868 18.5186049995208 2020-07-19 00:43:43.425432\n34 31 54.5402366669708 18.5187299977377 2020-07-19 00:43:44.819868\n35 32 54.5401883336973 18.5188533342217 2020-07-19 00:43:46.771391\n36 33 54.5401650009205 18.5189166687997 2020-07-19 00:43:48.442111\n37 34 54.5401383335013 18.5189783324385 2020-07-19 00:43:50.785531\n38 35 54.5400866675122 18.5190999979833 2020-07-19 00:43:51.286644\n39 36 54.5400383340602 18.5192233344673 2020-07-19 00:43:53.295764\n40 37 54.5400100002553 18.5192849981062 2020-07-19 00:43:54.124934\n41 38 54.5399316671159 18.519469998229 2020-07-19 00:43:57.308578\n42 39 54.5399066658503 18.519530000135 2020-07-19 00:43:58.141199\n43 40 54.5398816666039 18.519591668377 2020-07-19 00:44:00.478768\n44 41 54.5398300002884 18.5197133339218 2020-07-19 00:44:01.650046\n45 42 54.5397800002191 18.5198333331306 2020-07-19 00:44:03.672619\n46 43 54.5397283337742 18.5199549986754 2020-07-19 00:44:05.658974\n47 44 54.5396766672636 18.5200733315482 2020-07-19 00:44:06.162039\n48 45 54.5395999998008 18.520249999991 2020-07-19 00:44:09.007489\n49 46 54.5395750003657 18.5203100018969 2020-07-19 00:44:10.846194\n50 47 54.5395216673376 18.5204300011058 2020-07-19 00:44:12.013129\n51 48 54.5394716668888 18.5205500003146 2020-07-19 00:44:14.353421\n52 49 54.539418333725 18.5206650005153 2020-07-19 00:44:16.028147\n53 50 54.5393450004691 18.5208483343021 2020-07-19 00:44:17.195838\n54 51 54.5393216672079 18.520909997941 2020-07-19 00:44:18.197112\n55 52 54.539300000265 18.520971666183 2020-07-19 00:44:20.542407\n56 53 54.539279999643 18.521035000761 2020-07-19 00:44:21.212484\n57 54 54.539255000011 18.5210933317278 2020-07-19 00:44:23.715173\n58 55 54.539210000275 18.5212183345478 2020-07-19 00:44:26.560206\n59 56 54.5391866669363 18.5212783318506 2020-07-19 00:44:27.892708\n60 57 54.5391400007864 18.5214033346706 2020-07-19 00:44:29.957365\n61 58 54.5391166674075 18.5214649983095 2020-07-19 00:44:31.075719\n62 59 54.5390933340151 18.5215250002155 2020-07-19 00:44:32.415464\n63 60 54.5390149991081 18.5217066676663 2020-07-19 00:44:35.875974\n64 61 54.538989999313 18.5217666649691 2020-07-19 00:44:37.756093\n65 62 54.5389400002445 18.5218900014531 2020-07-19 00:44:40.440123\n66 63 54.5388883327313 18.5220133333339 2020-07-19 00:44:41.436889\n67 64 54.538798332965 18.5222049988008 2020-07-19 00:44:43.027747\n68 65 54.5387749993899 18.5222650007068 2020-07-19 00:44:45.618906\n69 66 54.53875333419 18.5223266643456 2020-07-19 00:44:46.458412\n70 67 54.5387049991517 18.5224466681576 2020-07-19 00:44:48.034621\n71 68 54.5386583324486 18.5225666673664 2020-07-19 00:44:50.969289\n72 69 54.5386166668058 18.5226883329112 2020-07-19 00:44:51.470208\n73 70 54.5385900004049 18.5227950014319 2020-07-19 00:44:52.640704\n"
}

hint5() {
  printf "Nie wygląda to zbyt skomplikowanie. Na podstawie naszych poprzednich zadań powinniśmy umieć odczytać takie dane i podzielić je na szerokość i długość geograficzną, a także podzielić czas na godziny, minuty, sekundy. Na nasze szczęście wszystko się wydarzyło jednego dnia to datę możemy zignorować.\nIt doesn't look too complicated. Based on our previous tasks, we should be able to read such data and divide it into latitude and longitude, and divide time into hours, minutes, seconds. Fortunately for us, everything happened on one day then we can ignore the date.\n"
}

hint6() {
  printf "A teraz popatrzmy na uzyskane wyniki. Również mamy dwa zestawy, jeden po polsku, a drugi po angielsku.\nNow let's look at the results obtained. Also we have two sets, one in Polish and one in English.\n"
}

hint7() {
  printf " 1 Tabela 2. Tabela pomiarów ruchu holownika przed kolizją\n 2 ODCINEK DROGA [M] CZAS [S] PRĘDKOŚĆ [M/S] PRĘDKOŚĆ[WĘZŁY]\n 3 Odcinek 1 [P7 – P0] 63,95 13,55 4,7 9,2\n 4 Odcinek 2 [P14 – P7] 67,67 10,54 6,4 12,5\n 5 Odcinek 3 [P21 – P14] 53,55 10,53 5,1 9,9\n 6 Odcinek 4 [P28 – P21] 53,05 16,38 3,2 6,3\n 7 Odcinek 5 [P35 – P28] 53,31 12,88 4,1 8,0\n 8 Odcinek 6 [P42 – P35] 58,40 12,36 4,7 9,2\n 9 Odcinek 7 [P49 – P42] 71,64 11,54 6,2 12,1\n10 Odcinek 8 [P56 – P49] 42,44 12,76 3,3 6,5\n11 Odcinek 9 [P63 – P56] 64,17 13,07 4,9 9,5\n12 Odcinek 10 [P70 - P63] 60,54 11,2 5,4 10,5\n"
}

hint8() {
  printf " 1 Table 2. Table of measurements of the tugboat movement before the collision.\n 2 SECTION DISTANCE [M] TIME [S] SPEED [M/S] SPEED[KNOTS]\n 3 Section 1 [P7 – P0] 63,95 13,55 4,7 9,2\n 4 Section 2 [P14 – P7] 67,67 10,54 6,4 12,5\n 5 Section 3 [P21 – P14] 53,55 10,53 5,1 9,9\n 6 Section 4 [P28 – P21] 53,05 16,38 3,2 6,3\n 7 Section 5 [P35 – P28] 53,31 12,88 4,1 8,0\n 8 Section 6 [P42 – P35] 58,40 12,36 4,7 9,2\n 9 Section 7 [P49 – P42] 71,64 11,54 6,2 12,1\n10 Section 8 [P56 – P49] 42,44 12,76 3,3 6,5\n11 Section 9 [P63 – P56] 64,17 13,07 4,9 9,5\n12 Section 10 [P70 - P63] 60,54 11,2 5,4 10,5\n"
}

hint9() {
  printf "Jak widać, wyniki podzielone są na odcinki czasowe i zawierają informacje o przebytej drodze i prędkości w określonym odcinku czasowym.\nAs you can see, the results are divided into time segments and contain information about the distance traveled and speed over a specific time segment.\n"
}

hint10() {
  printf "No i czas teraz zajrzeć do programu napisanego w języku Python. Z góry uprzedzam, że nie ja jestem autorem tego programu. Na początku pobieżnie zapoznaj się z tym co Cię czeka, a potem ja coś niecoś wytłumaczę.\nWell, and now it is time to look at the program written in Python. Let me warn you in advance that I am not the author of this program. At first, get a cursory overview of what awaits you, and then I will explain a little something.\n"
}

hint11() {
  printf " 1 #code=UTF-8\n 2 #©2021 Jacek Pietraszkiewicz;\n 3 # A program that recalculates from coordinates and time downloaded from CSV lat[ss.sssss], lon[sss.ssss],\n 4 # time[rrrr,mm,dd,gg,mm,ss,ms]\n 5 # distance, time and speed.\n 6 \n 7 import csv\n 8 import math\n 9 import datetime\n10 import os\n11 \n12 def ortodroma(fi_1_s, la_1_s, fi_2_s, la_2_s):\n13     ortodroma_nm = ((math.acos(math.cos(math.radians(fi_1_s)) * math.cos(math.radians(fi_2_s))\n14     * math.cos((math.radians(la_2_s) - math.radians(la_1_s))) + (math.sin(math.radians(fi_1_s)) *\n15     math.sin(math.radians(fi_2_s)))) / (math.pi * 2 / 360)) * 60)\n16     ortodroma_m = (ortodroma_nm * 1852)\n17     return ortodroma_nm, ortodroma_m\n18 \n19 latitude = list([])\n20 longitude = list([])\n21 time = list([])\n22 \n23 with open('Z:/Python/proby/uran20przeduderzeniem.csv') as csvfile:\n24 readCSV = csv.reader(csvfile, delimiter=\",\")\n25 \n26 for row in readCSV:\n27     try:\n28         latitude.append(float(row[1]))\n29         longitude.append(float(row[2]))\n30         a = int(row[3]) # year\n31         b = int(row[4]) # month\n32         c = int(row[5]) # day\n33         d = int(row[6]) # hour\n34         e = int(row[7]) # minute\n35         f = int(row[8]) # second\n36         g = int(row[9]) # milisecond\n37         g = g / 1000000\n38         g = int(round(g - int(g), 6) * 1000000)\n39         x = datetime.datetime(year=a, month=b, day=c, hour=d, minute=e, second=f, microsecond=g)\n40         time.append(x)\n41     except ValueError:\n42         continue\n43 \n44 D_nM = []\n45 D_m = []\n46 d_t = []\n47 \n48 for i in range(len(latitude) - 1):\n49     x, x_m = ortodroma(latitude[i], longitude[i], latitude[i + 1], longitude[i + 1])\n50     D_nM.append(x)\n51     D_m.append(round(x_m, 2))\n52     d_t.append(time[i + 1] - time[i])\n53 \n54 route = 0\n55 time = d_t[1] - d_t[1]\n56 \n57 for i in range(len(D_m)):\n58     route = route + D_m[i]\n59     time = time + d_t[i]\n60 \n61 s = time.seconds\n62 sm = time.microseconds / 1000000\n63 \n64 time = s + sm\n65 print(\"Route= \", \"{:6.2f}\".format(route), \" m\")\n66 print(\"Time= \", \"{:6.2f}\".format(time), \"s\")\n67 print(\"Average speed [m/s] = \", round((route / time), 1))\n68 print(\"Average speed [kt] = \", round(route / time * 3600 / 1852, 1))\n69 \n70 section = 0\n71 section_t = d_t[1] - d_t[1]\n72 \n73 for i in range(len(D_m)):\n74     section = section + D_m[i]\n75     section_t = section_t + d_t[i]\n76     if i %% 7 == 0 and i > 0:\n77         s = section_t.seconds\n78         sm = section_t.microseconds / 1000000\n79         section_t = s + sm\n80         print(\"SECTION\", i // 7)\n81         print(\"Route= \", \"{:6.2f}\".format(section), \" m\")\n82         print(\"Time= \", \"{:6.2f}\".format(section), \"s\")\n83         print(\"Average speed [m/s] = \", round((section / section_t), 1))\n84         print(\"Average speed [kt] = \", round(section / section_t * 3600 / 1852, 1))\n85         print(\"*\" * 30)\n86         section = 0\n87         section_t = d_t[1] - d_t[1]\n88 \n89 for i in range(len(D_m)):\n90     print(\n91         \"{:2.0f}\".format(i + 1) + \".\",\n92         \"{:5.2f}\".format(D_m[i]),\n93         \"m - \",\n94         \"{:5.2f}\".format((d_t[i].seconds + d_t[i].microseconds / 1000000)),\n95         \"s = \",\n96         \"{:5.2f}\".format(D_m[i] / (d_t[i].seconds + d_t[i].microseconds / 1000000)),\n97         \"m/s [\",\n98         \"{:4.1f}\".format(round(D_m[i] / (d_t[i].seconds + d_t[i].microseconds / 1000000) * 3600 / 1852, 1)), \"kt #]\")\n"
}

hint12() {
  printf "Nie ma tutaj nic strasznego. Operacje arytmetyczne, formatowanie tekstów, pętle, kilka instrukcji warunkowych. Nie powinno być źle. Skupmy sie teraz na szczegółach.\nThere is nothing scary here. Arithmetic operations, text formatting, loops, a few conditional statements. It shouldn't be too bad. Now let's focus on the details.\n"
}

hint13() {
  printf "1 #code=UTF-8\n2 #©2021 Jacek Pietraszkiewicz;\n3 # A program that recalculates from coordinates and time downloaded from CSV lat[ss.sssss], lon[sss.ssss],\n4 # time[rrrr,mm,dd,gg,mm,ss,ms]\n5 # distance, time and speed.\n6 ...\n22 ...\n23 with open('Z:/Python/proby/uran20przeduderzeniem.csv') as csvfile:\n24 readCSV = csv.reader(csvfile, delimiter=\",\")\n25 \n26 for row in readCSV:\n27 ...\n"
}

hint14() {
  printf "Już na wstępie, możemy znaleźć informację, że dane będą odczytywane z pliku CSV. W naszym przypadku moze to być plik z kolumnami pomiędzy które oddzielone są znakiem spacji. W naszym wypadku linie od 23 do 26 możemy napisać w jednej linii, z użyciem pętli foreach oraz polecenia cat, które dostarczy dane do pętli. Użyteczna może być też zmienna IFS. A dokładniej biorąc jest ona chyba tutaj konieczna.\nAlready in the introduction, we can find information that the data will be read from a CSV file. In our case, it can be a file with columns between which are separated by a space character. In our case, lines 23 to 26 can be written in a single line, using a foreach loop and the cat command, which will provide data to the loop. The IFS variable can also be useful. Or more precisely, it is probably necessary here.\n"
}

hint15() {
  printf "11 ...\n12 def ortodroma(fi_1_s, la_1_s, fi_2_s, la_2_s):\n13     ortodroma_nm = ((math.acos(math.cos(math.radians(fi_1_s)) * math.cos(math.radians(fi_2_s))\n14     * math.cos((math.radians(la_2_s) - math.radians(la_1_s))) + (math.sin(math.radians(fi_1_s)) *\n15     math.sin(math.radians(fi_2_s)))) / (math.pi * 2 / 360)) * 60)\n16     ortodroma_m = (ortodroma_nm * 1852)\n17     return ortodroma_nm, ortodroma_m\n18 \n19 ...\n"
}

hint16() {
  printf "Na początku mamy też funkcję, która pobiera współrzędne geograficzne położenia statku i wyznacza odległość z wykorzystaniem wzorów ortodromicznych. Jeżeli jest to dla Ciebie zbyt skomplikowane, można wykorzystać standardowe wzory na wyznaczanie odległości między dwoma punktami na płaszczyźnie. Zwróć uwagę, że funkcja ta zwraca dwie liczby. Da się to zrobić w bashu? Bez problemu.\nFirst, we also have a function that takes the geographic coordinates of the ship's location and determines the distance using orthodromic formulas. If this is too complicated for you, you can use standard formulas for determining the distance between two points on the plane. Note that this function returns two numbers. Can it be done in bash? No problem\n"
}

hint17() {
  printf "18 ...\n19 latitude = list([])\n20 longitude = list([])\n21 time = list([])\n22 ...\n"
}

hint18() {
  printf "Następnie tworzymy trzy listy do przechowywania informacji o szerokości geograficznej, długości geograficznej i czasie pomiaru. Bash również to potrafi.\nThen we create three lists to store information about latitude, longitude and measurement time. Bash can do this as well.\n"
}

hint19() {
  printf "25 ...\n26 for row in readCSV:\n27     try:\n28         latitude.append(float(row[1]))\n29         longitude.append(float(row[2]))\n30         a = int(row[3]) # year\n31         b = int(row[4]) # month\n32         c = int(row[5]) # day\n33         d = int(row[6]) # hour\n34         e = int(row[7]) # minute\n35         f = int(row[8]) # second\n36         g = int(row[9]) # milisecond\n37         g = g / 1000000\n38         g = int(round(g - int(g), 6) * 1000000)\n39         x = datetime.datetime(year=a, month=b, day=c, hour=d, minute=e, second=f, microsecond=g)\n40         time.append(x)\n41     except ValueError:\n42         continue\n43 ...\n"
}

hint20() {
  printf "W pętli wypełniamy te listy wartościami odczytanymi z pliku. Tutaj linia odczytana z pliku jest jakby w tablicy i konkretne wartości odczytujemy z konkretnych komórek. W bashu też to umiemy - mamy komendę cut.\nIn the loop, we fill these lists with values read from the file. Here the line read from the file is as if in an array and we read specific values from specific cells. In bash we also know how to do this - we have the cut command.\n"
}

hint21() {
  printf "42 ...\n43 \n44 D_nM = []\n45 D_m = []\n46 d_t = []\n47 \n48 ...\n"
}

hint22() {
  printf "Tworzymy trzy tablice pomocnicze ...\nWe create three auxiliary arrays.\n"
}

hint23() {
  printf "42 ...\n43 \n44 D_nM = []\n45 D_m = []\n46 d_t = []\n47 \n48 for i in range(len(latitude) - 1):\n49     x, x_m = ortodroma(latitude[i], longitude[i], latitude[i + 1], longitude[i + 1])\n50     D_nM.append(x)\n51     D_m.append(round(x_m, 2))\n52     d_t.append(time[i + 1] - time[i])\n53 \n54 ...\n"
}

hint24() {
  printf "... które wypełniamy wartościami wyznaczonymi przez funkcję: ortodroma. Funkcja ta wyznacza odległość ortodromiczną między dwoma punktami.\n... which we fill with the values determined by the function: ortodroma. This function determines the orthodromic distance between two points.\n"
}

hint25() {
  printf "52 ...\n53 \n54 route = 0\n55 time = d_t[1] - d_t[1]\n56 \n57 for i in range(len(D_m)):\n58     route = route + D_m[i]\n59     time = time + d_t[i]\n60 \n61 ...\n"
}

hint26() {
  printf "Możemy już wyznaczyć całkowitą drogę jaką pokonał statek i ile czasu mu to zajęło.\nWe can already determine the total distance the ship traveled and how long it took.\n"
}

hint27() {
  printf "59 ...\n60 \n61 s = time.seconds\n62 sm = time.microseconds / 1000000\n63 \n64 time = s + sm\n65 print(\"Route= \", \"{:6.2f}\".format(route), \" m\")\n66 print(\"Time= \", \"{:6.2f}\".format(time), \"s\")\n67 print(\"Average speed [m/s] = \", round((route / time), 1))\n68 print(\"Average speed [kt] = \", round(route / time * 3600 / 1852, 1))\n69 \n70 ...\n"
}

hint28() {
  printf "Obliczamy całkowitą przebytą drogę i średnią prędkość, a następnie wyniki wyświetlamy na konsoli.\nWe calculate the total distance traveled and the average speed, and then display the results on the console.\n"
}

hint29() {
  printf "68 ...\n69 \n70 section = 0\n71 section_t = d_t[1] - d_t[1]\n72 \n73 for i in range(len(D_m)):\n74     section = section + D_m[i]\n75     section_t = section_t + d_t[i]\n76     if i %% 7 == 0 and i > 0:\n77         s = section_t.seconds\n78         sm = section_t.microseconds / 1000000\n79         section_t = s + sm\n80         print(\"SECTION\", i // 7)\n81         print(\"Route= \", \"{:6.2f}\".format(section), \" m\")\n82         print(\"Time= \", \"{:6.2f}\".format(section), \"s\")\n83         print(\"Average speed [m/s] = \", round((section / section_t), 1))\n84         print(\"Average speed [kt] = \", round(section / section_t * 3600 / 1852, 1))\n85         print(\"*\" * 30)\n86         section = 0\n87         section_t = d_t[1] - d_t[1]\n88 \n89 ...\n"
}

hint30() {
  printf "Kolejna pętla wyświetla zagregowane dane odnośnie drogi, czasu i prędkości w odcinkach. Każdy odcinek obejmuje 8 kolejnych pomiarów.\nThe next loop displays aggregated data regarding distance, time and speed in sections. Each section includes 8 consecutive measurements.\n"
}

hint31() {
  printf "87 ...\n88 \n89 for i in range(len(D_m)):\n90     print(\n91         \"{:2.0f}\".format(i + 1) + \".\",\n92         \"{:5.2f}\".format(D_m[i]),\n93         \"m - \",\n94         \"{:5.2f}\".format((d_t[i].seconds + d_t[i].microseconds / 1000000)),\n95         \"s = \",\n96         \"{:5.2f}\".format(D_m[i] / (d_t[i].seconds + d_t[i].microseconds / 1000000)),\n97 ...\n"
}

hint32() {
  printf "I to już jest ostatnia pętla. Nie napiszę do czego ona służy. Postaraj się sam to zrobić.\nAnd this is the final loop. I will not write what it is used for. Try to do it yourself.\n"
}

hint33() {
  printf "1 \n2   ####    ####    ####   #####\n3  #    #  #    #  #    #  #    #\n4  #       #    #  #    #  #    #\n5  #  ###  #    #  #    #  #    #\n6  #    #  #    #  #    #  #    #\n7   ####    ####    ####   #####\n8 \n9 \n10  #       #    #   ####   #    #\n11  #       #    #  #    #  #   #\n12  #       #    #  #       ####\n13  #       #    #  #       #  #\n14  #       #    #  #    #  #   #\n15  ######   ####    ####   #    #\n16 \n"
}

solution() {
  printf "1 \n2   ####    ####    ####   #####\n3  #    #  #    #  #    #  #    #\n4  #       #    #  #    #  #    #\n5  #  ###  #    #  #    #  #    #\n6  #    #  #    #  #    #  #    #\n7   ####    ####    ####   #####\n8 \n9 \n10  #       #    #   ####   #    #\n11  #       #    #  #    #  #   #\n12  #       #    #  #       ####\n13  #       #    #  #       #  #\n14  #       #    #  #    #  #   #\n15  ######   ####    ####   #    #\n16 \n"
}



menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'hint30' 'hint31' 'hint32' 'hint33' 'solution' 

exit 0