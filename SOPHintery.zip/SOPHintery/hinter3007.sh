#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 3 | 0 | 0 | 7 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Jest to kontynuacja zadania 3006. Mamy już generator klas. Jeżeli zrobiliście prace domowe, to macie logowanie, a jak nie to nie macie. Teraz czas aby coś zrobić z tymi utworzonymi klasami. Napiszmy walidator, który wstępnie zweryfikuje czy klasy są poprawne. Co będziemy sprawdzać? Czy klasy są w odpowiednich pakietach i czy są klasa publiczna zapisana w pliku z rozszerzeniem java ma odpowiednią nazwę."
  echo 
  echo "This is a continuation of task 3006, and we already have a class generator. If you have done the homework, you have logging, and if not, you don't. Now it's time to do something with these created classes. Let's write a validator that will pre-verify if the classes are correct. What are we going to check? Whether the classes are in the right packages and whether there are public classes stored in a file with a java extension with the right name."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Jak widać zadanie jest bardzo ogólne i rozwojowe. Staram się prezentować bardzo ogólne podejścia, które będzie można w dowolny sposób zmodyfikować, a przez to użyć przy rozwiązywaniu dowolnych problemów. Nie jest to bynajmniej moja zasługa, ale duża w tym zasługa samego basha, czy może  samego podejścia skryptowego. Same skrypty nie są może zbyt wydajne w czasie samego wykonania, ale są za to bardzo elastyczne czyli są bardzo wydajne w momencie tworzenia.\nAs you can see, the task is very general and developmental. I try to present very general approaches, which will be able to be modified in any way, and thus used in solving any problem. This is by no means to my credit, but a big part of it is due to bash itself, or perhaps the scripting approach itself. The scripts themselves may not be very efficient at the time of execution itself, but they are instead very flexible, that is, they are very efficient at the time of creation.\n"
}

hint2() {
  printf "Jako, że specyfikacja tego nie określa, to to napiszmy vlidator, który jako argument otrzyma nazwę pakietu i zwaliduje wszystkie klasy (pliki źródłowe) w tym pakiecie.\nSince the specification does not specify this, let's write a vlidator that receives the name of a package as an argument and validates all classes (source files) in that package.\n"
}

hint3() {
  printf "Napiszę dwa skrypty: validator.sh i java_validator.sh. Pierwszy z nich, będzie wyszukiwał odpowiednie pliki źródłowe we wskazanym pakiecie i wywoływał drugi, który wykona wstępną walidację konkretnego pliku źródłowego.\nI will write two scripts: validator.sh and java_validator.sh. The first one, will search for the appropriate source files in the indicated package and call the second one, which will perform the initial validation of the specific source file.\n"
}

hint4() {
  printf "Zacznijmy od skryptu pierwszego validator.sh.\nLet's start with the first validator.sh script.\n"
}

hint5() {
  printf " 1 #!/bin/bash\n 2 #SCRIPT valdator.sh\n 3 \n 4 [ ! \"\$#\" -eq 1 ] && { echo \"usage: \$0 PACKAGE_NAME \" >&2; exit 1; }\n 5 \n 6 ............\n 7 .................. .......... . .. ... ....\n 8 ..................................\n 9 ..............\n10 \n11 .. ..............\n12 .... . ..... ........ ..... ........... .. ..........  ..\n13 .. ..........\n"
}

hint6() {
  printf "Początek jest dość oczywisty. Sprawdzamy, czy został podany przynajmniej jeden parametr. Oczekujemy że obowiązkowo zostanie podana nazwa pakietu.\nThe beginning is quite obvious. We check that at least one parameter is specified. We expect that it is mandatory to specify the name of the package.\n"
}

hint7() {
  printf " 1 #!/bin/bash\n 2 #SCRIPT valdator.sh\n 3 \n 4 [ ! \"\$#\" -eq 1 ] && { echo \"usage: \$0 PACKAGE_NAME \" >&2; exit 1; }\n 5 \n 6 PACKAGE=\"\$1\"\n 7 PACKAGE_DIR=\$(echo \"\$PACKAGE\" | tr '.' '/')\n 8 EXECUTOR=\"\$(pwd)/validate_java.sh\"\n 9 OLD_DIR=\$(pwd)\n10 \n11 .. ..............\n12 .... . ..... ........ ..... ........... .. ..........  ..\n13 .. ..........\n"
}

hint8() {
  printf "Następnie definiujemy zmienne i inicjalizujemy je danymi wejściowymi, czasami surowymi, a czasami wstępnie przetworzonymi, jak w przypadku nazwy katalogu PACKAGE_DIR, gdzie znajdują się klasy dla danego pakietu. Określiłem też nazwę egzekutora, czyli nazwę skryptu, który będzie wykonywany dla każdej znalezionej klasy w określonym pakiecie.\nThen we define variables and initialize them with input data, sometimes raw and sometimes preprocessed, as in the case of the name of the PACKAGE_DIR directory, where the classes for a given package are located. I also defined the name of the enforcer, which is the name of the script that will be executed for each class found in the specified package.\n"
}

hint9() {
  printf " 1 #!/bin/bash\n 2 #SCRIPT valdator.sh\n 3 \n 4 [ ! \"\$#\" -eq 1 ] && { echo \"usage: \$0 PACKAGE_NAME \" >&2; exit 1; }\n 5 \n 6 PACKAGE=\"\$1\"\n 7 PACKAGE_DIR=\$(echo \"\$PACKAGE\" | tr '.' '/')\n 8 EXECUTOR=\"\$(pwd)/validate_java.sh\"\n 9 OLD_DIR=\$(pwd)\n10 \n11 cd \"\$PACKAGE_DIR\"\n12 find . -name \"*.java\" -exec \"\$EXECUTOR\" {} \"\$PACKAGE\"  \;\n13 cd \"\$OLD_DIR\"\n"
}

hint10() {
  printf "Jak widać przeszedłem do katalogu, w którym znajdują się klasy, które chcemy zwalidować, a następnie wykorzystałem polecenie find do znalezienia klas i wywołania zdefiniowanego egzekutora.\nAs you can see, I changed working directory to the directory where the classes we want to validate are located, and then used the find command to find the classes and call the defined executor.\n"
}

hint11() {
  printf "Teraz szybko przejrzyjmy kod naszego egzekutora, którym będzie ekstremalnie uproszczony walidator kodu źródłowego javy. Jak widać z wywołania powinien on otrzymać dwa parametry: nazwę pliku źródłowego i nazwę pakietu.\nNow let's quickly review the code of our executor, which will be an extremely simplified java source code validator. As you can see from the call, it should receive two parameters: the source file name and the package name.\n"
}

hint12() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 .....................\n 5 .................\n 6 .......\n 7 \n 8 . .. ................... . .. .... .\n 9 . .. ............... . .. .... .\n10 \n11 .... ................... . .... ......... . ......... .. . .... ..... ................. ... ... .... ........... ... . .... . . .\n12 \n13 .................... ................... . ... . ... ..... ....... . ... . .. . . ...... . .. ...\n14 .. . ................ ... . . . ....\n15         .... ..... .... ................. ... ........ ... . .... . .\n16 ..\n17 \n18 ................ ................... . .... .. ..\n19 ................. ........ .............. ...\n20 .. .. . ............. .. ................ .. . ....\n21         .... ..... ................. .... ... ....... ..... ....... ...... ...\n22         ... .......\n23 ..\n24 \n25 ...................... ................... . ... ..... ... . ... ..... ....\n26 .................. ................... . ..... . ....... ...... .................. .... . .. ...\n27 .. . ............... ... . . . ....\n28         .... ..... ................. .... ... ....... ..... ..... ..... ...\n29         ... .......\n30 ..\n31 \n32 .... ........\n"
}

hint13() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 . .. ................... . .. .... .\n 9 . .. ............... . .. .... .\n10 \n11 .... ................... . .... ......... . ......... .. . .... ..... ................. ... ... .... ........... ... . .... . . .\n12 \n13 .................... ................... . ... . ... ..... ....... . ... . .. . . ...... . .. ...\n14 .. . ................ ... . . . ....\n15         .... ..... .... ................. ... ........ ... . .... . .\n16 ..\n17 \n18 ................ ................... . .... .. ..\n19 ................. ........ .............. ...\n20 .. .. . ............. .. ................ .. . ....\n21         .... ..... ................. .... ... ....... ..... ....... ...... ...\n22         ... .......\n23 ..\n24 \n25 ...................... ................... . ... ..... ... . ... ..... ....\n26 .................. ................... . ..... . ....... ...... .................. .... . .. ...\n27 .. . ............... ... . . . ....\n28         .... ..... ................. .... ... ....... ..... ..... ..... ...\n29         ... .......\n30 ..\n31 \n32 .... ........\n"
}

hint14() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 .... ................... . .... ......... . ......... .. . .... ..... ................. ... ... .... ........... ... . .... . . .\n12 \n13 .................... ................... . ... . ... ..... ....... . ... . .. . . ...... . .. ...\n14 .. . ................ ... . . . ....\n15         .... ..... .... ................. ... ........ ... . .... . .\n16 ..\n17 \n18 ................ ................... . .... .. ..\n19 ................. ........ .............. ...\n20 .. .. . ............. .. ................ .. . ....\n21         .... ..... ................. .... ... ....... ..... ....... ...... ...\n22         ... .......\n23 ..\n24 \n25 ...................... ................... . ... ..... ... . ... ..... ....\n26 .................. ................... . ..... . ....... ...... .................. .... . .. ...\n27 .. . ............... ... . . . ....\n28         .... ..... ................. .... ... ....... ..... ..... ..... ...\n29         ... .......\n30 ..\n31 \n32 .... ........\n"
}

hint15() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 echo \"\$JAVA_SOURCE_FILE\" | grep \"\.java\$\" > /dev/null || { echo \"File \$JAVA_SOURCE_FILE has not java extension.\" >&2 ; exit 1 ; }\n12 \n13 .................... ................... . ... . ... ..... ....... . ... . .. . . ...... . .. ...\n14 .. . ................ ... . . . ....\n15         .... ..... .... ................. ... ........ ... . .... . .\n16 ..\n17 \n18 ................ ................... . .... .. ..\n19 ................. ........ .............. ...\n20 .. .. . ............. .. ................ .. . ....\n21         .... ..... ................. .... ... ....... ..... ....... ...... ...\n22         ... .......\n23 ..\n24 \n25 ...................... ................... . ... ..... ... . ... ..... ....\n26 .................. ................... . ..... . ....... ...... .................. .... . .. ...\n27 .. . ............... ... . . . ....\n28         .... ..... ................. .... ... ....... ..... ..... ..... ...\n29         ... .......\n30 ..\n31 \n32 .... ........\n"
}

hint16() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 echo \"\$JAVA_SOURCE_FILE\" | grep \"\.java\$\" > /dev/null || { echo \"File \$JAVA_SOURCE_FILE has not java extension.\" >&2 ; exit 1 ; }\n12 \n13 WORDS_IN_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | rev | cut -d'.' -f2-100 | rev | tr ' ' '\\\n' | wc -l)\n14 if [ \"\$WORDS_IN_NAME\" -ne 1 ] ; then\n15         echo \"File name \$JAVA_SOURCE_FILE has spaces.\" >&2 ; exit 2 ;\n16 fi\n17 \n18 ................ ................... . .... .. ..\n19 ................. ........ .............. ...\n20 .. .. . ............. .. ................ .. . ....\n21         .... ..... ................. .... ... ....... ..... ....... ...... ...\n22         ... .......\n23 ..\n24 \n25 ...................... ................... . ... ..... ... . ... ..... ....\n26 .................. ................... . ..... . ....... ...... .................. .... . .. ...\n27 .. . ............... ... . . . ....\n28         .... ..... ................. .... ... ....... ..... ..... ..... ...\n29         ... .......\n30 ..\n31 \n32 .... ........\n"
}

hint17() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 echo \"\$JAVA_SOURCE_FILE\" | grep \"\.java\$\" > /dev/null || { echo \"File \$JAVA_SOURCE_FILE has not java extension.\" >&2 ; exit 1 ; }\n12 \n13 WORDS_IN_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | rev | cut -d'.' -f2-100 | rev | tr ' ' '\\\n' | wc -l)\n14 if [ \"\$WORDS_IN_NAME\" -ne 1 ] ; then\n15         echo \"File name \$JAVA_SOURCE_FILE has spaces.\" >&2 ; exit 2 ;\n16 fi\n17 \n18 FIRST_LINE=\$(cat \"\$JAVA_SOURCE_FILE\" | head -n 1)\n19 PACKAGE_PATTERN=\" *package *\$PACKAGE_NAME *;\"\n20 if [[ ! \"\$FIRST_LINE\" =~ \$PACKAGE_PATTERN ]] ; then\n21         echo \"File \$JAVA_SOURCE_FILE does not contain valid package name.\" >&2\n22         let ERRNO++\n23 fi\n24 \n25 ...................... ................... . ... ..... ... . ... ..... ....\n26 .................. ................... . ..... . ....... ...... .................. .... . .. ...\n27 .. . ............... ... . . . ....\n28         .... ..... ................. .... ... ....... ..... ..... ..... ...\n29         ... .......\n30 ..\n31 \n32 .... ........\n"
}

hint18() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 echo \"\$JAVA_SOURCE_FILE\" | grep \"\.java\$\" > /dev/null || { echo \"File \$JAVA_SOURCE_FILE has not java extension.\" >&2 ; exit 1 ; }\n12 \n13 WORDS_IN_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | rev | cut -d'.' -f2-100 | rev | tr ' ' '\\\n' | wc -l)\n14 if [ \"\$WORDS_IN_NAME\" -ne 1 ] ; then\n15         echo \"File name \$JAVA_SOURCE_FILE has spaces.\" >&2 ; exit 2 ;\n16 fi\n17 \n18 FIRST_LINE=\$(cat \"\$JAVA_SOURCE_FILE\" | head -n 1)\n19 PACKAGE_PATTERN=\" *package *\$PACKAGE_NAME *;\"\n20 if [[ ! \"\$FIRST_LINE\" =~ \$PACKAGE_PATTERN ]] ; then\n21         echo \"File \$JAVA_SOURCE_FILE does not contain valid package name.\" >&2\n22         let ERRNO++\n23 fi\n24 \n25 JAVA_CLASS_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | cut -d'/' -f2 | cut -d'.' -f1)\n26 PUBLIC_CLASS=\$(cat \"\$JAVA_SOURCE_FILE\" | egrep \" *public +class +\$JAVA_CLASS_NAME[ {/]\" | wc -l)\n27 if [ \"\$PUBLIC_CLASS\" -ne 1 ] ; then\n28         echo \"File \$JAVA_SOURCE_FILE does not contain valid class name\" >&2\n29         let ERRNO++\n30 fi\n31 \n32 .... ........\n"
}

hint19() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 echo \"\$JAVA_SOURCE_FILE\" | grep \"\.java\$\" > /dev/null || { echo \"File \$JAVA_SOURCE_FILE has not java extension.\" >&2 ; exit 1 ; }\n12 \n13 WORDS_IN_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | rev | cut -d'.' -f2-100 | rev | tr ' ' '\\\n' | wc -l)\n14 if [ \"\$WORDS_IN_NAME\" -ne 1 ] ; then\n15         echo \"File name \$JAVA_SOURCE_FILE has spaces.\" >&2 ; exit 2 ;\n16 fi\n17 \n18 FIRST_LINE=\$(cat \"\$JAVA_SOURCE_FILE\" | head -n 1)\n19 PACKAGE_PATTERN=\" *package *\$PACKAGE_NAME *;\"\n20 if [[ ! \"\$FIRST_LINE\" =~ \$PACKAGE_PATTERN ]] ; then\n21         echo \"File \$JAVA_SOURCE_FILE does not contain valid package name.\" >&2\n22         let ERRNO++\n23 fi\n24 \n25 JAVA_CLASS_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | cut -d'/' -f2 | cut -d'.' -f1)\n26 PUBLIC_CLASS=\$(cat \"\$JAVA_SOURCE_FILE\" | egrep \" *public +class +\$JAVA_CLASS_NAME[ {/]\" | wc -l)\n27 if [ \"\$PUBLIC_CLASS\" -ne 1 ] ; then\n28         echo \"File \$JAVA_SOURCE_FILE does not contain valid class name\" >&2\n29         let ERRNO++\n30 fi\n31 \n32 exit \"\$ERRNO\"\n"
}

hint20() {
  printf "No to teraz przejdźmy przez to wolniej. Dodajmy pewne wyjaśnienia, aby było wiadomo co się tutaj dzieje. Uprzedzam, korzystamy tutaj z bardzo prostych mechanizmów, więc nie wszystko da się tutaj sprawdzić.\nWell, now let's go through it more slowly. Let's add some explanations so that it is clear what is going on here. Be warned, we are using very simple mechanisms here, so not everything can be checked here.\n"
}

hint21() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 . .. ................... . .. .... .\n 9 . .. ............... . .. .... .\n10 \n11 .... ................... . .... ......... . ......... .. . .... ..... ................. ... ... .... ........... ... . .... . . .\n12 \n13 .................... ................... . ... . ... ..... ....... . ... . .. . . ...... . .. ...\n14 .. . ................ ... . . . ....\n15         .... ..... .... ................. ... ........ ... . .... . .\n16 ..\n17 \n18 ................ ................... . .... .. ..\n19 ................. ........ .............. ...\n20 .. .. . ............. .. ................ .. . ....\n21         .... ..... ................. .... ... ....... ..... ....... ...... ...\n22         ... .......\n23 ..\n24 \n25 ...................... ................... . ... ..... ... . ... ..... ....\n26 .................. ................... . ..... . ....... ...... .................. .... . .. ...\n27 .. . ............... ... . . . ....\n28         .... ..... ................. .... ... ....... ..... ..... ..... ...\n29         ... .......\n30 ..\n31 \n32 .... ........\n"
}

hint22() {
  printf "Inicjalizujemy zmienne wartościami argumentów wejściowych, oraz zmienną ERROR, która będzie przechowywać zwracany przez skrypt kod błędu.\nWe initialize the variables with the values of the input arguments, and the ERROR variable, which will store the error code returned by the script.\n"
}

hint23() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 .... ................... . .... ......... . ......... .. . .... ..... ................. ... ... .... ........... ... . .... . . .\n12 \n13 .................... ................... . ... . ... ..... ....... . ... . .. . . ...... . .. ...\n14 .. . ................ ... . . . ....\n15         .... ..... .... ................. ... ........ ... . .... . .\n16 ..\n17 \n18 ................ ................... . .... .. ..\n19 ................. ........ .............. ...\n20 .. .. . ............. .. ................ .. . ....\n21         .... ..... ................. .... ... ....... ..... ....... ...... ...\n22         ... .......\n23 ..\n24 \n25 ...................... ................... . ... ..... ... . ... ..... ....\n26 .................. ................... . ..... . ....... ...... .................. .... . .. ...\n27 .. . ............... ... . . . ....\n28         .... ..... ................. .... ... ....... ..... ..... ..... ...\n29         ... .......\n30 ..\n31 \n32 .... ........\n"
}

hint24() {
  printf "Sprawdzamy, czy argumenty wejściowe nie są puste. Jeżeli któryś jest pusty, to kończymy skrypt z kodem błędu 1.\nWe check that the input arguments are not empty. If any are empty, we end the script with error code 1\n"
}

hint25() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 echo \"\$JAVA_SOURCE_FILE\" | grep \"\.java\$\" > /dev/null || { echo \"File \$JAVA_SOURCE_FILE has not java extension.\" >&2 ; exit 1 ; }\n12 \n13 .................... ................... . ... . ... ..... ....... . ... . .. . . ...... . .. ...\n14 .. . ................ ... . . . ....\n15         .... ..... .... ................. ... ........ ... . .... . .\n16 ..\n17 \n18 ................ ................... . .... .. ..\n19 ................. ........ .............. ...\n20 .. .. . ............. .. ................ .. . ....\n21         .... ..... ................. .... ... ....... ..... ....... ...... ...\n22         ... .......\n23 ..\n24 \n25 ...................... ................... . ... ..... ... . ... ..... ....\n26 .................. ................... . ..... . ....... ...... .................. .... . .. ...\n27 .. . ............... ... . . . ....\n28         .... ..... ................. .... ... ....... ..... ..... ..... ...\n29         ... .......\n30 ..\n31 \n32 .... ........\n"
}

hint26() {
  printf "Kolejne sprawdzenie (z użyciem polecenia grep i wyrażeń regularnych) dotyczy rozszerzenia pliku źródłowego. Jeżeli jest ono nieprawidłowe, to skrypt kończy się z kodem błędu 1.\nThe next check (using the grep command and regular expressions) is for the extension of the source file. If it is invalid, the script ends with error code 1.\n"
}

hint27() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 echo \"\$JAVA_SOURCE_FILE\" | grep \"\.java\$\" > /dev/null || { echo \"File \$JAVA_SOURCE_FILE has not java extension.\" >&2 ; exit 1 ; }\n12 \n13 WORDS_IN_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | rev | cut -d'.' -f2-100 | rev | tr ' ' '\\\n' | wc -l)\n14 if [ \"\$WORDS_IN_NAME\" -ne 1 ] ; then\n15         echo \"File name \$JAVA_SOURCE_FILE has spaces.\" >&2 ; exit 2 ;\n16 fi\n17 \n18 ................ ................... . .... .. ..\n19 ................. ........ .............. ...\n20 .. .. . ............. .. ................ .. . ....\n21         .... ..... ................. .... ... ....... ..... ....... ...... ...\n22         ... .......\n23 ..\n24 \n25 ...................... ................... . ... ..... ... . ... ..... ....\n26 .................. ................... . ..... . ....... ...... .................. .... . .. ...\n27 .. . ............... ... . . . ....\n28         .... ..... ................. .... ... ....... ..... ..... ..... ...\n29         ... .......\n30 ..\n31 \n32 .... ........\n"
}

hint28() {
  printf "Tutaj się na chwilę zatrzymam. Chcę sprawdzić czy nazwa pliku zawiera znak spacji spację. Jeżeli tak by było wówczas w nazwie klasy również musiałaby być spacja, a już nie jest prawidłowe. Z naszej nazwy usuwamy rozszerzenie, następnie zamieniamy potencjalne znaki spacji na znaki końca linii i je zliczamy. Powinniśmy mieć dokładnie jeden znak końca linii. Jeżeli mamy ich więcej to mamy sytuację nieprawidłową.\nThis is where I will stop for a moment. I want to check if the file name contains a space character. If it did then there would also have to be a space in the class name, which is no longer correct. We remove the extension from our name, then replace the potential space characters with end-of-line characters and count them. We should have exactly one end-of-line character. If we have more then we have an incorrect situation.\n"
}

hint29() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 echo \"\$JAVA_SOURCE_FILE\" | grep \"\.java\$\" > /dev/null || { echo \"File \$JAVA_SOURCE_FILE has not java extension.\" >&2 ; exit 1 ; }\n12 \n13 WORDS_IN_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | rev | cut -d'.' -f2-100 | rev | tr ' ' '\\\n' | wc -l)\n14 if [ \"\$WORDS_IN_NAME\" -ne 1 ] ; then\n15         echo \"File name \$JAVA_SOURCE_FILE has spaces.\" >&2 ; exit 2 ;\n16 fi\n17 \n18 FIRST_LINE=\$(cat \"\$JAVA_SOURCE_FILE\" | head -n 1)\n19 PACKAGE_PATTERN=\" *package *\$PACKAGE_NAME *;\"\n20 if [[ ! \"\$FIRST_LINE\" =~ \$PACKAGE_PATTERN ]] ; then\n21         echo \"File \$JAVA_SOURCE_FILE does not contain valid package name.\" >&2\n22         let ERRNO++\n23 fi\n24 \n25 ...................... ................... . ... ..... ... . ... ..... ....\n26 .................. ................... . ..... . ....... ...... .................. .... . .. ...\n27 .. . ............... ... . . . ....\n28         .... ..... ................. .... ... ....... ..... ..... ..... ...\n29         ... .......\n30 ..\n31 \n32 .... ........\n"
}

hint30() {
  printf "Kolejny test weryfikuje, czy plik faktycznie należy do sprawdzanego pakietu, nie tylko z racji położenia w odpowiednim katalogu, ale także posiada odpowiedni wpis w swojej treści.\nThe next test verifies that the file actually belongs to the package being checked, not only because it is a file in the right directory, but also has a corresponding entry in its content.\n"
}

hint31() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 echo \"\$JAVA_SOURCE_FILE\" | grep \"\.java\$\" > /dev/null || { echo \"File \$JAVA_SOURCE_FILE has not java extension.\" >&2 ; exit 1 ; }\n12 \n13 WORDS_IN_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | rev | cut -d'.' -f2-100 | rev | tr ' ' '\\\n' | wc -l)\n14 if [ \"\$WORDS_IN_NAME\" -ne 1 ] ; then\n15         echo \"File name \$JAVA_SOURCE_FILE has spaces.\" >&2 ; exit 2 ;\n16 fi\n17 \n18 FIRST_LINE=\$(cat \"\$JAVA_SOURCE_FILE\" | head -n 1)\n19 PACKAGE_PATTERN=\" *package *\$PACKAGE_NAME *;\"\n20 if [[ ! \"\$FIRST_LINE\" =~ \$PACKAGE_PATTERN ]] ; then\n21         echo \"File \$JAVA_SOURCE_FILE does not contain valid package name.\" >&2\n22         let ERRNO++\n23 fi\n24 \n25 JAVA_CLASS_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | cut -d'/' -f2 | cut -d'.' -f1)\n26 PUBLIC_CLASS=\$(cat \"\$JAVA_SOURCE_FILE\" | egrep \" *public +class +\$JAVA_CLASS_NAME[ {/]\" | wc -l)\n27 if [ \"\$PUBLIC_CLASS\" -ne 1 ] ; then\n28         echo \"File \$JAVA_SOURCE_FILE does not contain valid class name\" >&2\n29         let ERRNO++\n30 fi\n31 \n32 .... ........\n"
}

hint32() {
  printf "Ostatni test weryfikuje, czy plik faktycznie zawiera publiczną klasę o nazwie pliku. Sposób weryfikacji jest podobny do poprzedniego. Wykorzystujemy wyrażenia regularne, polecenia grep, wc, cut, oraz instrukcję if. Weź od uwagę, że te testy są uproszczone i prawdopodobnie da się je oszukać, ale nie o to tutaj chodzi.\nThe last test verifies that the file actually contains a public class named file. The verification method is similar to the previous one. We use regular expressions, grep, wc, cut commands, and the if statement. Take from the consideration that these tests are simplified and can probably be cheated, but that's not the point here.\n"
}

hint33() {
  printf " 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 echo \"\$JAVA_SOURCE_FILE\" | grep \"\.java\$\" > /dev/null || { echo \"File \$JAVA_SOURCE_FILE has not java extension.\" >&2 ; exit 1 ; }\n12 \n13 WORDS_IN_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | rev | cut -d'.' -f2-100 | rev | tr ' ' '\\\n' | wc -l)\n14 if [ \"\$WORDS_IN_NAME\" -ne 1 ] ; then\n15         echo \"File name \$JAVA_SOURCE_FILE has spaces.\" >&2 ; exit 2 ;\n16 fi\n17 \n18 FIRST_LINE=\$(cat \"\$JAVA_SOURCE_FILE\" | head -n 1)\n19 PACKAGE_PATTERN=\" *package *\$PACKAGE_NAME *;\"\n20 if [[ ! \"\$FIRST_LINE\" =~ \$PACKAGE_PATTERN ]] ; then\n21         echo \"File \$JAVA_SOURCE_FILE does not contain valid package name.\" >&2\n22         let ERRNO++\n23 fi\n24 \n25 JAVA_CLASS_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | cut -d'/' -f2 | cut -d'.' -f1)\n26 PUBLIC_CLASS=\$(cat \"\$JAVA_SOURCE_FILE\" | egrep \" *public +class +\$JAVA_CLASS_NAME[ {/]\" | wc -l)\n27 if [ \"\$PUBLIC_CLASS\" -ne 1 ] ; then\n28         echo \"File \$JAVA_SOURCE_FILE does not contain valid class name\" >&2\n29         let ERRNO++\n30 fi\n31 \n32 exit \"\$ERRNO\"\n"
}

hint34() {
  printf "Skrypt zwraca wartość zmiennej ERRNO, która na początku ma wartość 0, ale za każdym niepomyślnym testem, jest zwiększana o 1.\nThe script returns the value of the variable ERRNO, which has a value of 0 at the beginning, but with each unsuccessful test, it is increased by 1.\n"
}

solution() {
  printf " 1 #!/bin/bash\n 2 #SCRIPT valdator.sh\n 3 \n 4 [ ! \"\$#\" -eq 1 ] && { echo \"usage: \$0 PACKAGE_NAME \" >&2; exit 1; }\n 5 \n 6 PACKAGE=\"\$1\"\n 7 PACKAGE_DIR=\$(echo \"\$PACKAGE\" | tr '.' '/')\n 8 EXECUTOR=\"\$(pwd)/validate_java.sh\"\n 9 OLD_DIR=\$(pwd)\n10 \n11 cd \"\$PACKAGE_DIR\"\n12 find . -name \"*.java\" -exec \"\$EXECUTOR\" {} \"\$PACKAGE\"  \;\n13 cd \"\$OLD_DIR\"\n 1 ############ JAVA VALIDATOR ###################################################################\n 2 #!/bin/bash\n 3 \n 4 JAVA_SOURCE_FILE=\"\$1\"\n 5 PACKAGE_NAME=\"\$2\"\n 6 ERRNO=0\n 7 \n 8 [ -z \"\$JAVA_SOURCE_FILE\" ] && exit 1\n 9 [ -z \"\$PACKAGE_NAME\" ] && exit 1\n10 \n11 echo \"\$JAVA_SOURCE_FILE\" | grep \"\.java\$\" > /dev/null || { echo \"File \$JAVA_SOURCE_FILE has not java extension.\" >&2 ; exit 1 ; }\n12 \n13 WORDS_IN_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | rev | cut -d'.' -f2-100 | rev | tr ' ' '\\\n' | wc -l)\n14 if [ \"\$WORDS_IN_NAME\" -ne 1 ] ; then\n15         echo \"File name \$JAVA_SOURCE_FILE has spaces.\" >&2 ; exit 2 ;\n16 fi\n17 \n18 FIRST_LINE=\$(cat \"\$JAVA_SOURCE_FILE\" | head -n 1)\n19 PACKAGE_PATTERN=\" *package *\$PACKAGE_NAME *;\"\n20 if [[ ! \"\$FIRST_LINE\" =~ \$PACKAGE_PATTERN ]] ; then\n21         echo \"File \$JAVA_SOURCE_FILE does not contain valid package name.\" >&2\n22         let ERRNO++\n23 fi\n24 \n25 JAVA_CLASS_NAME=\$(echo \"\$JAVA_SOURCE_FILE\" | cut -d'/' -f2 | cut -d'.' -f1)\n26 PUBLIC_CLASS=\$(cat \"\$JAVA_SOURCE_FILE\" | egrep \" *public +class +\$JAVA_CLASS_NAME[ {/]\" | wc -l)\n27 if [ \"\$PUBLIC_CLASS\" -ne 1 ] ; then\n28         echo \"File \$JAVA_SOURCE_FILE does not contain valid class name\" >&2\n29         let ERRNO++\n30 fi\n31 \n32 exit \"\$ERRNO\"\n"
}



homework1() {
  printf "Praca domowa #3007_1: Dopisz walidację na nazwę pakietu: niech zawiera tylko i wyłącznie litery małe i duże.\nHomework #3007_1: Add validation on the package name: have it contain only lowercase and uppercase letters.\n"
}

homework2() {
  printf "Praca domowa #3007_2: Widzimy, że nasze skrypty spełniają powierzone im zadanie, komunikują się ze sobą, ale postaraj się teraz przerobić udostępniony validator javy na podprogramy, tak aby można było go wywołać w następujący sposób: \nHomework #3007_2: We can see that our scripts are fulfilling the task given to them, they are communicating with each other, but now try to convert the provided java validator into subroutines, so that it can be called as follows:\n"
}

homework3() {
  printf " 1 #!/bin/bash\n 2 #JAVA VALIDATOR AFTER REFACTORIZATION\n 3 \n 4 ...\n 5 \n 6 .....................\n 7 .................\n 8 .......\n 9 \n10 ............... ................... ...............\n11 ............... ................... ...............\n12 ................. ................... ...............\n13 .................... ................... ...............\n14 \n15 .... ........\n"
}

homework4() {
  printf " 1 #!/bin/bash\n 2 #JAVA VALIDATOR AFTER REFACTORIZATION\n 3 \n 4 ...\n 5 \n 6 JAVA_SOURCE_FILE=\"\$1\"\n 7 PACKAGE_NAME=\"\$2\"\n 8 ERRNO=0\n 9 \n10 ............... ................... ...............\n11 ............... ................... ...............\n12 ................. ................... ...............\n13 .................... ................... ...............\n14 \n15 .... ........\n"
}

homework5() {
  printf " 1 #!/bin/bash\n 2 #JAVA VALIDATOR AFTER REFACTORIZATION\n 3 \n 4 ...\n 5 \n 6 JAVA_SOURCE_FILE=\"\$1\"\n 7 PACKAGE_NAME=\"\$2\"\n 8 ERRNO=0\n 9 \n10 input_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n11 basic_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n12 package_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n13 java_class_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n14 \n15 .... ........\n"
}

homework6() {
  printf " 1 #!/bin/bash\n 2 #JAVA VALIDATOR AFTER REFACTORIZATION\n 3 \n 4 ...\n 5 \n 6 JAVA_SOURCE_FILE=\"\$1\"\n 7 PACKAGE_NAME=\"\$2\"\n 8 ERRNO=0\n 9 \n10 input_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n11 basic_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n12 package_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n13 java_class_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n14 \n15 exit \"\$ERRNO\"\n"
}

homework7() {
  printf "Musimy napisać (skopiować i lekko przerobić) 4 podprogramy: input_validator, basic_validator, package_validator, java_class_validator. Każdy z nich pobiera 2 argumenty i walidują one odpowiednio: czy istnieją dane wejściowe, czy w nazwie klasy nie ma spacji i czy plik ma rozszerzenie java, czy nazwa pakietu jest odpowiednia, czy nazwa klasy jest odpowiednia.\nWe need to write (copy and slightly rewrite) 4 subroutines: input_validator, basic_validator, package_validator, java_class_validator. Each of them takes 2 arguments and they validate respectively: whether input data exists, whether there are no spaces in the class name and whether the file has java extension, whether the package name is appropriate, whether the class name is appropriate.\n"
}

homework8() {
  printf " 1 #!/bin/bash\n 2 #JAVA VALIDATOR AFTER REFACTORIZATION\n 3 \n 4 ................. .\n 5   ...\n 6   ...... .\n 7 .\n 8 \n 9 ................. .\n10   ...\n11   ...... .\n12 .\n13 \n14 ................... .\n15   ...\n16   ...... .\n17 .\n18 \n19 ...................... .\n20   ...\n21   ...... .\n22 .\n23 \n24 .....................\n25 .................\n26 .......\n27 \n28 ............... ................... ...............\n29 ............... ................... ...............\n30 ................. ................... ...............\n31 .................... ................... ...............\n32 \n33 .... ........\n"
}

homework9() {
  printf " 1 #!/bin/bash\n 2 #JAVA VALIDATOR AFTER REFACTORIZATION\n 3 \n 4 input_validator() {\n 5   ...\n 6   return 0\n 7 }\n 8 \n 9 ................. .\n10   ...\n11   ...... .\n12 .\n13 \n14 ................... .\n15   ...\n16   ...... .\n17 .\n18 \n19 ...................... .\n20   ...\n21   ...... .\n22 .\n23 \n24 .....................\n25 .................\n26 .......\n27 \n28 ............... ................... ...............\n29 ............... ................... ...............\n30 ................. ................... ...............\n31 .................... ................... ...............\n32 \n33 .... ........\n"
}

homework10() {
  printf " 1 #!/bin/bash\n 2 #JAVA VALIDATOR AFTER REFACTORIZATION\n 3 \n 4 input_validator() {\n 5   ...\n 6   return 0\n 7 }\n 8 \n 9 basic_validator() {\n10   ...\n11   return 0\n12 }\n13 \n14 ................... .\n15   ...\n16   ...... .\n17 .\n18 \n19 ...................... .\n20   ...\n21   ...... .\n22 .\n23 \n24 .....................\n25 .................\n26 .......\n27 \n28 ............... ................... ...............\n29 ............... ................... ...............\n30 ................. ................... ...............\n31 .................... ................... ...............\n32 \n33 .... ........\n"
}

homework11() {
  printf " 1 #!/bin/bash\n 2 #JAVA VALIDATOR AFTER REFACTORIZATION\n 3 \n 4 input_validator() {\n 5   ...\n 6   return 0\n 7 }\n 8 \n 9 basic_validator() {\n10   ...\n11   return 0\n12 }\n13 \n14 package_validator() {\n15   ...\n16   return 0\n17 }\n18 \n19 ...................... .\n20   ...\n21   ...... .\n22 .\n23 \n24 .....................\n25 .................\n26 .......\n27 \n28 ............... ................... ...............\n29 ............... ................... ...............\n30 ................. ................... ...............\n31 .................... ................... ...............\n32 \n33 .... ........\n"
}

homework12() {
  printf " 1 #!/bin/bash\n 2 #JAVA VALIDATOR AFTER REFACTORIZATION\n 3 \n 4 input_validator() {\n 5   ...\n 6   return 0\n 7 }\n 8 \n 9 basic_validator() {\n10   ...\n11   return 0\n12 }\n13 \n14 package_validator() {\n15   ...\n16   return 0\n17 }\n18 \n19 java_class_validator() {\n20   ...\n21   return 0\n22 }\n23 \n24 .....................\n25 .................\n26 .......\n27 \n28 ............... ................... ...............\n29 ............... ................... ...............\n30 ................. ................... ...............\n31 .................... ................... ...............\n32 \n33 .... ........\n"
}

homework13() {
  printf " 1 #!/bin/bash\n 2 #JAVA VALIDATOR AFTER REFACTORIZATION\n 3 \n 4 input_validator() {\n 5   ...\n 6   return 0\n 7 }\n 8 \n 9 basic_validator() {\n10   ...\n11   return 0\n12 }\n13 \n14 package_validator() {\n15   ...\n16   return 0\n17 }\n18 \n19 java_class_validator() {\n20   ...\n21   return 0\n22 }\n23 \n24 JAVA_SOURCE_FILE=\"\$1\"\n25 PACKAGE_NAME=\"\$2\"\n26 ERRNO=0\n27 \n28 input_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n29 basic_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n30 package_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n31 java_class_validator \"\$JAVA_SOURCE_FILE\" \"\$PACKAGE_NAME\"\n32 \n33 exit \"\$ERRNO\"\n"
}

homework14() {
  printf "Poniżej masz coś w rodzaju odpowiedzi. Ale coś z nią jest nie tak. Coś musisz zrobić, aby ją odczytać. Co takiego pokręciłem? Czy bash tutaj się przyda?\nBelow you have something like an answer. But something is wrong with it. Something you have to do to read it. What did I screw up like that? Is bash useful here?\n"
}

homework15() {
  printf " 1 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_ssalc_avaj\n 2 ............... ................... .................\n 3 ............... ................... ...............\n 4 ............... ................... ...............\n 5 \n 6 .................\n 7 .....................\n 8 \n 9 .\n10 . ......\n11 ..\n12 . ......\n13 ... ...... ..... ..... ....... ... .... ................. ..... ....\n14 .... . . . ... ............... . ..\n15 \n16 ... .. . .... .................. ...... ....... . ..... . ................... ..................\n17 .... ..... ... . ... ..... ... . ................... ......................\n18 . ......................\n19 \n20 .\n21 . ......\n22 ..\n23 . ......\n24 ... ...... ....... ..... ....... ... .... ................. ..... ....\n25 .... . .. ................ .. ............. . .. ..\n26 \n27 ... .............. ........ .................\n28 .. .. .... . ................... ................\n29 \n30 .................\n31 .....................\n32 . ...................\n33 \n34 .\n35 . ......\n36 ..\n37 . . ...... . ... ........ ... ................. .... ..... ....\n38 .... . . . ... ................ . ..\n39 \n40 ... .. . .... . . .. . ...\n41 . ....... ..... ... . ... . ................... ....................\n42 \n43 . . . ...... . ... ........... .... ... ... ................. ..... .... .\n44 .. ......... . ......... .... . ................... ....\n45 . .................\n46 \n47 .\n48 . ......\n49 . .... .. . ............... .. .\n50 . .... .. . ................... .. .\n51 .................\n52 .....................\n53 . .................\n54 \n55 ...........\n"
}

homework16() {
  printf " 1 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_ssalc_avaj\n 2 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_egakcap\n 3 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_cisab\n 4 ............... ................... ...............\n 5 \n 6 .................\n 7 .....................\n 8 \n 9 .\n10 . ......\n11 ..\n12 . ......\n13 ... ...... ..... ..... ....... ... .... ................. ..... ....\n14 .... . . . ... ............... . ..\n15 \n16 ... .. . .... .................. ...... ....... . ..... . ................... ..................\n17 .... ..... ... . ... ..... ... . ................... ......................\n18 . ......................\n19 \n20 .\n21 . ......\n22 ..\n23 . ......\n24 ... ...... ....... ..... ....... ... .... ................. ..... ....\n25 .... . .. ................ .. ............. . .. ..\n26 \n27 ... .............. ........ .................\n28 .. .. .... . ................... ................\n29 \n30 .................\n31 .....................\n32 . ...................\n33 \n34 .\n35 . ......\n36 ..\n37 . . ...... . ... ........ ... ................. .... ..... ....\n38 .... . . . ... ................ . ..\n39 \n40 ... .. . .... . . .. . ...\n41 . ....... ..... ... . ... . ................... ....................\n42 \n43 . . . ...... . ... ........... .... ... ... ................. ..... .... .\n44 .. ......... . ......... .... . ................... ....\n45 . .................\n46 \n47 .\n48 . ......\n49 . .... .. . ............... .. .\n50 . .... .. . ................... .. .\n51 .................\n52 .....................\n53 . .................\n54 \n55 ...........\n"
}

homework17() {
  printf " 1 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_ssalc_avaj\n 2 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_egakcap\n 3 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_cisab\n 4 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_tupni\n 5 \n 6 .................\n 7 .....................\n 8 \n 9 .\n10 . ......\n11 ..\n12 . ......\n13 ... ...... ..... ..... ....... ... .... ................. ..... ....\n14 .... . . . ... ............... . ..\n15 \n16 ... .. . .... .................. ...... ....... . ..... . ................... ..................\n17 .... ..... ... . ... ..... ... . ................... ......................\n18 . ......................\n19 \n20 .\n21 . ......\n22 ..\n23 . ......\n24 ... ...... ....... ..... ....... ... .... ................. ..... ....\n25 .... . .. ................ .. ............. . .. ..\n26 \n27 ... .............. ........ .................\n28 .. .. .... . ................... ................\n29 \n30 .................\n31 .....................\n32 . ...................\n33 \n34 .\n35 . ......\n36 ..\n37 . . ...... . ... ........ ... ................. .... ..... ....\n38 .... . . . ... ................ . ..\n39 \n40 ... .. . .... . . .. . ...\n41 . ....... ..... ... . ... . ................... ....................\n42 \n43 . . . ...... . ... ........... .... ... ... ................. ..... .... .\n44 .. ......... . ......... .... . ................... ....\n45 . .................\n46 \n47 .\n48 . ......\n49 . .... .. . ............... .. .\n50 . .... .. . ................... .. .\n51 .................\n52 .....................\n53 . .................\n54 \n55 ...........\n"
}

homework18() {
  printf " 1 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_ssalc_avaj\n 2 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_egakcap\n 3 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_cisab\n 4 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_tupni\n 5 \n 6 \"2\$\"=EMAN_EGAKCAP\n 7 \"1\$\"=ELIF_ECRUOS_AVAJ\n 8 \n 9 .\n10 . ......\n11 ..\n12 . ......\n13 ... ...... ..... ..... ....... ... .... ................. ..... ....\n14 .... . . . ... ............... . ..\n15 \n16 ... .. . .... .................. ...... ....... . ..... . ................... ..................\n17 .... ..... ... . ... ..... ... . ................... ......................\n18 . ......................\n19 \n20 .\n21 . ......\n22 ..\n23 . ......\n24 ... ...... ....... ..... ....... ... .... ................. ..... ....\n25 .... . .. ................ .. ............. . .. ..\n26 \n27 ... .............. ........ .................\n28 .. .. .... . ................... ................\n29 \n30 .................\n31 .....................\n32 . ...................\n33 \n34 .\n35 . ......\n36 ..\n37 . . ...... . ... ........ ... ................. .... ..... ....\n38 .... . . . ... ................ . ..\n39 \n40 ... .. . .... . . .. . ...\n41 . ....... ..... ... . ... . ................... ....................\n42 \n43 . . . ...... . ... ........... .... ... ... ................. ..... .... .\n44 .. ......... . ......... .... . ................... ....\n45 . .................\n46 \n47 .\n48 . ......\n49 . .... .. . ............... .. .\n50 . .... .. . ................... .. .\n51 .................\n52 .....................\n53 . .................\n54 \n55 ...........\n"
}

homework19() {
  printf " 1 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_ssalc_avaj\n 2 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_egakcap\n 3 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_cisab\n 4 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_tupni\n 5 \n 6 \"2\$\"=EMAN_EGAKCAP\n 7 \"1\$\"=ELIF_ECRUOS_AVAJ\n 8 \n 9 }\n10 0 nruter\n11 if\n12 1 nruter\n13 ... ...... ..... ..... ....... ... .... ................. ..... ....\n14 .... . . . ... ............... . ..\n15 \n16 ... .. . .... .................. ...... ....... . ..... . ................... ..................\n17 .... ..... ... . ... ..... ... . ................... ......................\n18 . ......................\n19 \n20 .\n21 . ......\n22 ..\n23 . ......\n24 ... ...... ....... ..... ....... ... .... ................. ..... ....\n25 .... . .. ................ .. ............. . .. ..\n26 \n27 ... .............. ........ .................\n28 .. .. .... . ................... ................\n29 \n30 .................\n31 .....................\n32 . ...................\n33 \n34 .\n35 . ......\n36 ..\n37 . . ...... . ... ........ ... ................. .... ..... ....\n38 .... . . . ... ................ . ..\n39 \n40 ... .. . .... . . .. . ...\n41 . ....... ..... ... . ... . ................... ....................\n42 \n43 . . . ...... . ... ........... .... ... ... ................. ..... .... .\n44 .. ......... . ......... .... . ................... ....\n45 . .................\n46 \n47 .\n48 . ......\n49 . .... .. . ............... .. .\n50 . .... .. . ................... .. .\n51 .................\n52 .....................\n53 . .................\n54 \n55 ...........\n"
}

homework20() {
  printf " 1 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_ssalc_avaj\n 2 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_egakcap\n 3 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_cisab\n 4 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_tupni\n 5 \n 6 \"2\$\"=EMAN_EGAKCAP\n 7 \"1\$\"=ELIF_ECRUOS_AVAJ\n 8 \n 9 }\n10 0 nruter\n11 if\n12 1 nruter\n13 2&> \".eman ssalc dilav niatnoc ton seod ELIF_ECRUOS_AVAJ\$ eliF\" ohce\n14 neht ; ] 1 en- \"SSALC_CILBUP\$\" [ fi\n15 \n16 )l- cw | \"]/{ [EMAN_SSALC_AVAJ\$+ ssalc+ cilbup* \" perge | \"ELIF_ECRUOS_AVAJ\$\" tac(\$=SSALC_CILBUP\n17 )1f- '.'d- tuc | 2f- '/'d- tuc | \"ELIF_ECRUOS_AVAJ\$\" ohce(\$=EMAN_SSALC_AVAJ\n18 . ......................\n19 \n20 .\n21 . ......\n22 ..\n23 . ......\n24 ... ...... ....... ..... ....... ... .... ................. ..... ....\n25 .... . .. ................ .. ............. . .. ..\n26 \n27 ... .............. ........ .................\n28 .. .. .... . ................... ................\n29 \n30 .................\n31 .....................\n32 . ...................\n33 \n34 .\n35 . ......\n36 ..\n37 . . ...... . ... ........ ... ................. .... ..... ....\n38 .... . . . ... ................ . ..\n39 \n40 ... .. . .... . . .. . ...\n41 . ....... ..... ... . ... . ................... ....................\n42 \n43 . . . ...... . ... ........... .... ... ... ................. ..... .... .\n44 .. ......... . ......... .... . ................... ....\n45 . .................\n46 \n47 .\n48 . ......\n49 . .... .. . ............... .. .\n50 . .... .. . ................... .. .\n51 .................\n52 .....................\n53 . .................\n54 \n55 ...........\n"
}

homework21() {
  printf " 1 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_ssalc_avaj\n 2 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_egakcap\n 3 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_cisab\n 4 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_tupni\n 5 \n 6 \"2\$\"=EMAN_EGAKCAP\n 7 \"1\$\"=ELIF_ECRUOS_AVAJ\n 8 \n 9 }\n10 0 nruter\n11 if\n12 1 nruter\n13 2&> \".eman ssalc dilav niatnoc ton seod ELIF_ECRUOS_AVAJ\$ eliF\" ohce\n14 neht ; ] 1 en- \"SSALC_CILBUP\$\" [ fi\n15 \n16 )l- cw | \"]/{ [EMAN_SSALC_AVAJ\$+ ssalc+ cilbup* \" perge | \"ELIF_ECRUOS_AVAJ\$\" tac(\$=SSALC_CILBUP\n17 )1f- '.'d- tuc | 2f- '/'d- tuc | \"ELIF_ECRUOS_AVAJ\$\" ohce(\$=EMAN_SSALC_AVAJ\n18 { )(rotadilav_ssalc_avaj\n19 \n20 }\n21 0 nruter\n22 if\n23 1 nruter\n24 ... ...... ....... ..... ....... ... .... ................. ..... ....\n25 .... . .. ................ .. ............. . .. ..\n26 \n27 ... .............. ........ .................\n28 .. .. .... . ................... ................\n29 \n30 .................\n31 .....................\n32 . ...................\n33 \n34 .\n35 . ......\n36 ..\n37 . . ...... . ... ........ ... ................. .... ..... ....\n38 .... . . . ... ................ . ..\n39 \n40 ... .. . .... . . .. . ...\n41 . ....... ..... ... . ... . ................... ....................\n42 \n43 . . . ...... . ... ........... .... ... ... ................. ..... .... .\n44 .. ......... . ......... .... . ................... ....\n45 . .................\n46 \n47 .\n48 . ......\n49 . .... .. . ............... .. .\n50 . .... .. . ................... .. .\n51 .................\n52 .....................\n53 . .................\n54 \n55 ...........\n"
}

homework22() {
  printf " 1 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_ssalc_avaj\n 2 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_egakcap\n 3 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_cisab\n 4 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_tupni\n 5 \n 6 \"2\$\"=EMAN_EGAKCAP\n 7 \"1\$\"=ELIF_ECRUOS_AVAJ\n 8 \n 9 }\n10 0 nruter\n11 if\n12 1 nruter\n13 2&> \".eman ssalc dilav niatnoc ton seod ELIF_ECRUOS_AVAJ\$ eliF\" ohce\n14 neht ; ] 1 en- \"SSALC_CILBUP\$\" [ fi\n15 \n16 )l- cw | \"]/{ [EMAN_SSALC_AVAJ\$+ ssalc+ cilbup* \" perge | \"ELIF_ECRUOS_AVAJ\$\" tac(\$=SSALC_CILBUP\n17 )1f- '.'d- tuc | 2f- '/'d- tuc | \"ELIF_ECRUOS_AVAJ\$\" ohce(\$=EMAN_SSALC_AVAJ\n18 { )(rotadilav_ssalc_avaj\n19 \n20 }\n21 0 nruter\n22 if\n23 1 nruter\n24 2&> \".eman egakcap dilav niatnoc ton seod ELIF_ECRUOS_AVAJ\$ eliF\" ohce\n25 neht ; ]] NRETTAP_EGAKCAP\$ ~= \"ENIL_TSRIF\$\" ! [[ fi\n26 \n27 \";* EMAN_EGAKCAP\$* egakcap* \"=NRETTAP_EGAKCAP\n28 )1 n- daeh | \"ELIF_ECRUOS_AVAJ\$\" tac(\$=ENIL_TSRIF\n29 \n30 \"2\$\"=EMAN_EGAKCAP\n31 .....................\n32 . ...................\n33 \n34 .\n35 . ......\n36 ..\n37 . . ...... . ... ........ ... ................. .... ..... ....\n38 .... . . . ... ................ . ..\n39 \n40 ... .. . .... . . .. . ...\n41 . ....... ..... ... . ... . ................... ....................\n42 \n43 . . . ...... . ... ........... .... ... ... ................. ..... .... .\n44 .. ......... . ......... .... . ................... ....\n45 . .................\n46 \n47 .\n48 . ......\n49 . .... .. . ............... .. .\n50 . .... .. . ................... .. .\n51 .................\n52 .....................\n53 . .................\n54 \n55 ...........\n"
}

homework23() {
  printf " 1 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_ssalc_avaj\n 2 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_egakcap\n 3 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_cisab\n 4 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_tupni\n 5 \n 6 \"2\$\"=EMAN_EGAKCAP\n 7 \"1\$\"=ELIF_ECRUOS_AVAJ\n 8 \n 9 }\n10 0 nruter\n11 if\n12 1 nruter\n13 2&> \".eman ssalc dilav niatnoc ton seod ELIF_ECRUOS_AVAJ\$ eliF\" ohce\n14 neht ; ] 1 en- \"SSALC_CILBUP\$\" [ fi\n15 \n16 )l- cw | \"]/{ [EMAN_SSALC_AVAJ\$+ ssalc+ cilbup* \" perge | \"ELIF_ECRUOS_AVAJ\$\" tac(\$=SSALC_CILBUP\n17 )1f- '.'d- tuc | 2f- '/'d- tuc | \"ELIF_ECRUOS_AVAJ\$\" ohce(\$=EMAN_SSALC_AVAJ\n18 { )(rotadilav_ssalc_avaj\n19 \n20 }\n21 0 nruter\n22 if\n23 1 nruter\n24 2&> \".eman egakcap dilav niatnoc ton seod ELIF_ECRUOS_AVAJ\$ eliF\" ohce\n25 neht ; ]] NRETTAP_EGAKCAP\$ ~= \"ENIL_TSRIF\$\" ! [[ fi\n26 \n27 \";* EMAN_EGAKCAP\$* egakcap* \"=NRETTAP_EGAKCAP\n28 )1 n- daeh | \"ELIF_ECRUOS_AVAJ\$\" tac(\$=ENIL_TSRIF\n29 \n30 \"2\$\"=EMAN_EGAKCAP\n31 \"1\$\"=ELIF_ECRUOS_AVAJ\n32 { )(rotadilav_egakcap\n33 \n34 }\n35 0 nruter\n36 if\n37 ; 2 nruter ; 2&> \".secaps sah ELIF_ECRUOS_AVAJ\$ eman eliF\" ohce\n38 neht ; ] 1 en- \"EMAN_NI_SDROW\$\" [ fi\n39 \n40 ... .. . .... . . .. . ...\n41 . ....... ..... ... . ... . ................... ....................\n42 \n43 . . . ...... . ... ........... .... ... ... ................. ..... .... .\n44 .. ......... . ......... .... . ................... ....\n45 . .................\n46 \n47 .\n48 . ......\n49 . .... .. . ............... .. .\n50 . .... .. . ................... .. .\n51 .................\n52 .....................\n53 . .................\n54 \n55 ...........\n"
}

homework24() {
  printf " 1 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_ssalc_avaj\n 2 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_egakcap\n 3 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_cisab\n 4 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_tupni\n 5 \n 6 \"2\$\"=EMAN_EGAKCAP\n 7 \"1\$\"=ELIF_ECRUOS_AVAJ\n 8 \n 9 }\n10 0 nruter\n11 if\n12 1 nruter\n13 2&> \".eman ssalc dilav niatnoc ton seod ELIF_ECRUOS_AVAJ\$ eliF\" ohce\n14 neht ; ] 1 en- \"SSALC_CILBUP\$\" [ fi\n15 \n16 )l- cw | \"]/{ [EMAN_SSALC_AVAJ\$+ ssalc+ cilbup* \" perge | \"ELIF_ECRUOS_AVAJ\$\" tac(\$=SSALC_CILBUP\n17 )1f- '.'d- tuc | 2f- '/'d- tuc | \"ELIF_ECRUOS_AVAJ\$\" ohce(\$=EMAN_SSALC_AVAJ\n18 { )(rotadilav_ssalc_avaj\n19 \n20 }\n21 0 nruter\n22 if\n23 1 nruter\n24 2&> \".eman egakcap dilav niatnoc ton seod ELIF_ECRUOS_AVAJ\$ eliF\" ohce\n25 neht ; ]] NRETTAP_EGAKCAP\$ ~= \"ENIL_TSRIF\$\" ! [[ fi\n26 \n27 \";* EMAN_EGAKCAP\$* egakcap* \"=NRETTAP_EGAKCAP\n28 )1 n- daeh | \"ELIF_ECRUOS_AVAJ\$\" tac(\$=ENIL_TSRIF\n29 \n30 \"2\$\"=EMAN_EGAKCAP\n31 \"1\$\"=ELIF_ECRUOS_AVAJ\n32 { )(rotadilav_egakcap\n33 \n34 }\n35 0 nruter\n36 if\n37 ; 2 nruter ; 2&> \".secaps sah ELIF_ECRUOS_AVAJ\$ eman eliF\" ohce\n38 neht ; ] 1 en- \"EMAN_NI_SDROW\$\" [ fi\n39 \n40 )l- cw | 'n\' ' ' rt | ver\n41 | 001-2f- '.'d- tuc | ver | \"ELIF_ECRUOS_AVAJ\$\" ohce(\$=EMAN_NI_SDROW\n42 \n43 } ; 2 nruter ; 2&> \".noisnetxe avaj ton sah ELIF_ECRUOS_AVAJ\$ eliF\" ohce {\n44 || llun/ved/ > \"\$avaj.\" perg | \"ELIF_ECRUOS_AVAJ\$\" ohce\n45 { )(rotadilav_cisab\n46 \n47 }\n48 . ......\n49 . .... .. . ............... .. .\n50 . .... .. . ................... .. .\n51 .................\n52 .....................\n53 . .................\n54 \n55 ...........\n"
}

homework25() {
  printf " 1 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_ssalc_avaj\n 2 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_egakcap\n 3 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_cisab\n 4 \"EMAN_EGAKCAP\$\" \"ELIF_ECRUOS_AVAJ\$\" rotadilav_tupni\n 5 \n 6 \"2\$\"=EMAN_EGAKCAP\n 7 \"1\$\"=ELIF_ECRUOS_AVAJ\n 8 \n 9 }\n10 0 nruter\n11 if\n12 1 nruter\n13 2&> \".eman ssalc dilav niatnoc ton seod ELIF_ECRUOS_AVAJ\$ eliF\" ohce\n14 neht ; ] 1 en- \"SSALC_CILBUP\$\" [ fi\n15 \n16 )l- cw | \"]/{ [EMAN_SSALC_AVAJ\$+ ssalc+ cilbup* \" perge | \"ELIF_ECRUOS_AVAJ\$\" tac(\$=SSALC_CILBUP\n17 )1f- '.'d- tuc | 2f- '/'d- tuc | \"ELIF_ECRUOS_AVAJ\$\" ohce(\$=EMAN_SSALC_AVAJ\n18 { )(rotadilav_ssalc_avaj\n19 \n20 }\n21 0 nruter\n22 if\n23 1 nruter\n24 2&> \".eman egakcap dilav niatnoc ton seod ELIF_ECRUOS_AVAJ\$ eliF\" ohce\n25 neht ; ]] NRETTAP_EGAKCAP\$ ~= \"ENIL_TSRIF\$\" ! [[ fi\n26 \n27 \";* EMAN_EGAKCAP\$* egakcap* \"=NRETTAP_EGAKCAP\n28 )1 n- daeh | \"ELIF_ECRUOS_AVAJ\$\" tac(\$=ENIL_TSRIF\n29 \n30 \"2\$\"=EMAN_EGAKCAP\n31 \"1\$\"=ELIF_ECRUOS_AVAJ\n32 { )(rotadilav_egakcap\n33 \n34 }\n35 0 nruter\n36 if\n37 ; 2 nruter ; 2&> \".secaps sah ELIF_ECRUOS_AVAJ\$ eman eliF\" ohce\n38 neht ; ] 1 en- \"EMAN_NI_SDROW\$\" [ fi\n39 \n40 )l- cw | 'n\' ' ' rt | ver\n41 | 001-2f- '.'d- tuc | ver | \"ELIF_ECRUOS_AVAJ\$\" ohce(\$=EMAN_NI_SDROW\n42 \n43 } ; 2 nruter ; 2&> \".noisnetxe avaj ton sah ELIF_ECRUOS_AVAJ\$ eliF\" ohce {\n44 || llun/ved/ > \"\$avaj.\" perg | \"ELIF_ECRUOS_AVAJ\$\" ohce\n45 { )(rotadilav_cisab\n46 \n47 }\n48 0 nruter\n49 1 tixe && ] \"EMAN_EGAKCAP\$\" z- [\n50 1 tixe && ] \"ELIF_ECRUOS_AVAJ\$\" z- [\n51 \"2\$\"=EMAN_EGAKCAP\n52 \"1\$\"=ELIF_ECRUOS_AVAJ\n53 { )(rotadilav_tupni\n54 \n55 hsab/nib/!#\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'hint30' 'hint31' 'hint32' 'hint33' 'hint34' 'solution' 'homework1' 'homework2' 'homework3' 'homework4' 'homework5' 'homework6' 'homework7' 'homework8' 'homework9' 'homework10' 'homework11' 'homework12' 'homework13' 'homework14' 'homework15' 'homework16' 'homework17' 'homework18' 'homework19' 'homework20' 'homework21' 'homework22' 'homework23' 'homework24' 'homework25' 

exit 0