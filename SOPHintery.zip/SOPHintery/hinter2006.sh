#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 2 | 0 | 0 | 6 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Napisz ciąg poleceń, które spowodują zamianę pierwszej połowy linii z wskazanego pliku z drugą połową linii tegoż pliku. Nie zwracamy uwagi na to czy plik ma parzystą liczbę linii czy nie."
  echo 
  echo "Write a sequence of commands that will cause the first half of a line from the indicated file to be swapped with the second half of a line of that file. We do not pay attention to whether the plilk has an even number of lines or not."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Do tego zadania będziemy potrzebowali komend wc, cat, tail, head i operatorów | i > lub <\nFor this task we will need the commands wc, cat, tail, head and the operators | and > or >>\n"
}

hint2() {
  printf "Załóżmy, że wskazany plik ma nazwę INPUT_FILE.TXT\nLet's assume that the indicated file is named INPUT_FILE.TXT\n"
}

hint3() {
  printf "Policzmy całkowitą liczbę linii (a dokładniej liczbę znaków końca linii) w tym pliku.\nLet's count the total number of lines (or more precisely, the number of end-of-line characters) in this file.\n"
}

hint4() {
  printf "wc -l INPUT_FILE.TXT\n"
}

hint5() {
  printf "Zapiszmy ten wynik do zmiennej N\nLet's write this result to the variable N\n"
}

hint6() {
  printf "N=\$(wc -l INPUT_FILE.TXT)\n"
}

hint7() {
  printf "Podzielmy to N przez 2 i wynik zapiszmy do zmiennej K.\nLet's divide this N by 2 and write the results into the variable K.\n"
}

hint8() {
  printf "let K=N/2\n"
}

hint9() {
  printf "... lub ...\n... or ...\n"
}

hint10() {
  printf "K=\$((N/2))\n"
}

hint11() {
  printf "... lub ...\n... or ...\n"
}

hint12() {
  printf "K=\$(expr \$N / 2)\n"
}

hint13() {
  printf "... lub może jeszcze jakoś inaczej ale nie wiem jak.\n... or maybe some other way but I don't know how.\n"
}

hint14() {
  printf "Teraz wyświetlmy pierwszą połowę pliku na konsoli (K pierwszych linii).\nNow let's display the first half of the file on the console (K first lines).\n"
}

hint15() {
  printf "head -n \$K INPUT_FILE.TXT\n"
}

hint16() {
  printf "Teraz wyświetlmy drugą połowę pliku na konsoli (K ostatnich linii).\nNow let's display the second half of the file on the console (K last lines).\n"
}

hint17() {
  printf "tail -n \$K INPUT_FILE.TXT\n"
}

hint18() {
  printf "Połówki te zapiszmy do plików pomocniczych. Ale najpierw musimy wymyśleć jakieś, w miarę unikalne, nazwy dla tych plików i zapiszmy je do zmiennych.\nLet's save these halves to auxiliary files. But first we need to come up with some, reasonably unique, names for these files and let's save them to variables.\n"
}

hint19() {
  printf "HALF_UP=\$(echo /tmp/UP\$\$asmyk\$(date) | tr ' ' '_')\nHALF_DOWN=\$(echo /tmp/DOWN\$\$asmyk\$(date) | tr ' ' '_')\necho \"\$HALF_UP\"\necho \"\$HALF_DOWN\"\n"
}

hint20() {
  printf "head -n \$K INPUT_FILE.TXT > \"\$HALF_UP\"\ntail -n \$K INPUT_FILE.TXT > \"\$HALF_DOWN\"\n"
}

hint21() {
  printf "Połówki te zapiszmy z powrotem do naszego pliku wejsciowego, ale w odwrotnej kolejności.\nLet's write these halves back into our input file, but in reverse order.\n"
}

hint22() {
  printf "cat \"\$HALF_DOWN\" > INPUT_FILE.TXT\ncat \"\$HALF_UP\" >> INPUT_FILE.TXT\n"
}

hint23() {
  printf "Zwróć uwagę na różnice w operatorach zapisu. Raz użyłem > a drugi raz >>.\nNote the differences in the notation operators. I used > once and >> the other time.\n"
}

hint24() {
  printf "Na zakończenie kasujemy nasze pliki pomocnicze.\nFinally, we delete our auxiliary files.\n"
}

hint25() {
  printf "rm \"\$HALF_DOWN\"\nrm \"\$HALF_UP\"\n"
}

solution() {
  printf "HALF_UP=\$(echo /tmp/UP\$\$asmyk\$(date) | tr ' ' '_')\nHALF_DOWN=\$(echo /tmp/DOWN\$\$asmyk\$(date) | tr ' ' '_')\necho \"\$HALF_UP\"\necho \"\$HALF_DOWN\"\nhead -n \$K INPUT_FILE.TXT > \"\$HALF_UP\"\ntail -n \$K INPUT_FILE.TXT > \"\$HALF_DOWN\"\ncat \"\$HALF_DOWN\" > INPUT_FILE.TXT\ncat \"\$HALF_UP\" >> INPUT_FILE.TXT\nrm \"\$HALF_DOWN\"\nrm \"\$HALF_UP\"\n"
}



homework1() {
  printf "Praca domowa 2006_1: Rozwiąż to samo zadanie, ale zamień pierwszą jedną trzecią linii z ostatnią jedną trzecią linii. W jednej trzeciej linii, która nie była zamieniana, zamień linie kolejnością. Przydatne może być polecenie tac.\nHomework 2006_1: Solve the same task, but swap the first one-third line with the last one-third line. In the one-third line that was not swapped, swap the lines in order. You may find the tac command useful.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'solution' 'homework1' 

exit 0