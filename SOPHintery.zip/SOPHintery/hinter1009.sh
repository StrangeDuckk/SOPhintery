#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 1 | 0 | 0 | 9 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Z pewnością na swoim dysku Z masz jakieś pliki java i pliki tekstowe. Wyświetl ile linii ma każdy z nich. Zrób to tylko dla wskazanych przez siebie katalogów."
  echo 
  echo "Surely you have some java files on your Z drive. Display how many lines each of them has. Do this only for the directories you indicate."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Na początku wykorzystajmy podręcznik man, aby dowiedzieć się jak policzyć linie we wskazanym pliku z wykorzystaniem polecenia wc.\nFirst, let's use the man page to learn how to count the lines in the indicated file using the wc command.\n"
}

hint2() {
  printf "man wc\n"
}

hint3() {
  printf "Bez trudu znajdujemy opcję -l, która umożliwia uzyskanie informacji o liczba znaków nowej linii w strumieniu wejściowym\nWe easily find the -l option to get information about the number of newline characters in the input stream\n"
}

hint4() {
  printf "wc -l\n"
}

hint5() {
  printf "No to teraz pytanie, skąd wziąć ten strumień wejściowy?\nWell, now the question is, where to get this input stream?\n"
}

hint6() {
  printf "Odpowiedź jest prosta, można to uzyskać na kilka sposobów. Teraz pokażę jeden z nich.\nThe answer is simple, it can be achieved in several ways. Now I will show one of them.\n"
}

hint7() {
  printf "Po prostu wskazujemy jawnie nazwę lub nazwy plików, które chcemy przetworzyć.\nWe simply indicate explicitly the name or names of the files we want to process\n"
}

hint8() {
  printf "wc -l plik1.java dir/plik2.java dir2/plik3.java\n"
}

hint9() {
  printf "Poprzednim polecenie wygeneruje nam prosty raport o liczbie linii w trzech wskazanych plikach.\nThe preceding command will generate us a simple report on the number of lines in the three indicated files.\n"
}

hint10() {
  printf "Uogólniamy nasze 'zapytanie' i zamiast specyfikować konkretne nazwy plików odwołamy się do wszystkich plików spełniających nasze wymaganie - java i txt.\nWe generalize our 'query' and instead of specifying specific file names we will refer to all files that meet our requirement - java and txt.\n"
}

hint11() {
  printf "wc -l *.java *.txt dir/*.java dir/*.txt dir2/*.java dir2/*.txt\n"
}

hint12() {
  printf "Upraszczamy nasze rozwiązanie.\nWe simplify our solution\n"
}

hint13() {
  printf "wc -l *.{java,txt}  dir/*.{java,txt} dir2/*.{java,txt}\n"
}

hint14() {
  printf "I jeszcze upraszczamy ...\nAnd we're simplifying a bit more ...\n"
}

hint15() {
  printf "wc -l {.,dir,dir2}/*.{java,txt}\n"
}

solution() {
  printf "wc -l {.,dir,dir2}/*.{java,txt}\n"
}



homework1() {
  printf "Praca domowa #1009_1: Ze strony https://www.lipsum.com/feed/html ściągnij 50 paragrafów tekstu Lorem ipsum i zapisz je w pliku tekstowym. Usuń ręcznie puste linie (Jak potrafisz to możesz usunąć automatycznie) i policz te które pozostały. Policz również i znaki i słowa. Na dole strony mamy krótki raport z liczby linii, słów i znaków. Czy polecenie wc dokładnie tak policzyło jak na stronie? Jeżeli nie, wytłumacz dlaczego nie.\nHomework #1009_1: From https://www.lipsum.com/feed/html download 50 paragraphs of Lorem ipsum text and save them in a text file. Remove the blank lines manually (If you can, you can remove them automatically) and count the ones that remain. Count also and characters and words. At the bottom of the page we have a short report of the number of lines, words and characters. Did the wc command count exactly as shown on the page? If not, explain why not.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'solution' 'homework1' 

exit 0