#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 3 | 0 | 0 | 6 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Jest to kontynuacja zadania 3005. Uzupełnij powstały skrypt o  dodatkową funkcjonalność, a mianowicie skrypt może pobrać dodatkowy argument -s (--silent), który będzie przełączał skrypt w tryb cichy to znaczy nie będa raportowane żadne komunikaty na konsolę."
  echo 
  echo "This is a continuation of task 3005. Complete the resulting script with additional functionality, namely the script can take an additional argument -s (--silent), which will put the script into silent mode that is, no messages will be reported to the console."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Naszym skryptem wejściowym będzie poniższy skrypt i jego trochę zmodyfikujemy.\nOur input script will be the following script and we will modify it a bit.\n"
}

hint2() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 CONFIG_FILE=\"gen.conf\"\n 6 PACKAGE_NAME=\"\$1\"\n 7 JAVA_CLASS_NAME=\"\$2\"\n 8 \n 9 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n10 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n11 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] && { echo \"Config file is not available\" >&2 ; exit 2 ; }\n12 \n13 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null && echo 'T' || echo 'F' )\n14 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  && echo 'T' || echo 'F' )\n15 \n16 [ \"\$GEN_MAIN\" = 'T' ] && echo \"Generator will create main fynction \"\n17 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] && echo \"Generator will create hello world code\"\n18 \n19 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n20 FILE=\"\$JAVA_CLASS_NAME.java\"\n21 \n22 mkdir -p \"\$DIR\" 2> /dev/null\n23 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n24 \n25 (\n26 echo \"package \$PACKAGE_NAME;\"\n27 echo\n28 echo \"public class \$JAVA_CLASS_NAME {\"\n29 echo\n30 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n31   echo \"  public static coid main(String[]args) {\"\n32   if [ \"\$GEN_HELLO\" = \"T\" ] ;then\n33     echo\n34     echo \"    System.out.println(\"Hello world\")\"\n35     echo\n36   fi\n37   echo \"  }\"\n38 fi\n39 echo\n40 echo \"}\"\n41 ) > \"\$DIR/\$FILE\"\n"
}

hint3() {
  printf "Wprowadzając kolejny argument musimy zmienić warunki pracy naszego skryptu, czyli nie wymagamy już koniecznie istnienia dokładnie dwóch argumentów, ale nie może być tez ich mniej jak dwa.\nIntroducing another argument, we must change the conditions of our script, that is, we no longer necessarily require the existence of exactly two arguments, but there can also be no less than two.\n"
}

hint4() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ ! \"\$#\" -eq 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME\" >&2; exit 1; }\n 4 \n 5 ......................\n 6 .................\n 7 ....................\n 8 \n 9 . .. ............... . .. . .... ........ .... .. ........ . .... ..  .\n10 . .. .................. . .. . .... ...... .... .. ........ . .... ..  .\n11 . . .. .............. . .. . . .. .............. . .. . .... ....... .... .. ... .......... ... . .... . . .\n12 \n13 ............... ........... .............. . ......... .. .... ... .. .... ... .\n14 ................ .................. .............. . .........  .. .... ... .. .... ... .\n15 \n16 . ........... . ... . .. .... .......... .... ...... .... ........ .\n17 . ........... . ... .. ............ . ... . .. .... .......... .... ...... ..... ..... .....\n18 \n19 .......... ............... . .. ... ....\n20 ............................\n21 \n22 ..... .. ...... .. .........\n23 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n24 \n25 .\n26 .... ........ ...............\n27 ....\n28 .... ....... ..... ................ ..\n29 ....\n30 .. . ........... . ... . . ....\n31   .... .  ...... ...... .... .................. ..\n32   .. . ............ . ... . .....\n33     ....\n34     .... .    .......................... .........\n35     ....\n36   ..\n37   .... .  ..\n38 ..\n39 ....\n40 .... ...\n41 . . ............\n"
}

hint5() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ \"\$#\" -lt 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME [-s|--silent]\" >&2; exit 1; }\n 4 \n 5 ......................\n 6 .................\n 7 ....................\n 8 .............. . .. ... . . .. . .... . .... .. .... . .......... . .. .... ... .. .... ... .\n 9 \n10 . .. ............... . .. . .... ........ .... .. ........ . .... ..  .\n11 . .. .................. . .. . .... ...... .... .. ........ . .... ..  .\n12 . . .. .............. . .. . . .. .............. . .. . .... ....... .... .. ... .......... ... . .... . . .\n13 \n14 ............... ........... .............. . ......... .. .... ... .. .... ... .\n15 ................ .................. .............. . .........  .. .... ... .. .... ... .\n16 \n17 . ........... . ... . .. .... .......... .... ...... .... ........ .\n18 . ........... . ... .. ............ . ... . .. .... .......... .... ...... ..... ..... .....\n19 \n20 .......... ............... . .. ... ....\n21 ............................\n22 \n23 ..... .. ...... .. .........\n24 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n25 \n26 .\n27 .... ........ ...............\n28 ....\n29 .... ....... ..... ................ ..\n30 ....\n31 .. . ........... . ... . . ....\n32   .... .  ...... ...... .... .................. ..\n33   .. . ............ . ... . .....\n34     ....\n35     .... .    .......................... .........\n36     ....\n37   ..\n38   .... .  ..\n39 ..\n40 ....\n41 .... ...\n42 . . ............\n"
}

hint6() {
  printf "Jak pewnie zauważyłeś, zmiana nie dotyczyła wyłacznie instrukcji warunkowej, ale również wyświetlanego komunikatu.\nAs you may have noticed, the change was not only to the conditional statement, but also to the displayed message.\n"
}

hint7() {
  printf "To zadanie, można rozwiązać na kilka sposobów. Ja wykorzystam podprogram, czyli coś w rodzaju funkcji. Nie jest to dokładnie funkcja znana na przykład z języka JAVA, jest raczej skryptem w skrypcie.\nThis task, can be solved in several ways. I will use a subroutine, or something like a function. It is not exactly a function known from, for example, the JAVA language, it is rather a script within a script.\n"
}

hint8() {
  printf " 1 #!/bin/bash\n 2 \n 3 [ \"\$#\" -lt 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME [-s|--silent]\" >&2; exit 1; }\n 4 \n 5 ......................\n 6 .................\n 7 ....................\n 8 .............. . .. ... . . .. . .... . .... .. .... . .......... . .. .... ... .. .... ... .\n 9 \n10 . .. ............... . .. . .... ........ .... .. ........ . .... ..  .\n11 . .. .................. . .. . .... ...... .... .. ........ . .... ..  .\n12 . . .. .............. . .. . . .. .............. . .. . .... ....... .... .. ... .......... ... . .... . . .\n13 \n14 ............... ........... .............. . ......... .. .... ... .. .... ... .\n15 ................ .................. .............. . .........  .. .... ... .. .... ... .\n16 \n17 . ........... . ... . .. .... .......... .... ...... .... ........ .\n18 . ........... . ... .. ............ . ... . .. .... .......... .... ...... ..... ..... .....\n19 \n20 .......... ............... . .. ... ....\n21 ............................\n22 \n23 ..... .. ...... .. .........\n24 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n25 \n26 .\n27 .... ........ ...............\n28 ....\n29 .... ....... ..... ................ ..\n30 ....\n31 .. . ........... . ... . . ....\n32   .... .  ...... ...... .... .................. ..\n33   .. . ............ . ... . .....\n34     ....\n35     .... .    .......................... .........\n36     ....\n37   ..\n38   .... .  ..\n39 ..\n40 ....\n41 .... ...\n42 . . ............\n"
}

hint9() {
  printf " 1 #!/bin/bash\n 2 \n 3 silent_echo() {\n 4   if [ \"\$1\" = 'F' ] ; then\n 5     shift\n 6     echo \"\$@\"\n 7   fi\n 8 }\n 9 \n10 [ \"\$#\" -lt 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME [-s|--silent]\" >&2; exit 1; }\n11 \n12 ......................\n13 .................\n14 ....................\n15 .............. . .. ... . . .. . .... . .... .. .... . .......... . .. .... ... .. .... ... .\n16 \n17 . .. ............... . .. . .... ........ .... .. ........ . .... ..  .\n18 . .. .................. . .. . .... ...... .... .. ........ . .... ..  .\n19 . . .. .............. . .. . . .. .............. . .. . .... ....... .... .. ... .......... ... . .... . . .\n20 \n21 ............... ........... .............. . ......... .. .... ... .. .... ... .\n22 ................ .................. .............. . .........  .. .... ... .. .... ... .\n23 \n24 . ........... . ... . .. .... .......... .... ...... .... ........ .\n25 . ........... . ... .. ............ . ... . .. .... .......... .... ...... ..... ..... .....\n26 \n27 .......... ............... . .. ... ....\n28 ............................\n29 \n30 ..... .. ...... .. .........\n31 . .. ... . . .. . .... ....... ...... ......... ..... . .... ..  .\n32 \n33 .\n34 .... ........ ...............\n35 ....\n36 .... ....... ..... ................ ..\n37 ....\n38 .. . ........... . ... . . ....\n39   .... .  ...... ...... .... .................. ..\n40   .. . ............ . ... . .....\n41     ....\n42     .... .    .......................... .........\n43     ....\n44   ..\n45   .... .  ..\n46 ..\n47 ....\n48 .... ...\n49 . . ............\n"
}

hint10() {
  printf "Dwa słowa o naszym podprogramie. Skupmy się tylko na nim, więc usunę resztę kodu.\nTwo words about our subprogram. Let's just focus on it, so I'll remove the rest of the code.\n"
}

hint11() {
  printf "#!/bin/bash\n\nsilent_echo() {\n  if [ \"\$1\" = 'F' ] ; then\n    shift\n    echo \"\$@\"\n  fi\n}\n\n........... ... .... ..... ... ........ ............\n........... ... .... ..... ........ ............\n"
}

hint12() {
  printf "Jak widać ma on nazwę, klamry znane z języka JAVA, puste nawiasy. Ale jeżeli nawiasy są puste, to jak przekazujemy argumenty? Dokładnie tak samo, jak do normalnego skryptu, czyli z użyciem zmiennych \$#, \$1, \$@ itd .... Możemy użyć też polecenia shift, jak przetworzone zostały jakieś argumenty, co tutaj jest to wykorzystane. Jako pierwszy argument spodziewamy się T/F, jak już wiemy co otrzymaliśmy to argument przesuwamy, a te argumenty, które pozostały wyświetlamy.\nAs you can see it has a name, brackets familiar from the JAVA language, empty parentheses. But if the parentheses are empty, how do we pass arguments? Exactly the same as for a normal script, that is, using the variables \$#, \$1, \$@, etc. .... We can also use the shift command, as we have processed some arguments, which is what is used here. As the first argument we expect T/F, as we know what we have received we shift the argument, and those arguments that remain we display.\n"
}

hint13() {
  printf " 1 #!/bin/bash\n 2 \n 3 silent_echo() {\n 4   if [ \"\$1\" = 'F' ] ; then\n 5     shift\n 6     echo \"\$@\"\n 7   fi\n 8 }\n 9 \n10 silent_echo \"T\" \"Ten tekst nie zostanie wyświetlony\"\n11 silent_echo \"F\" \"Ten tekst zostanie wyświetlony\"\n"
}

hint14() {
  printf "Samo wywołanie, również przypomina bardziej wywołanie skryptu, niż funkcji, ale do tego trzeba się po prostu przyzwyczaić.\nThe call itself, also looks more like a script call than a function call, but you just have to get used to it\n"
}

hint15() {
  printf "Ostatnia część tego zadania, polega na podmianie wszystkich wywołań polecenia echo na wywołanie silent_echo, przy czym pierwszym argumentem tutaj musi być tryb pracy (T/F), a potem wyświetlany tekst.\nThe last part of this task, is to replace all calls to the echo command with a silent_echo call, with the first argument here having to be the mode of operation (T/F), followed by the displayed text.\n"
}

hint16() {
  printf " 1 #!/bin/bash\n 2 \n 3 silent_echo() {\n 4   if [ \"\$1\" = 'F' ] ; then\n 5     shift\n 6     echo \"\$@\"\n 7   fi\n 8 }\n 9 \n10 [ \"\$#\" -lt 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME [-s|--silent]\" >&2; exit 1; }\n11 \n12 CONFIG_FILE=\"gen.conf\"\n13 PACKAGE_NAME=\"\$1\"\n14 JAVA_CLASS_NAME=\"\$2\"\n15 SILENT_MODE=\$( [ \$# -ge 3 ] && [ \"\$3\" = \"-s\" -o \"\$3\" = \"--silent\" ] && echo 'T' || echo 'F' )\n16 \n17 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n18 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n19 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] && { echo \"Config file is not available\" >&2 ; exit 2 ; }\n20 \n21 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null && echo 'T' || echo 'F' )\n22 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  && echo 'T' || echo 'F' )\n23 \n24 [ \"\$GEN_MAIN\" = 'T' ] && echo \"Generator will create main fynction \"\n25 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] && echo \"Generator will create hello world code\"\n26 \n27 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n28 FILE=\"\$JAVA_CLASS_NAME.java\"\n29 \n30 mkdir -p \"\$DIR\" 2> /dev/null\n31 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n32 \n33 (\n34 echo \"package \$PACKAGE_NAME;\"\n35 echo\n36 echo \"public class \$JAVA_CLASS_NAME {\"\n37 echo\n38 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n39   echo \"  public static coid main(String[]args) {\"\n40   if [ \"\$GEN_HELLO\" = \"T\" ] ;then\n41     echo\n42     echo \"    System.out.println(\"Hello world\")\"\n43     echo\n44   fi\n45   echo \"  }\"\n46 fi\n47 echo\n48 echo \"}\"\n49 ) > \"\$DIR/\$FILE\"\n"
}

hint17() {
  printf " 1 ...........\n 2 \n 3 ............. .\n 4   .. . .... . ... . . ....\n 5     .....\n 6     .... ....\n 7   ..\n 8 .\n 9 \n10 . .... ... . . .. . .... ....... .. ............ ............... .............. .... .... .. .\n11 \n12 ......................\n13 .................\n14 ....................\n15 .............. . .. ... . . .. . .... . .... .. .... . .......... . .. .... ... .. .... ... .\n16 \n17 [ -z \"\$PACKAGE_NAME\" ] && { echo \"Package name is invalid\" ; exit 2;  }\n18 [ -z \"\$JAVA_CLASS_NAME\" ] && { echo \"Class name is invalid\" ; exit 3;  }\n19 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] && { echo \"Config file is not available\" >&2 ; exit 2 ; }\n20 \n21 ............... ........... .............. . ......... .. .... ... .. .... ... .\n22 ................ .................. .............. . .........  .. .... ... .. .... ... .\n23 \n24 [ \"\$GEN_MAIN\" = 'T' ] && echo \"Generator will create main fynction \"\n25 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] && echo \"Generator will create hello world code\"\n26 \n27 .......... ............... . .. ... ....\n28 ............................\n29 \n30 ..... .. ...... .. .........\n31 [ \$? -ne 0 ] && { echo \"Cannot create directory \$DIR\" ; exit 7;  }\n32 \n33 .\n34 .... ........ ...............\n35 ....\n36 .... ....... ..... ................ ..\n37 ....\n38 .. . ........... . ... . . ....\n39   .... .  ...... ...... .... .................. ..\n40   .. . ............ . ... . .....\n41     ....\n42     .... .    .......................... .........\n43     ....\n44   ..\n45   .... .  ..\n46 ..\n47 ....\n48 .... ...\n49 . . ............\n"
}

hint18() {
  printf " 1 ...........\n 2 \n 3 ............. .\n 4   .. . .... . ... . . ....\n 5     .....\n 6     .... ....\n 7   ..\n 8 .\n 9 \n10 . .... ... . . .. . .... ....... .. ............ ............... .............. .... .... .. .\n11 \n12 ......................\n13 .................\n14 ....................\n15 .............. . .. ... . . .. . .... . .... .. .... . .......... . .. .... ... .. .... ... .\n16 \n17 [ -z \"\$PACKAGE_NAME\" ] && { silent_echo \"\$SILENT_MODE\" \"Package name is invalid\" ; exit 2;  }\n18 [ -z \"\$JAVA_CLASS_NAME\" ] && { silent_echo \"\$SILENT_MODE\"  \"Class name is invalid\" ; exit 3;  }\n19 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] && { silent_echo \"\$SILENT_MODE\"  \"Config file is not available\" >&2 ; exit 2 ; }\n20 \n21 ............... ........... .............. . ......... .. .... ... .. .... ... .\n22 ................ .................. .............. . .........  .. .... ... .. .... ... .\n23 \n24 [ \"\$GEN_MAIN\" = 'T' ] && silent_echo \"\$SILENT_MODE\" \"Generator will create main fynction \"\n25 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] && silent_echo \"\$SILENT_MODE\"  \"Generator will create hello world code\"\n26 \n27 .......... ............... . .. ... ....\n28 ............................\n29 \n30 ..... .. ...... .. .........\n31 [ \$? -ne 0 ] && { silent_echo \"\$SILENT_MODE\" \"Cannot create directory \$DIR\" ; exit 7;  }\n32 \n33 .\n34 .... ........ ...............\n35 ....\n36 .... ....... ..... ................ ..\n37 ....\n38 .. . ........... . ... . . ....\n39   .... .  ...... ...... .... .................. ..\n40   .. . ............ . ... . .....\n41     ....\n42     .... .    .......................... .........\n43     ....\n44   ..\n45   .... .  ..\n46 ..\n47 ....\n48 .... ...\n49 . . ............\n"
}

hint19() {
  printf " 1 #!/bin/bash\n 2 \n 3 silent_echo() {\n 4   if [ \"\$1\" = 'F' ] ; then\n 5     shift\n 6     echo \"\$@\"\n 7   fi\n 8 }\n 9 \n10 [ \"\$#\" -lt 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME [-s|--silent]\" >&2; exit 1; }\n11 \n12 CONFIG_FILE=\"gen.conf\"\n13 PACKAGE_NAME=\"\$1\"\n14 JAVA_CLASS_NAME=\"\$2\"\n15 SILENT_MODE=\$( [ \$# -ge 3 ] && [ \"\$3\" = \"-s\" -o \"\$3\" = \"--silent\" ] && echo 'T' || echo 'F' )\n16 \n17 [ -z \"\$PACKAGE_NAME\" ] && { silent_echo \"\$SILENT_MODE\" \"Package name is invalid\" ; exit 2;  }\n18 [ -z \"\$JAVA_CLASS_NAME\" ] && { silent_echo \"\$SILENT_MODE\"  \"Class name is invalid\" ; exit 3;  }\n19 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] && { silent_echo \"\$SILENT_MODE\"  \"Config file is not available\" >&2 ; exit 2 ; }\n20 \n21 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null && echo 'T' || echo 'F' )\n22 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  && echo 'T' || echo 'F' )\n23 \n24 [ \"\$GEN_MAIN\" = 'T' ] && silent_echo \"\$SILENT_MODE\" \"Generator will create main fynction \"\n25 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] && silent_echo \"\$SILENT_MODE\"  \"Generator will create hello world code\"\n26 \n27 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n28 FILE=\"\$JAVA_CLASS_NAME.java\"\n29 \n30 mkdir -p \"\$DIR\" 2> /dev/null\n31 [ \$? -ne 0 ] && { silent_echo \"\$SILENT_MODE\" \"Cannot create directory \$DIR\" ; exit 7;  }\n32 \n33 (\n34 echo \"package \$PACKAGE_NAME;\"\n35 echo\n36 echo \"public class \$JAVA_CLASS_NAME {\"\n37 echo\n38 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n39   echo \"  public static coid main(String[]args) {\"\n40   if [ \"\$GEN_HELLO\" = \"T\" ] ;then\n41     echo\n42     echo \"    System.out.println(\"Hello world\")\"\n43     echo\n44   fi\n45   echo \"  }\"\n46 fi\n47 echo\n48 echo \"}\"\n49 ) > \"\$DIR/\$FILE\"\n"
}

solution() {
  printf " 1 #!/bin/bash\n 2 \n 3 silent_echo() {\n 4   if [ \"\$1\" = 'F' ] ; then\n 5     shift\n 6     echo \"\$@\"\n 7   fi\n 8 }\n 9 \n10 [ \"\$#\" -lt 2 ] && { echo \"usage: \$0 PACKAGE_NAME JAVA_CLASS_NAME [-s|--silent]\" >&2; exit 1; }\n11 \n12 CONFIG_FILE=\"gen.conf\"\n13 PACKAGE_NAME=\"\$1\"\n14 JAVA_CLASS_NAME=\"\$2\"\n15 SILENT_MODE=\$( [ \$# -ge 3 ] && [ \"\$3\" = \"-s\" -o \"\$3\" = \"--silent\" ] && echo 'T' || echo 'F' )\n16 \n17 [ -z \"\$PACKAGE_NAME\" ] && { silent_echo \"\$SILENT_MODE\" \"Package name is invalid\" ; exit 2;  }\n18 [ -z \"\$JAVA_CLASS_NAME\" ] && { silent_echo \"\$SILENT_MODE\"  \"Class name is invalid\" ; exit 3;  }\n19 [ ! -f \"\$CONFIG_FILE\" ] || [ ! -r \"\$CONFIG_FILE\" ] && { silent_echo \"\$SILENT_MODE\"  \"Config file is not available\" >&2 ; exit 2 ; }\n20 \n21 GEN_MAIN=\$(grep \"MAIN=TRUE\" \"\$CONFIG_FILE\" > /dev/null && echo 'T' || echo 'F' )\n22 GEN_HELLO=\$(grep \"HELLO_WORLD=TRUE\" \"\$CONFIG_FILE\" > /dev/null  && echo 'T' || echo 'F' )\n23 \n24 [ \"\$GEN_MAIN\" = 'T' ] && silent_echo \"\$SILENT_MODE\" \"Generator will create main fynction \"\n25 [ \"\$GEN_MAIN\" = 'T' -a \"\$GEN_HELLO\" = 'T' ] && silent_echo \"\$SILENT_MODE\"  \"Generator will create hello world code\"\n26 \n27 DIR=\$(echo \"\$PACKAGE_NAME\" | tr '.' '/')\n28 FILE=\"\$JAVA_CLASS_NAME.java\"\n29 \n30 mkdir -p \"\$DIR\" 2> /dev/null\n31 [ \$? -ne 0 ] && { silent_echo \"\$SILENT_MODE\" \"Cannot create directory \$DIR\" ; exit 7;  }\n32 \n33 (\n34 echo \"package \$PACKAGE_NAME;\"\n35 echo\n36 echo \"public class \$JAVA_CLASS_NAME {\"\n37 echo\n38 if [ \"\$GEN_MAIN\" = \"T\" ] ; then\n39   echo \"  public static coid main(String[]args) {\"\n40   if [ \"\$GEN_HELLO\" = \"T\" ] ;then\n41     echo\n42     echo \"    System.out.println(\"Hello world\")\"\n43     echo\n44   fi\n45   echo \"  }\"\n46 fi\n47 echo\n48 echo \"}\"\n49 ) > \"\$DIR/\$FILE\"\n"
}



homework1() {
  printf "Praca domowa numer #3006_1: Dodaj funkcjonalność  polegającą na dodaniu obsługi trybu log, czyli komunikaty będą raportowane i na konsolę (jeżeli nie mamy trybu silent) i do pliku. \nHomework #3006_1: Add functionality to add support for log mode, that is, messages will be reported and to the console (if we do not have silent mode) and to a file. \n"
}

homework2() {
  printf "Praca domowa numer #3006_2: Jak wykonałeś poprzednią pracę domową, musiałeś jakoś określić nazwę pliku. Teraz ja chcę, aby nazwa pliku zawierała datę, godzinę i minutę. Każdy zapis musi być zaraportowany tak aby logi a danej minuty pojawiały się w konkretnym pliku. Jak się zmieni minuta to kolejne logi zostaną utworzone już w kolejnym pliku. Dodatkowo, każdy log musi mieć informację o dokładnym czasie powstania logu (sekundy, milisekundy), i jaki użytkownik go wygenerował oraz na jakiej maszynie to się stało - adres ip może by się przydał.\nHomework #3006_2: As you did the previous homework, you had to specify the file name somehow. Now I want the file name to contain the date, time and minute. Each record must be reported so that logs a given minute appear in a specific file. As the minute changes, the next logs will already be created in the next file. In addition, each log must have information about the exact time of creation of the log (seconds, milliseconds), and what user generated it and on what machine it happened - ip address might be useful.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'solution' 'homework1' 'homework2' 

exit 0