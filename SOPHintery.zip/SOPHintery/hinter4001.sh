#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 4 | 0 | 0 | 1 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Utwórz, strukturę katalogów zgodną ciągiem liczb Fibonacciego, czyli w bieżącym katalogu tworzymy jeden katalog, w tym katalogu tworzymy też jeden katalog, w tym katalogu, tworzymy dwa katalogi, w tych dwóch tworzymy trzy katalogi, a w każdym z tych sześciu utworzonych tworzymy pięć katalogów. Utwórz to dla dowolnej nieujemnej wprowadzonej z klawiatury liczby całkowitej, ale powiedzmy nie większej niż 10. Zakładamy, że wprowadzona dana będzie liczbą."
  echo 
  echo "Create, a directory structure that conforms to the Fibonacci sequence of numbers, that is, in the current directory we create one directory, in this directory we also create one directory, in this directory, we create two directories, in these two we create three directories, and in each of these six created we create five directories. Create this for any non-negative integer entered from the keyboard, but let's say no more than 10. We assume that the entered data will be a number."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "W rozwiązaniu wykorzystam: if, for, podprogram, zmienne, echo, eval, rozwinięcia i instrukcję read. Interesujące jest polecenie eval - sugeruję się z nim zapoznać.\nIn the solution I will use: if, for, subroutine, variables, echo, eval, expansions and read statement. The eval command is interesting - I suggest getting familiar with it.\n"
}

hint2() {
  printf "Na wstępie, jak zwykle szybkie przedstawienie rozwiązania. A później będę to tłumaczył.\nFirst, as usual, a quick presentation of the solution. And later I will explain it.\n"
}

hint3() {
  printf " 1 ...........\n 2 \n 3 ......................... .\n 4   .........\n 5   .. . .... ... . . .....\n 6   	..........\n 7   ..\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   .... .........\n21 .\n22 \n23 .... .. ...... . ....... . .\n24 ..................................... ...\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint4() {
  printf " 1 #!/bin/bash\n 2 \n 3 ......................... .\n 4   .........\n 5   .. . .... ... . . .....\n 6   	..........\n 7   ..\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   .... .........\n21 .\n22 \n23 .... .. ...... . ....... . .\n24 ..................................... ...\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint5() {
  printf " 1 #!/bin/bash\n 2 \n 3 ......................... .\n 4   .........\n 5   .. . .... ... . . .....\n 6   	..........\n 7   ..\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   .... .........\n21 .\n22 \n23 read -p \"Enter a number: \" N\n24 ..................................... ...\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint6() {
  printf " 1 #!/bin/bash\n 2 \n 3 ......................... .\n 4   .........\n 5   .. . .... ... . . .....\n 6   	..........\n 7   ..\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   .... .........\n21 .\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint7() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   .........\n 5   .. . .... ... . . .....\n 6   	..........\n 7   ..\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   .... .........\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint8() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   .. . .... ... . . .....\n 6   	..........\n 7   ..\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint9() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint10() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint11() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint12() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   for((i=2;i<=\$1;i++)) ; do\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   done\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint13() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   for((i=2;i<=\$1;i++)) ; do\n14   	let C=A+B\n15   	let A=B\n16   	let B=C\n17   	........................\n18   done\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint14() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   for((i=2;i<=\$1;i++)) ; do\n14   	let C=A+B\n15   	let A=B\n16   	let B=C\n17   	RESULT=\$RESULT/\$C{1..\$C}\n18   done\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint15() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   for((i=2;i<=\$1;i++)) ; do\n14   	let C=A+B\n15   	let A=B\n16   	let B=C\n17   	RESULT=\$RESULT/\$C{1..\$C}\n18   done\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 eval \"echo \$DIRECTORIES\"\n27 ..... ...... ..............\n"
}

hint16() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   for((i=2;i<=\$1;i++)) ; do\n14   	let C=A+B\n15   	let A=B\n16   	let B=C\n17   	RESULT=\$RESULT/\$C{1..\$C}\n18   done\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 eval \"echo \$DIRECTORIES\"\n27 #eval \"mkdir \$\$DIRECTORIES\"\n"
}

hint17() {
  printf "To teraz będą wyjaśnienia do wszystkiego co się tutaj dzieje.\nThis will now be the explanation for everything that happens here\n"
}

hint18() {
  printf " 1 #!/bin/bash\n 2 \n 3 ......................... .\n 4   .........\n 5   .. . .... ... . . .....\n 6   	..........\n 7   ..\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   .... .........\n21 .\n22 \n23 read -p \"Enter a number: \" N\n24 ..................................... ...\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint19() {
  printf "W linii 23 wprowadzamy z klawiatury liczbę określającą żądaną liczbę Fibonacciego. Uwaga: nie sprawdzam poprawności wprowadzonych danych.\nOn line 23, enter the number specifying the desired Fibonacci number from the keyboard. Note: I do not check the correctness of the entered data.\n"
}

hint20() {
  printf " 1 #!/bin/bash\n 2 \n 3 ......................... .\n 4   .........\n 5   .. . .... ... . . .....\n 6   	..........\n 7   ..\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   .... .........\n21 .\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint21() {
  printf "W linii 24 wywołuję podprogram fibonacci_formated_text, który wyprodukuje mi ścieżki katalogów określone w specyfikacji zadania.\nOn line 24, I call the fibonacci_formated_text subroutine, which will produce me the directory paths specified in the task specification.\n"
}

hint22() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   .........\n 5   .. . .... ... . . .....\n 6   	..........\n 7   ..\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   .... .........\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint23() {
  printf "Następnie definiujemy podprogram.\nNext, we define the fibonacci_formed_text subroutine.\n"
}

hint24() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   .. . .... ... . . .....\n 6   	..........\n 7   ..\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint25() {
  printf "Definiujemy zmienną RESULT, której wartość będzie wynikiem działania podprogramu.\nWe define the RESULT variable, the value of which will be the result of the subroutine's action\n"
}

hint26() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   .. .... .... ... .  .....\n 9   	.............\n10   ..\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint27() {
  printf "Jeżeli argument wejściowy jest równy lub większy od 0 (-ge) to wiemy, że mamy utworzyć co najmniej jeden katalog o nazwie 1.\nIf the input argument is equal to or greater than 0 (-ge) then we know that we are to create at least one directory named 1.\n"
}

hint28() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   ...\n12   ...\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint29() {
  printf "Jeżeli argument wejściowy jest równy lub większy od 1 (-ge) to wiemy, że mamy w katalogu o nazwie 1, podkatalog o nazwie 1.\nIf the input argument is equal to or greater than 1 (-ge) then we know that we have in the directory named 1, a subdirectory named 1.\n"
}

hint30() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   .................... . ..\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   ....\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint31() {
  printf "Definiujemy zmienne pomocnicze A i B.\nWe define auxiliary variables A and B.\n"
}

hint32() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   for((i=2;i<=\$1;i++)) ; do\n14   	... .....\n15   	... ...\n16   	... ...\n17   	........................\n18   done\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint33() {
  printf "I zaczynam definiować standardową pętlę, znaną nam z języka JAVA czy C++. Zwróć uwagę na podwójne nawiasy.\nAnd I start defining a standard loop, familiar to us from JAVA or C++. Note the double parentheses.\n"
}

hint34() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   for((i=2;i<=\$1;i++)) ; do\n14   	let C=A+B\n15   	let A=B\n16   	let B=C\n17   	........................\n18   done\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint35() {
  printf "Obliczamy kolejne wartości ciągu Fibonacciego.\nWe calculate the consecutive values of the Fibonacci sequence.\n"
}

hint36() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   for((i=2;i<=\$1;i++)) ; do\n14   	let C=A+B\n15   	let A=B\n16   	let B=C\n17   	RESULT=\$RESULT/\$C{1..\$C}\n18   done\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 .... ..... .............\n27 ..... ...... ..............\n"
}

hint37() {
  printf "To w linii 17 ukryło się nasze rozwiązanie. To tutaj wytwarzamy odpowiednie ścieżki z wykorzystaniem operatora rozwinięcia {}.\nIt is in line 17 that our solution hides. This is where we produce the correct paths using the {} expansion operator.\n"
}

hint38() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   for((i=2;i<=\$1;i++)) ; do\n14   	let C=A+B\n15   	let A=B\n16   	let B=C\n17   	RESULT=\$RESULT/\$C{1..\$C}\n18   done\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 eval \"echo \$DIRECTORIES\"\n27 ..... ...... ..............\n"
}

hint39() {
  printf "W linii 26 wyświetlamy wszystkie wytworzone ścieżki. Dlaczego musiałem tutaj użyć polecenia eval? Sprawdź co by się stało bez niego?\nIn line 26 we display all produced paths . Why did I have to use the eval command here? Check what would have happened without it?\n"
}

hint40() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   for((i=2;i<=\$1;i++)) ; do\n14   	let C=A+B\n15   	let A=B\n16   	let B=C\n17   	RESULT=\$RESULT/\$C{1..\$C}\n18   done\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 eval \"echo \$DIRECTORIES\"\n27 #eval \"mkdir \$\$DIRECTORIES\"\n"
}

hint41() {
  printf "Na samym końcu mamy zakomentowaną linię z poleceniem mkdir. Dlaczego? Dlatego, że liczba tych katalogów może być bardzo bardzo duża, dlatego wstrzymałem się z wywołaniem procedury ich fizycznego utworzenia na dysku. Jest to bardzo skomplikowana operacja, chociaż wygląda na bardzo prostą.\nAt the very end we have a commented out line with the mkdir command. Why? Because the number of these directories can be very large, so I have suspended calling the procedure to physically create them on disk. This is a very complicated operation, although it looks very simple.\n"
}

solution() {
  printf " 1 #!/bin/bash\n 2 \n 3 fibonacci_formated_text() {\n 4   RESULT=\"\"\n 5   if [ \"\$1\" -ge 0 ] ;then\n 6   	RESULT=\"1\"\n 7   fi\n 8   if test \"\$1\" -ge 1  ;then\n 9   	RESULT=\"\$Z/1\"\n10   fi\n11   A=1\n12   B=1\n13   for((i=2;i<=\$1;i++)) ; do\n14   	let C=A+B\n15   	let A=B\n16   	let B=C\n17   	RESULT=\$RESULT/\$C{1..\$C}\n18   done\n19 \n20   echo \"\$RESULT\"\n21 }\n22 \n23 read -p \"Enter a number: \" N\n24 DIRECTORIES=\$(fibonacci_formated_text \$N)\n25 \n26 eval \"echo \$DIRECTORIES\"\n27 #eval \"mkdir \$\$DIRECTORIES\"\n"
}



homework1() {
  printf "Praca domowa #4001_1: Napisz podprogram, który zwróci informację, ile takich katalogów zostanie fizycznie utworzonych.\nHomework #4001_1: Write a subroutine that returns how many such directories will be physically created.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'hint30' 'hint31' 'hint32' 'hint33' 'hint34' 'hint35' 'hint36' 'hint37' 'hint38' 'hint39' 'hint40' 'hint41' 'solution' 'homework1' 

exit 0