#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 3 | 0 | 0 | 3 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Pamiętasz zadanie 3002? Jeżeli nie to cofnij się do niego. Jak już je rozwiązałeś i rozumiesz tamto zadanie, to teraz obsłuż przynajmniej dwa błędy: otrzymany ciąg musi mieć przynajmniej dwa elementy i muszą to być liczby. Powinniśmy jeszcze sprawdzić mnóstwo innych rzeczy, ale na razie to wystarczy."
  echo 
  echo "Do you remember task 3002? If not then go back to it. Once you've solved it and understand that task, now handle at least two errors: the resulting string must have at least two elements and they must be numbers. We should still check a lot of other things, but this is enough for now."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "W zadaniu 3002 napisaliśmy taki skrypt.\nIn task 3002, we wrote such a script.\n"
}

hint2() {
  printf "#!/bin/bash\n\nread FIBO\nA=\$(echo \"\$FIBO\" | rev | cut -d':' -f1 | rev)\nB=\$(echo \"\$FIBO\" | rev | cut -d':' -f2 | rev)\nlet C=A+B\necho \"\$FIBO:\$C\"\n\nexit 0\n"
}

hint3() {
  printf "Sprawdźmy, czy otrzymany ciąg FIBO ma niezerową długość.\nLet's check that the resulting FIBO string has a non-zero length.\n"
}

hint4() {
  printf "...\nread FIBO\nif [ -n \"\$FIBO\" ] ; then \n  .....\nfi\n...\n"
}

hint5() {
  printf "Jeżeli ciąg FIBO ma niezerową długość wtedy możemy zacząć go analizować i przetwarzać.\nIf the FIBO string has a non-zero length then we can start analyzing and processing it.\n"
}

hint6() {
  printf "Ale z doświadczenia wiem, że lepiej jest sprawdzić, nie czy coś jest poprawne, ale że coś jest niepoprawne i zakończyć przetwarzanie z odpowiednim komunikatem i kodem błędu.\nBut I know from experience that it is better to check, not that something is correct, but that something is incorrect, and terminate processing with the appropriate message and error code.\n"
}

hint7() {
  printf "...\nread FIBO\nif [ -z \"\$FIBO\" ] ; then\n  echo \"FIBO sequence is empty\"; exit 1;\nfi\n...\n"
}

hint8() {
  printf "Nasze rozwiązanie zostało wzbogacone o to proste sprawdzenie.\nOur solution has been enhanced with this simple check.\n"
}

hint9() {
  printf "#!/bin/bash\n\nread FIBO\nif [ -z \"\$FIBO\" ] ; then\n  echo \"FIBO sequence is empty\"; exit 1;\nfi\nA=\$(echo \"\$FIBO\" | rev | cut -d':' -f1 | rev)\nB=\$(echo \"\$FIBO\" | rev | cut -d':' -f2 | rev)\nlet C=A+B\necho \"\$FIBO:\$C\"\n\nexit 0\n"
}

hint10() {
  printf "Czasami jednak dodany kod, tutaj jest to obsługa błędów, sam może byc błędny. Gdzie jest błąd?\nSometimes, however, the added code, here it is error handling, can itself be wrong. Where is the error?\n"
}

hint11() {
  printf "Problemem tutaj jest użycie polecenia echo w obsłudze błędu. Pamiętamy, że mamy dwa urządzenia w systemie stdout i stderr. Komunikat o błędzie powinien być przekazywany do urządzenia stderr czyli powinniśmy użyć 2>, ale echo przekazuje to domyślnie na stdout. Co gorsza, w naszym konkretnym przypadku, komunikat ten zostanie przekazany poprzez potok do kolejnej aplikacji, ta go odczyta i musi obsłużyć.\nThe problem here is the use of the echo command in error handling. We remember that we have two devices in the system stdout and stderr. The error message should be passed to the stderr device i.e. we should use 2>, but echo passes it to stdout by default. To make matters worse, in our particular case, this message will be passed through the pipeline to another application, this one will read it and has to handle it.\n"
}

hint12() {
  printf "Przekierujmy strumień wyjściowy z stdout na standardowe wyjście diagnostyczne stderr.\nLet's redirect the output stream from stdout to the standard diagnostic output stderr.\n"
}

hint13() {
  printf "#!/bin/bash\n\nread FIBO\nif [ -z \"\$FIBO\" ] ; then echo \"FIBO sequence is empty\" >&2; exit 1;  fi\nA=\$(echo \"\$FIBO\" | rev | cut -d':' -f1 | rev)\nB=\$(echo \"\$FIBO\" | rev | cut -d':' -f2 | rev)\nlet C=A+B\necho \"\$FIBO:\$C\"\n\nexit 0\n"
}

hint14() {
  printf "Już lepiej, wygląda trochę dziwnie, ale bash jest pełny dziwnych rzeczy.\nIt's better now, it looks a little strange, but bash is full of strange things.\n"
}

hint15() {
  printf "Sprawdźmy czy mamy przynajmniej jeden dwukropek. Pokażę dwie metody, w pierwszej usunę potencjalne dwukropki i porównam długości tekstów przed tą operacją i po. Jak będą takie same to znaczy że dwukropka tam nie ma.\nLet's check that we have at least one colon. I will show two methods, in the first one I will remove potential colons and compare the lengths of the texts before and after this operation. If they are the same it means that the colon is not there.\n"
}

hint16() {
  printf "#!/bin/bash\n\nread FIBO\nif [ -z \"\$FIBO\" ] ; then\n  echo \"FIBO sequence is empty\" >&2; exit 1;\nfi\nLENGTH_BEFORE=\$(echo -n \"\$FIBO\" | wc -c)\nLENGTH_AFTER=\$(echo -n \"\$FIBO\" | tr -d ':' | wc -c)\nif [ \"\$LENGTH_BEFORE\" -eq \"\$LENGTH_AFTER\" ] ; then\n  echo \"FIBO sequence without :\" >&2; exit 2;\nfi\nA=\$(echo \"\$FIBO\" | rev | cut -d':' -f1 | rev)\nB=\$(echo \"\$FIBO\" | rev | cut -d':' -f2 | rev)\nlet C=A+B\necho \"\$FIBO:\$C\"\n\nexit 0\n"
}

hint17() {
  printf "To ostatnie sprawdzenie było bardzo proste, szybkie, niewiele nas kosztowało, ale lepiej jest to zrobić trochę inaczej. Użyjmy regexa, który sprawdzi czy mamy dwukropek w naszym tekście.\nThis last check was very simple, quick, and cost us very little, but it is better to do it a little differently. Let's use a regex that will check if we have a colon in our text.\n"
}

hint18() {
  printf "...\necho \"\$FIBO\" | grep \":\"\n...\n"
}

hint19() {
  printf "Polecenie grep odfiltruje dane, które nie pasują do wyrażenia regularnego. Zwraca ono też błąd jak tekstu nie udało się dopasować i to właśnie wykorzystamy.\nThe grep command will filter out data that does not match a regular expression. It also returns an error as the text failed to match, and this is what we will use.\n"
}

hint20() {
  printf "#FIRST METHOD WITH IF...\necho \"\$FIBO\" | grep \":\"\nif [ \$? -ne 0 ]; then then\n  echo \"FIBO sequence without :\" >&2;\nexit 2;\nfi\n...\n"
}

hint21() {
  printf "#SECOND METHOD WITHOUT IF, BUT WITH ||...\necho \"\$FIBO\" | grep \":\" || { echo \"FIBO sequence without :\" >&2; exit 2; }\n...\n"
}

hint22() {
  printf "Rozbudujmy trochę naszego regexa. Wiemy, że przed dwukropkiem i po dwukropku mamy mieć liczby. Sprawdźmy to.\nLet's expand our regex a bit. We know that before the colon and after the colon we are supposed to have numbers. Let's check it out.\n"
}

hint23() {
  printf "#SECOND METHOD WITHOUT IF, BUT WITH ||, WITH NUMBERS CHECKING...\necho \"\$FIBO\" | egrep \"[0-9]+:[0-9]+\" || { echo \"FIBO sequence without NUMBER:NUMBER\" >&2; exit 3; }\n...\n"
}

hint24() {
  printf "Zwróć uwagę, że użyliśmy tutaj + więc grep musiał sie zmienić w egrep.\nNote that we used + here, so grep must have turned into egrep.\n"
}

hint25() {
  printf "Możemy to rozszerzyć, czy na początku są liczby, czy na końcu są liczby itd...\nWe can expand this, whether there are numbers at the beginning, whether there are numbers at the end, etc...\n"
}

hint26() {
  printf "#SECOND METHOD WITHOUT IF, BUT WITH ||, WITH NUMBERS CHECKING...\necho \"\$FIBO\" | egrep \"[0-9]+:[0-9]+\" || { echo \"FIBO sequence without NUMBER:NUMBER\" >&2; exit 3; }\necho \"\$FIBO\" | egrep \"^[0-9]+:[0-9]+\" || { echo \"FIBO sequence without NUMBER:NUMBER\" >&2; exit 4; }\necho \"\$FIBO\" | egrep \"[0-9]+:[0-9]+\$\" || { echo \"FIBO sequence without NUMBER:NUMBER\" >&2; exit 5; }\n...\n"
}

hint27() {
  printf "Niestety aby sprawdzić, czy ciąg ten składa się wyłącznie z liczb oddzielonych dwukropkami, musimy wykorzystać pętlę, a na to jeszcze za wcześnie. Sprawdźmy czy mamy w nim tylko znaki dwukropka lub tylko same cyfry. Najlepiej byłoby sprawdzić, czy istotnie jest to ciąg Fibonacciego, ale to może być jako zadanie domowe.\nUnfortunately, in order to check whether this string consists only of numbers separated by colons, we have to use a loop, and it's still too early for that. Let's check if we have only colon characters in it or only numbers alone. It would be best to check whether it is indeed a Fibonacci sequence, but that can be as homework.\n"
}

hint28() {
  printf "#SECOND METHOD WITHOUT IF, BUT WITH ||, WITH NUMBERS CHECKING...\necho \"\$FIBO\" | tr -d '0-9' | egrep \"^:+\$\" || { echo \"FIBO sequence has invalid format\" >&2; exit 6; }\necho \"\$FIBO\" | tr -d ':' | egrep \"^[0-9]+\$\" || { echo \"FIBO sequence has invalid format\" >&2; exit 6; }\n...\n"
}

hint29() {
  printf "Jeszcze pewnien drobny szczegół. Być może zauwazyliście, ale w przypadku gdy polecenie grep zaakceptuje dane wejściowe (pasują do regexa) to wyświetli ono te dane na standardowe swyjście - zobaczymy ja na ekranie, a nie chcieliśmy ich oglądać. Można to również uzyskac na dwa sposoby. W pierwszej przekierujemy wynik działania grep do urządzenia /dev/null (kosz na śmieci)\nOne more small detail. You may have noticed, but in case the grep command accepts the input data (it matches the regex) it will display this data on the standard output - we will see it on the screen, and we did not want to see it. This can also be achieved in two ways. In the first, we redirect the result of the grep action to the /dev/null device (trash).\n"
}

hint30() {
  printf "#SECOND METHOD WITHOUT IF, BUT WITH ||, WITH NUMBERS CHECKING...\necho \"\$FIBO\" | tr -d '0-9' | egrep \"^:+\$\" > /dev/null || { echo \"FIBO sequence has invalid format\" >&2; exit 6; }\necho \"\$FIBO\" | tr -d ':' | egrep \"^[0-9]+\$\" > /dev/null || { echo \"FIBO sequence has invalid format\" >&2; exit 6; }\n...\n"
}

hint31() {
  printf "W drugiej metodzie wykorzystame opcję polecenia grep -q - quiet, robi to co ma robić, ale nic nie wyświetla. Niektóre polecenia mają tę opcję.\nW drugiej metodzie wykorzystame opcję polecenia grep -q - quiet, robi to co ma robić, ale nic nie wyświetla. Niektóre polecenia mają tę opcję.\n"
}

hint32() {
  printf "#SECOND METHOD WITHOUT IF, BUT WITH ||, WITH NUMBERS CHECKING...\necho \"\$FIBO\" | tr -d '0-9' | egrep -q \"^:+\$\" || { echo \"FIBO sequence has invalid format\" >&2; exit 6; }\necho \"\$FIBO\" | tr -d ':' | egrep -q \"^[0-9]+\$\" || { echo \"FIBO sequence has invalid format\" >&2; exit 6; }\n...\n"
}

hint33() {
  printf "No to na razie mamy gotowy skrypt.\nWell, we have the script ready for now.\n"
}

hint34() {
  printf "#!/bin/bash\n\nread FIBO\nif [ -z \"\$FIBO\" ] ; then\n  echo \"FIBO sequence is empty\" >&2; exit 1;\nfi\nLENGTH_BEFORE=\$(echo -n \"\$FIBO\" | wc -c)\nLENGTH_AFTER=\$(echo -n \"\$FIBO\" | tr -d ':' | wc -c)\nif [ \"\$LENGTH_BEFORE\" -eq \"\$LENGTH_AFTER\" ] ; then\n  echo \"FIBO sequence without :\" >&2; exit 2;\nfi\necho \"\$FIBO\" | egrep -q \"[0-9]+:[0-9]+\" || { echo \"FIBO sequence without NUMBER:NUMBER\" >&2; exit 3; }\necho \"\$FIBO\" | egrep -q \"^[0-9]+:[0-9]+\" || { echo \"FIBO sequence without NUMBER:NUMBER\" >&2; exit 4; }\necho \"\$FIBO\" | egrep -q \"[0-9]+:[0-9]+\$\" || { echo \"FIBO sequence without NUMBER:NUMBER\" >&2; exit 5; }\necho \"\$FIBO\" | tr -d '0-9' | egrep -q \"^:+\$\" || { echo \"FIBO sequence has invalid format\" >&2; exit 6; }\necho \"\$FIBO\" | tr -d ':' | egrep -q \"^[0-9]+\$\" || { echo \"FIBO sequence has invalid format\" >&2; exit 7; }\nA=\$(echo \"\$FIBO\" | rev | cut -d':' -f1 | rev)\nB=\$(echo \"\$FIBO\" | rev | cut -d':' -f2 | rev)\nlet C=A+B\necho \"\$FIBO:\$C\"\n\nexit 0\n"
}

hint35() {
  printf "Duży ten skrypt, był mały, łatwo się to czytało, a teraz? Może go zrefaktoryzujesz, aby robił to samo, ale nie w tak rozwlekły sposób. Spróbuj.\nBig this script, it was small, it was easy to read, and now? Why don't you refactor it to do the same thing, but not in such a long-winded way. Try.\n"
}

solution() {
  printf "#!/bin/bash\n\nread FIBO\nif [ -z \"\$FIBO\" ] ; then\n  echo \"FIBO sequence is empty\" >&2; exit 1;\nfi\nLENGTH_BEFORE=\$(echo -n \"\$FIBO\" | wc -c)\nLENGTH_AFTER=\$(echo -n \"\$FIBO\" | tr -d ':' | wc -c)\nif [ \"\$LENGTH_BEFORE\" -eq \"\$LENGTH_AFTER\" ] ; then\n  echo \"FIBO sequence without :\" >&2; exit 2;\nfi\necho \"\$FIBO\" | egrep -q \"[0-9]+:[0-9]+\" || { echo \"FIBO sequence without NUMBER:NUMBER\" >&2; exit 3; }\necho \"\$FIBO\" | egrep -q \"^[0-9]+:[0-9]+\" || { echo \"FIBO sequence without NUMBER:NUMBER\" >&2; exit 4; }\necho \"\$FIBO\" | egrep -q \"[0-9]+:[0-9]+\$\" || { echo \"FIBO sequence without NUMBER:NUMBER\" >&2; exit 5; }\necho \"\$FIBO\" | tr -d '0-9' | egrep -q \"^:+\$\" || { echo \"FIBO sequence has invalid format\" >&2; exit 6; }\necho \"\$FIBO\" | tr -d ':' | egrep -q \"^[0-9]+\$\" || { echo \"FIBO sequence has invalid format\" >&2; exit 7; }\nA=\$(echo \"\$FIBO\" | rev | cut -d':' -f1 | rev)\nB=\$(echo \"\$FIBO\" | rev | cut -d':' -f2 | rev)\nlet C=A+B\necho \"\$FIBO:\$C\"\n\nexit 0\n"
}



homework1() {
  printf "Praca domowa #3003: Jeżeli znasz już pętle to dopisz kod sprawdzający, czy otrzymany ciąg liczb jest naprawdę ciągiem Fibonacciego.\nHomework #3003: If you already know the loops then add code to check if the resulting sequence of numbers is really a Fibonacci sequence.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'hint30' 'hint31' 'hint32' 'hint33' 'hint34' 'hint35' 'solution' 'homework1' 

exit 0