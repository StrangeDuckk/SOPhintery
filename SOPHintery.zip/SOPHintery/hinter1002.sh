#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 1 | 0 | 0 | 2 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Utwórz i wyświetl, strukturę katalogow zgodną ciągiem liczb Fibonacciego, czyli w bieżącym katalogu tworzymy jeden katalog, w tym katalogu tworzymy też jeden katalog, w tym katalogu, tworzymy dwa katalogi, w tych dwóch tworzymy trzy, a w każdym z tych sześciu utworzonych tworzymy pięć katalogów. Utwórz to w możliwie najkrótszy sposób."
  echo 
  echo "Create, a structure of directories that conforms to the Fibonacci sequence of numbers, eg. in the current directory we create one directory, in this directory we also create one directory, in this directory, we create two directories, in each ot these two directories we create three directories, and in each of these six created directories we create five directories. Create this in the shortest possible way."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Użyj polecenia mkdir.\nUse mkdir command.\n"
}

hint2() {
  printf "Zauważ, że polecenie mkdir może przyjąć jako swoje argumenty wiele nazw katalogów.\nNote that the mkdir command can take multiple directory names as its arguments.\n"
}

hint3() {
  printf "Możesz używać ścieżek względnych i bezwzględnych. A czym się one różnią?\nYou can use relative and absolute paths. And what are the differences\n"
}

hint4() {
  printf "Zanim zaczniesz tworzyć katalogi poleceniem mkdir, może najpierw wyswietl ich nazwy poleceniem echo\nBefore you start creating directories with the mkdir command, why not first display their names with the echo command.\n"
}

hint5() {
  printf "Sprawdź w podręczniku man do czego służą opcje -v -p polecenia mkdir.\nCheck the man page for what the -v -p options of the mkdir command are used for.\n"
}

hint6() {
  printf "Zanim zaczniesz wypisywać różne kombinacje nazw katalogów - uruchom echo {a..z}{a..g}.\nBefore you start typing out different combinations of directory names - run echo {a..z}{a..g}.\n"
}

hint7() {
  printf "Masz już wszystkie, niezbędne informacje.  Zacznij od polecenia echo zamiast mkdir.\nYou already have all, necessary information. Now just sit down and write. Start with echo command instead of mkdir.\n"
}

hint8() {
  printf "echo . ./. ./././ ................\n"
}

hint9() {
  printf "echo 1 1/1 ./././ ................\n"
}

hint10() {
  printf "echo 1 1/1 1/1/2a/ 1/1/2b/ ................\n"
}

hint11() {
  printf "echo 1 1/1 1/1/2a/ 1/1/2b/ 1/1/2a/3a 1/1/2a/3b ................\n"
}

hint12() {
  printf "I możemy tak wypisywać nasze ścieżki, mając nadzieję, że się nie pomylimy i wszystkie wypiszemy.\nAnd we can write out our paths like this, hoping that we don't make a mistake and write them all out.\n"
}

hint13() {
  printf "echo 1 1/1 1/1/2a/ 1/1/2b/ 1/1/2a/3a/5a 1/1/2a/3a/5b 1/1/2a/3a/5c 1/1/2a/3a/5d 1/1/2a/3a/5e 1/1/2a/3b/5a 1/1/2a/3b/5b 1/1/2a/3b/5c 1/1/2a/3b/5d 1/1/2a/3b/5e 1/1/2a/3c/5a 1/1/2a/3c/5b 1/1/2a/3c/5c 1/1/2a/3c/5d 1/1/2a/3c/5e 1/1/2b/3a/5a 1/1/2b/3a/5b 1/1/2b/3a/5c 1/1/2b/3a/5d 1/1/2b/3a/5e 1/1/2b/3b/5a 1/1/2b/3b/5b 1/1/2b/3b/5c 1/1/2b/3b/5d 1/1/2b/3b/5e 1/1/2b/3c/5a 1/1/2b/3c/5b 1/1/2b/3c/5c 1/1/2b/3c/5d 1/1/2b/3c/5e\n"
}

hint14() {
  printf "Jest nieźle, ale nasze rozwiązanie jest dość długie, a przez to nie wiem czy poprawne. Użyjmy rozwinięcia {}.\nIt's not bad, but our solution is quite long, and thus I don't know if it's correct. Let's use the {} expansion.\n"
}

hint15() {
  printf "echo 1/1/2{a..b}/ ...... \n"
}

hint16() {
  printf "echo 1/1/2{a..b}/3{a..c}/5{a..e}\n"
}

hint17() {
  printf "Zmieńmy polecenie echo na mkdir.\nLet's change the echo command to mkdir.\n"
}

hint18() {
  printf "Po każdym teście, usuń katalogi. Jeżeli nie wiesz jak, wykorzystaj polecenie mc. Ono zrobi to w bezpieczny, kontrolowany sposób.\nAfter each test, delete the directories. If you don't know how, use the mc command. It will do it in a safe, controlled way.\n"
}

hint19() {
  printf "mkdir 1/1/2{a..b}/3{a..c}/5{a..e}\n"
}

hint20() {
  printf "mkdir -v 1/1/2{a..b}/3{a..c}/5{a..e}\n"
}

hint21() {
  printf "mkdir -v -p 1/1/2{a..b}/3{a..c}/5{a..e}\n"
}

hint22() {
  printf "mkdir -vp 1/1/2{a..b}/3{a..c}/5{a..e}\n"
}

solution() {
  printf "mkdir -vp 1/1/2{a..b}/3{a..c}/5{a..e}\n"
}



homework1() {
  printf "Praca domowa #1002_1: Do powyższego rozwiązania dodaj jeszcze jeden poziom katalogów. Czy jesteś w stanie policzyć ile katalogów zostało utworzonych?\nHomework #1002_1: Add one more level of directories to the above solution. Are you able to count how many directories you created?\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'solution' 'homework1' 

exit 0