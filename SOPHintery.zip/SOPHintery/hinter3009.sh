#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 3 | 0 | 0 | 9 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "W zadaniu 3008 napisaliśmy skrypt, który w zalezności od sytuacji kończył się różnymi kodami błędów. Błędy te w żaden sposób nie są wyjaśnione w sposób przyjazny dla użytkownika. Napisz skrypt, który będzie wyświetlał odpowiednią informację tekstową, w zależności od uzyskanego kodu błędu."
  echo 
  echo "In task 3008, we wrote a script that ended up with different error codes depending on the situation. These errors are not explained in any user-friendly way. Write a script that will display the appropriate text information, depending on the error code obtained."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Rozwiązań tego problemu może być bardzo dużo. To co ja przedstawię to tylko propozycja.\nThere may be many solutions to this problem. What I will present is just a suggestion.\n"
}

hint2() {
  printf "Na początku oczywiście szybka ścieżka prowadząca do rozwiązania, a później tłumaczenie, co robię i dlaczego.\nAt first, a fast way to a solution, and then explaining what I'm doing and why.\n"
}

hint3() {
  printf " 1 #!/bin/bash\n 2 \n 3 ...............\n 4 .....\n 5 ..............\n 6 \n 7 . .. .............. . .. .... .\n 8 . . .. .............. . .. .... .\n 9 \n10 ............. ............\n11 ...............\n12 \n13 .... ........... ..\n14 .. ..\n15 .. .... ........ ...... ......... ..\n16 .. .... ........ ........... ......... ..\n17 .. .... ....... ........ .. ... .. ... ....... ..........\n18 .. .... ............ ........ .. ... .. ... ....... ..........\n19 .. .... ....... ........ .. ... . ..... .... ........\n20 .. .... ... ....... ........... .. . ...... ........\n21 .. .... ......... .... ...... ........\n22 .. .... ... ...... ..... ........... .. . ...... ........\n23 .. .... ......... .... ...... ........\n24 ... .... ............ ....... ........ ... .... .... .......\n25 ... .... ....... ...... ...... .......\n26 .. .... ........ ..... .......\n27 .... ...\n28 \n29 .... .\n"
}

hint4() {
  printf " 1 #!/bin/bash\n 2 \n 3 EXECUTABLE=\"\$1\"\n 4 shift\n 5 ARGUMENTS=\"\$@\"\n 6 \n 7 . .. .............. . .. .... .\n 8 . . .. .............. . .. .... .\n 9 \n10 ............. ............\n11 ...............\n12 \n13 .... ........... ..\n14 .. ..\n15 .. .... ........ ...... ......... ..\n16 .. .... ........ ........... ......... ..\n17 .. .... ....... ........ .. ... .. ... ....... ..........\n18 .. .... ............ ........ .. ... .. ... ....... ..........\n19 .. .... ....... ........ .. ... . ..... .... ........\n20 .. .... ... ....... ........... .. . ...... ........\n21 .. .... ......... .... ...... ........\n22 .. .... ... ...... ..... ........... .. . ...... ........\n23 .. .... ......... .... ...... ........\n24 ... .... ............ ....... ........ ... .... .... .......\n25 ... .... ....... ...... ...... .......\n26 .. .... ........ ..... .......\n27 .... ...\n28 \n29 .... .\n"
}

hint5() {
  printf " 1 #!/bin/bash\n 2 \n 3 EXECUTABLE=\"\$1\"\n 4 shift\n 5 ARGUMENTS=\"\$@\"\n 6 \n 7 [ -z \"\$EXECUTABLES\" ] && exit 1\n 8 [ ! -x \"\$EXECUTABLES\" ] && exit 2\n 9 \n10 ............. ............\n11 ...............\n12 \n13 .... ........... ..\n14 .. ..\n15 .. .... ........ ...... ......... ..\n16 .. .... ........ ........... ......... ..\n17 .. .... ....... ........ .. ... .. ... ....... ..........\n18 .. .... ............ ........ .. ... .. ... ....... ..........\n19 .. .... ....... ........ .. ... . ..... .... ........\n20 .. .... ... ....... ........... .. . ...... ........\n21 .. .... ......... .... ...... ........\n22 .. .... ... ...... ..... ........... .. . ...... ........\n23 .. .... ......... .... ...... ........\n24 ... .... ............ ....... ........ ... .... .... .......\n25 ... .... ....... ...... ...... .......\n26 .. .... ........ ..... .......\n27 .... ...\n28 \n29 .... .\n"
}

hint6() {
  printf " 1 #!/bin/bash\n 2 \n 3 EXECUTABLE=\"\$1\"\n 4 shift\n 5 ARGUMENTS=\"\$@\"\n 6 \n 7 [ -z \"\$EXECUTABLES\" ] && exit 1\n 8 [ ! -x \"\$EXECUTABLES\" ] && exit 2\n 9 \n10 \"\$EXECUTABLE\" \"\$ARGUMENTS\"\n11 ERROR_CODE=\"\$?\"\n12 \n13 .... ........... ..\n14 .. ..\n15 .. .... ........ ...... ......... ..\n16 .. .... ........ ........... ......... ..\n17 .. .... ....... ........ .. ... .. ... ....... ..........\n18 .. .... ............ ........ .. ... .. ... ....... ..........\n19 .. .... ....... ........ .. ... . ..... .... ........\n20 .. .... ... ....... ........... .. . ...... ........\n21 .. .... ......... .... ...... ........\n22 .. .... ... ...... ..... ........... .. . ...... ........\n23 .. .... ......... .... ...... ........\n24 ... .... ............ ....... ........ ... .... .... .......\n25 ... .... ....... ...... ...... .......\n26 .. .... ........ ..... .......\n27 .... ...\n28 \n29 .... .\n"
}

hint7() {
  printf " 1 #!/bin/bash\n 2 \n 3 EXECUTABLE=\"\$1\"\n 4 shift\n 5 ARGUMENTS=\"\$@\"\n 6 \n 7 [ -z \"\$EXECUTABLES\" ] && exit 1\n 8 [ ! -x \"\$EXECUTABLES\" ] && exit 2\n 9 \n10 \"\$EXECUTABLE\" \"\$ARGUMENTS\"\n11 ERROR_CODE=\"\$?\"\n12 \n13 case \$ERROR_CODE in\n14 0) ;;\n15 1) echo \"Invalid source argument\" ;;\n16 2) echo \"Invalid destination argument\" ;;\n17 3) echo \"Source argument is not in the current project\";;\n18 4) echo \"Destination argument is not in the current project\";;\n19 5) echo \"Source filename is not a valid java file.\";;\n20 6) echo \"No package information in a source file.\";;\n21 7) echo \"External tool error: grep.\";;\n22 8) echo \"No public class information in a source file.\";;\n23 9) echo \"External tool error: grep.\";;\n24 10) echo \"Destination already contains sth with this name\";;\n25 11) echo \"Cannot remove source file\";;\n26 *) echo \"Unknown error code\";;\n27 esac >&2\n28 \n29 .... .\n"
}

hint8() {
  printf " 1 #!/bin/bash\n 2 \n 3 EXECUTABLE=\"\$1\"\n 4 shift\n 5 ARGUMENTS=\"\$@\"\n 6 \n 7 [ -z \"\$EXECUTABLES\" ] && exit 1\n 8 [ ! -x \"\$EXECUTABLES\" ] && exit 2\n 9 \n10 \"\$EXECUTABLE\" \"\$ARGUMENTS\"\n11 ERROR_CODE=\"\$?\"\n12 \n13 case \$ERROR_CODE in\n14 0) ;;\n15 1) echo \"Invalid source argument\" ;;\n16 2) echo \"Invalid destination argument\" ;;\n17 3) echo \"Source argument is not in the current project\";;\n18 4) echo \"Destination argument is not in the current project\";;\n19 5) echo \"Source filename is not a valid java file.\";;\n20 6) echo \"No package information in a source file.\";;\n21 7) echo \"External tool error: grep.\";;\n22 8) echo \"No public class information in a source file.\";;\n23 9) echo \"External tool error: grep.\";;\n24 10) echo \"Destination already contains sth with this name\";;\n25 11) echo \"Cannot remove source file\";;\n26 *) echo \"Unknown error code\";;\n27 esac >&2\n28 \n29 exit 0\n"
}

hint9() {
  printf "No to teraz wytłumaczę co tutaj się dzieje.\nWell, now I will explain what is going on here.\n"
}

hint10() {
  printf " 1 #!/bin/bash\n 2 \n 3 EXECUTABLE=\"\$1\"\n 4 shift\n 5 ARGUMENTS=\"\$@\"\n 6 \n 7 . .. .............. . .. .... .\n 8 . . .. .............. . .. .... .\n 9 \n10 ............. ............\n11 ...............\n12 \n13 .... ........... ..\n14 .. ..\n15 .. .... ........ ...... ......... ..\n16 .. .... ........ ........... ......... ..\n17 .. .... ....... ........ .. ... .. ... ....... ..........\n18 .. .... ............ ........ .. ... .. ... ....... ..........\n19 .. .... ....... ........ .. ... . ..... .... ........\n20 .. .... ... ....... ........... .. . ...... ........\n21 .. .... ......... .... ...... ........\n22 .. .... ... ...... ..... ........... .. . ...... ........\n23 .. .... ......... .... ...... ........\n24 ... .... ............ ....... ........ ... .... .... .......\n25 ... .... ....... ...... ...... .......\n26 .. .... ........ ..... .......\n27 .... ...\n28 \n29 .... .\n"
}

hint11() {
  printf "Początek bardzo podobny do poprzednich. W dwóch zmiennych EXECUTABLE i ARGUMENTS zapamiętujemy nazwę polecenia, które będziemy uruchamiać i jego argumenty.\nThe beginning is very similar to the previous ones. In the two variables EXECUTABLE and ARGUMENTS, we store the name of the command we will run and its arguments.\n"
}

hint12() {
  printf " 1 #!/bin/bash\n 2 \n 3 EXECUTABLE=\"\$1\"\n 4 shift\n 5 ARGUMENTS=\"\$@\"\n 6 \n 7 [ -z \"\$EXECUTABLES\" ] && exit 1\n 8 [ ! -x \"\$EXECUTABLES\" ] && exit 2\n 9 \n10 ............. ............\n11 ...............\n12 \n13 .... ........... ..\n14 .. ..\n15 .. .... ........ ...... ......... ..\n16 .. .... ........ ........... ......... ..\n17 .. .... ....... ........ .. ... .. ... ....... ..........\n18 .. .... ............ ........ .. ... .. ... ....... ..........\n19 .. .... ....... ........ .. ... . ..... .... ........\n20 .. .... ... ....... ........... .. . ...... ........\n21 .. .... ......... .... ...... ........\n22 .. .... ... ...... ..... ........... .. . ...... ........\n23 .. .... ......... .... ...... ........\n24 ... .... ............ ....... ........ ... .... .... .......\n25 ... .... ....... ...... ...... .......\n26 .. .... ........ ..... .......\n27 .... ...\n28 \n29 .... .\n"
}

hint13() {
  printf "Sprawdzamy, czy została nam przekazana nazwa polecenia do wykonania. Jeżeli tak to sprawdzamy czy mamy uprawnienia do uruchomienia tego polecenia.\nWe check if we have been passed the name of the command to execute. If so, we check if we have permissions to run this command.\n"
}

hint14() {
  printf " 1 #!/bin/bash\n 2 \n 3 EXECUTABLE=\"\$1\"\n 4 shift\n 5 ARGUMENTS=\"\$@\"\n 6 \n 7 [ -z \"\$EXECUTABLES\" ] && exit 1\n 8 [ ! -x \"\$EXECUTABLES\" ] && exit 2\n 9 \n10 \"\$EXECUTABLE\" \"\$ARGUMENTS\"\n11 ERROR_CODE=\"\$?\"\n12 \n13 .... ........... ..\n14 .. ..\n15 .. .... ........ ...... ......... ..\n16 .. .... ........ ........... ......... ..\n17 .. .... ....... ........ .. ... .. ... ....... ..........\n18 .. .... ............ ........ .. ... .. ... ....... ..........\n19 .. .... ....... ........ .. ... . ..... .... ........\n20 .. .... ... ....... ........... .. . ...... ........\n21 .. .... ......... .... ...... ........\n22 .. .... ... ...... ..... ........... .. . ...... ........\n23 .. .... ......... .... ...... ........\n24 ... .... ............ ....... ........ ... .... .... .......\n25 ... .... ....... ...... ...... .......\n26 .. .... ........ ..... .......\n27 .... ...\n28 \n29 .... .\n"
}

hint15() {
  printf "Wykonujemy przekazane polecenie z podanym argumentami i zapamiętujemy kod błędu.\nWe execute the passed command with the given arguments and remember the error code.\n"
}

hint16() {
  printf " 1 #!/bin/bash\n 2 \n 3 EXECUTABLE=\"\$1\"\n 4 shift\n 5 ARGUMENTS=\"\$@\"\n 6 \n 7 [ -z \"\$EXECUTABLES\" ] && exit 1\n 8 [ ! -x \"\$EXECUTABLES\" ] && exit 2\n 9 \n10 \"\$EXECUTABLE\" \"\$ARGUMENTS\"\n11 ERROR_CODE=\"\$?\"\n12 \n13 case \$ERROR_CODE in\n14 0) ;;\n15 1) echo \"Invalid source argument\" ;;\n16 2) echo \"Invalid destination argument\" ;;\n17 3) echo \"Source argument is not in the current project\";;\n18 4) echo \"Destination argument is not in the current project\";;\n19 5) echo \"Source filename is not a valid java file.\";;\n20 6) echo \"No package information in a source file.\";;\n21 7) echo \"External tool error: grep.\";;\n22 8) echo \"No public class information in a source file.\";;\n23 9) echo \"External tool error: grep.\";;\n24 10) echo \"Destination already contains sth with this name\";;\n25 11) echo \"Cannot remove source file\";;\n26 *) echo \"Unknown error code\";;\n27 esac >&2\n28 \n29 .... .\n"
}

hint17() {
  printf "Wreszcie dekodujemy kod błędu. Do tego celu wykorzystałem instrukcję case. Wygląda to dość prosto, dość łatwo się to analizuje, zmienia itd... Zwróć uwagę na koniec tej instrukcji >&2. Do czego to służy?\nFinally, we decode the error code. For this purpose, I used the case instruction. It looks quite simple, it is quite easy to analyze, change, etc.... Note the end of this instruction >&2. What is it used for?\n"
}

hint18() {
  printf " 1 #!/bin/bash\n 2 \n 3 EXECUTABLE=\"\$1\"\n 4 shift\n 5 ARGUMENTS=\"\$@\"\n 6 \n 7 [ -z \"\$EXECUTABLES\" ] && exit 1\n 8 [ ! -x \"\$EXECUTABLES\" ] && exit 2\n 9 \n10 \"\$EXECUTABLE\" \"\$ARGUMENTS\"\n11 ERROR_CODE=\"\$?\"\n12 \n13 case \$ERROR_CODE in\n14 0) ;;\n15 1) echo \"Invalid source argument\" ;;\n16 2) echo \"Invalid destination argument\" ;;\n17 3) echo \"Source argument is not in the current project\";;\n18 4) echo \"Destination argument is not in the current project\";;\n19 5) echo \"Source filename is not a valid java file.\";;\n20 6) echo \"No package information in a source file.\";;\n21 7) echo \"External tool error: grep.\";;\n22 8) echo \"No public class information in a source file.\";;\n23 9) echo \"External tool error: grep.\";;\n24 10) echo \"Destination already contains sth with this name\";;\n25 11) echo \"Cannot remove source file\";;\n26 *) echo \"Unknown error code\";;\n27 esac >&2\n28 \n29 exit 0\n"
}

hint19() {
  printf "No i mamy rozwiązanie.\nWell, and we have a solution.\n"
}

solution() {
  printf " 1 #!/bin/bash\n 2 \n 3 EXECUTABLE=\"\$1\"\n 4 shift\n 5 ARGUMENTS=\"\$@\"\n 6 \n 7 [ -z \"\$EXECUTABLES\" ] && exit 1\n 8 [ ! -x \"\$EXECUTABLES\" ] && exit 2\n 9 \n10 \"\$EXECUTABLE\" \"\$ARGUMENTS\"\n11 ERROR_CODE=\"\$?\"\n12 \n13 case \$ERROR_CODE in\n14 0) ;;\n15 1) echo \"Invalid source argument\" ;;\n16 2) echo \"Invalid destination argument\" ;;\n17 3) echo \"Source argument is not in the current project\";;\n18 4) echo \"Destination argument is not in the current project\";;\n19 5) echo \"Source filename is not a valid java file.\";;\n20 6) echo \"No package information in a source file.\";;\n21 7) echo \"External tool error: grep.\";;\n22 8) echo \"No public class information in a source file.\";;\n23 9) echo \"External tool error: grep.\";;\n24 10) echo \"Destination already contains sth with this name\";;\n25 11) echo \"Cannot remove source file\";;\n26 *) echo \"Unknown error code\";;\n27 esac >&2\n28 \n29 exit 0\n"
}



homework1() {
  printf "Praca domowa #3009_1: Zaproponuj własne rozwiązanie do obsługi kilku języków. W zależności od ustawień komunikat może być wyświetlony po angielsku, polsku, hiszpańsku itd...\nHomework #3009_1: Propose your own solution to support several languages. Depending on the settings, the message can be displayed in English, Polish, Spanish, etc....\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'solution' 'homework1' 

exit 0