#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 2 | 0 | 0 | 5 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Znajdz wszystkie pliki z rozszerzeniem java i txt w swoim katalogu domowym wraz z podkatalogami i policz ile każdy z nich ma linii."
  echo 
  echo "Find all files with the java and txt extensions in your home directory along with subdirectories and count how many lines each has."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Wiemy już z poprzednich zajęć jak wyznaczyć liczbę linii w pliku:\nWe already know from previous classes how to determine the number of lines in a file:\n"
}

hint2() {
  printf "wc -l file\n"
}

hint3() {
  printf "... lub w plikach: \n... or in files:\n"
}

hint4() {
  printf "wc -l file1 file2 *.txt\n"
}

hint5() {
  printf "Ale jak ogólnie rozwiązać ten problem w różnych katalogach i podkatalogach.\nBut how to generally solve this problem in different directories and subdirectories\n"
}

hint6() {
  printf "Potrzebujemy bardzo silnego polecenia, które znajdzie nam konkretne pliki i zwróci ich dokładną lokalizację.\nWe need a very strong command that finds us specific files and returns their exact location.\n"
}

hint7() {
  printf "Tym niezbędnym poleceniem jest polecenie 'find'.\nThis essential command is the 'find' command.\n"
}

hint8() {
  printf "Uwaga polecenia 'find' nie należy utożsamiać z poleceniem ls -R, chociaż na pierwszy rzut oka oba te polecenia robią podobne rzeczy.\nNote the 'find' command should not be equated with the ls -R command, although at first glance the two commands do similar things.\n"
}

hint9() {
  printf "Znajdźmy wszystkie pliki tekstowe w naszym katalogu domowym.\nLet's find all the text files in our home directory.\n"
}

hint10() {
  printf "find ~ -name \"*.txt\"\n"
}

hint11() {
  printf "Można łatwo dostosować to polecenie do naszych potrzeb.\nWe can easily adapt this command to our needs.\n"
}

hint12() {
  printf "find ~ / -name '*.java'\n"
}

hint13() {
  printf "... lub tak ...\n... or so ...\n"
}

hint14() {
  printf "find ~ / -regextype posix-egrep -regex '.*txt\$|.*java'\n"
}

hint15() {
  printf "Możliwości w tym zakresie polecenie 'find' ma dość dużo, ale nas interesuje inna opcja tego polecenia.\nThe 'find' command has quite a lot of possibilities in this regard, but we are interested in another option of this command.\n"
}

hint16() {
  printf "Zapamiętajmy wynik działania polecenia 'find' w zmiennej.\nLet's store the result of the 'find' command in a variable.\n"
}

hint17() {
  printf "RESULTS=\$(find ~ / -regextype posix-egrep -regex '.*txt\$|.*java')\n"
}

hint18() {
  printf "Teraz zmienna RESULT zawiera listę plików znalezionych przez polecenie 'find', na których możemy wykonać, prawie dowolną operację:\nNow the RESULT variable contains a list of files found by the 'find' command on which we can perform, almost any operation:\n"
}

hint19() {
  printf "echo \$RESULT\n"
}

hint20() {
  printf "... lub ...\n... or ...\n"
}

hint21() {
  printf "cat \$RESULT\n"
}

hint22() {
  printf "... lub ...\n... or ...\n"
}

hint23() {
  printf "tail -n 1 \$RESULT\n"
}

hint24() {
  printf "... lub ...\n... or ...\n"
}

hint25() {
  printf "wc -l \$RESULT\n"
}

hint26() {
  printf "... lub ...\n... or ...\n"
}

hint27() {
  printf "wc -l \$(find ~ -regextype posix-egrep -regex '.*txt\$|.*java')\n"
}

hint28() {
  printf "... lub nawet ...\n... or even ...\n"
}

hint29() {
  printf "rm \"\$RESULT\"\n"
}

hint30() {
  printf "Dlaczego nazwy zmiennych bierzemy w cudzysłów?\nWhy do we put the names of variables in quotation marks?\n"
}

hint31() {
  printf "rm \"\$RESULT\"\nrm \$RESULT\n"
}

hint32() {
  printf "Przy takim rozwiązaniu problemem może być zbyt duża liczba (długość) argumentów. Jeżeli linia z argumentami będzie zbyt długa, polecenie zakończy sie błędem.\nWith such a solution, the problem may be too many (length) arguments. If the line a aguments is too long, the command will end with an error.\n"
}

hint33() {
  printf "Innym problemem przy takim podejściu są białe znaki, ale o tym więcej na wykładzie.\nAnother problem with this approach is whitespace characters, but more about that in the lecture.\n"
}

hint34() {
  printf "Aby to roziązać wykorzystajmy opcję ... exec ..., która daje nam możliwość wywołania dowolnego polecenia dla znalezionych przez polecenie find argumentów.\nTo solve this, let's use the option ... exec ..., which gives us the ability to call any command for the arguments found by the find command.\n"
}

hint35() {
  printf "Spróbujmy...\nLet's try...\n"
}

hint36() {
  printf "find ~ -regextype posix-egrep -regex '.*txt\$|.*java' -exec wc -l {} ';'\n"
}

hint37() {
  printf "Gotowe, po opcji exec wpisujemy polecenie, które będzie wykonane, opcje tego polecenia i nazwę pliku dla którego to polecenie będzie wykonane. Ta nazwa pliku zostanie przez polecenie find wstawiona w miejsce {}. Każde takie polecenie kończymy średnikiem.\nDone, after the exec option we type the command that will be executed, the options of this command and the name of the file for which this command will be executed. The file name will be inserted by the 'find' command in place of {}. We end each such command with a semicolon.\n"
}

hint38() {
  printf "find ~ -regextype posix-egrep -regex '.*txt\$|.*java' -exec wc -l {} \;\n"
}

hint39() {
  printf "Mamy więc kilka rozwiązań tago problemu. Dobrze jest je znać.\nSo we have several solutions to this problem. It is good to know them.\n"
}

solution() {
  printf "RESULTS=\$(find ~ / -regextype posix-egrep -regex '.*txt\$|.*java')\nwc -l \$RESULT\nwc -l \$(find ~ -regextype posix-egrep -regex '.*txt\$|.*java')\nfind ~ -regextype posix-egrep -regex '.*txt\$|.*java' -exec wc -l {} ';'\nfind ~ -regextype posix-egrep -regex '.*txt\$|.*java' -exec wc -l {} \;\n"
}



homework1() {
  printf "Praca domowa 2005_1: Obsłuż pliki, których nazwa zaczyna się na litery A, B lub C. Resztę plików pomiń.\nHomework 2005_1: Handle files whose name begins with the letters A, B or C. Skip the rest of the files.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'hint30' 'hint31' 'hint32' 'hint33' 'hint34' 'hint35' 'hint36' 'hint37' 'hint38' 'hint39' 'solution' 'homework1' 

exit 0