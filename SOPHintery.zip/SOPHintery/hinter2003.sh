#!/bin/bash

start() {
  echo '    _   _   _'
  echo '   / \ / \ / \'
  echo '  ( S | O | P )'
  echo '   \_/ \_/ \_/  _     _   _   _   _     _   _   _   _'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( B | A | S | H ) ( T | a | s | k ) ( 2 | 0 | 0 | 3 )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo '   / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( A | d | a | m ) ( S | m | y | k )'
  echo '   \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/      _   _   _   _'
  echo '   / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \'
  echo '  ( C | o | p | y | r | i | g | h | t ) ( 2 | 0 | 2 | 4 )'
  echo '   \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/'
  echo ''
  echo '[Q - quit] [<> Prev Next hint] [ Up Down Scroll hint]'
}

content() {
  echo "--------------------------"
  echo 
  echo "Napisz wyrażenie, które wyliczy ilość sekund od daty 1970-01-01 do początku dnia dzisiejszego. Załóżmy dla ułatwienia, że każdy miesiąc ma 30 dni."
  echo 
  echo "Write an expression that calculates the number of seconds from the date 1970-01-01 to the beginning of today. Assume for simplicity that each month has 30 days."
  echo "--------------------------"
}

my_clear() {
  clear
}


hint1() {
  printf "Po pierwsze musimy nauczyć się dodawać i mnożyć w BASHU\nFirst, we need to learn how to add and multiply in BASH.\n"
}

hint2() {
  printf "Do rozwiązania tego zadania wykorzystamy instrukcją let i zmienne\nWe are going to use let instructions and variables to solve this task.\n"
}

hint3() {
  printf "Aby dodać dwie liczby i wynik zapisać w zmiennej W wykonamy let W=10+5\nTo add two numbers and store the result in the variable W we will perform let W=10+5\n"
}

hint4() {
  printf "let W=10+20\n"
}

hint5() {
  printf "Aby wyznaczyć liczbę sekund w jednym dniu wystarczy let S=3600*24\nTo determine the number of seconds in one day just let S=3600*24\n"
}

hint6() {
  printf "Teraz musimy uzyskać aktualną datę\nNow we need to get the current date\n"
}

hint7() {
  printf "date\n"
}

hint8() {
  printf "A teraz wyciągnąć z daty rok, miesiąc i dzień. Sprawdż w manualu jak to zrobić.\nAnd now extract the year, month and day from the date. Check the manual on how to do this.\n"
}

hint9() {
  printf "date .....\n"
}

hint10() {
  printf "date '...'\n"
}

hint11() {
  printf "date '.%%.'\n"
}

hint12() {
  printf "date '+%%.'\ndate '+%%Y'\ndate '+%%m'\ndate '+%%d'\n"
}

hint13() {
  printf "Teraz zapiszmy informacje o roku, miesiącu i dniu do zmiennych - użyjmy \"'\$()'\" lub \"'``'\".\nNow let's save the year, month and day information to variables - use \"'\$()'\" or \"'``'\".\n"
}

hint14() {
  printf "YEAR=\$(date '+%%Y')\n"
}

hint15() {
  printf "MONTH=\$(date '+%%m')\n"
}

hint16() {
  printf "DAY=\$(date '+%%d')\n"
}

hint17() {
  printf "Wyznaczmy liczbę sekund w dniach od początku miesiąca.\nLet's calculate the number of seconds in days since the beginning of the month.\n"
}

hint18() {
  printf "let DAY_S=(DAY-1)*3600*24\n"
}

hint19() {
  printf "let DAY_S1970=0\n"
}

hint20() {
  printf "Wyznaczmy liczbę sekund w miesiacach od początku roku.\nLet's calculate the number of seconds in months since the beginning of the year.\n"
}

hint21() {
  printf "let MONTH_S=(M-1)*3600*24*30\n"
}

hint22() {
  printf "let MONTH_S1970=0\n"
}

hint23() {
  printf "Wyznaczmy liczbę sekund w latach do bieżącego roku.\nLet's calculate the number of seconds in years to the current year.\n"
}

hint24() {
  printf "let YEAR_S=(YEAR)*3600*24*30*12\n"
}

hint25() {
  printf "let YEAR_S1970=1970*3600*24*30*12\n"
}

hint26() {
  printf "let RESULT=DAY_S+MONTH_S+YEAR_S\n"
}

hint27() {
  printf "let RESULT1970=DAY_S1970+MONTH_S1970+YEAR_S1970\n"
}

hint28() {
  printf "let RESULT=RESULT-RESULT1970\n"
}

hint29() {
  printf "echo \"Liczba sekund od początku epoki do początku dnia dzisiejszego to \$RESULT\"\necho \"The number of seconds from the beginning of the epoch to the beginning of today is \$RESULT\"\n"
}

solution() {
  printf "YEAR=\$(date '+%%Y')\nMONTH=\$(date '+%%m')\nDAY=\$(date '+%%d')\nlet DAY_S=(DAY-1)*3600*24\nlet DAY_S1970=0\nlet MONTH_S=(M-1)*3600*24*30\nlet MONTH_S1970=0\nlet YEAR_S=(YEAR)*3600*24*30*12\nlet YEAR_S1970=1970*3600*24*30*12\nlet RESULT=DAY_S+MONTH_S+YEAR_S\nlet RESULT=RESULT-RESULT1970\necho \"Liczba sekund od początku epoki do początku dnia dzisiejszego to \$RESULT\"\necho \"The number of seconds from the beginning of the epoch to the beginning of today is \$RESULT\"\n"
}



homework1() {
  printf "Praca domowa #2003: Przedstaw ciąg operacji, wyznaczający liczbę sekund między aktualna godziną, a godziną o której rozpocząłeś dzisiaj pracę.\nHomework #2003: Present a sequence of operations, determining the number of seconds between the current time and the time at which you started work today.\n"
}

menu() {
  SELECTED_ITEM=0
  FROM=1
  HEIGHT=30
  STEP=1
  MENU_ITEMS=($@)
  HINTS=${#MENU_ITEMS[@]}
  let HINTS=HINTS-2

  clear
  echo "${MENU_ITEMS[$SELECTED_ITEM]}"
  ${MENU_ITEMS[$SELECTED_ITEM]} $((FROM+HEIGHT)) $HEIGHT

  while read -rsn1 INPUT ; do
    #clear
    case "$INPUT" in
      $'\x1B')
	      read -rsn1 -t 0.1 INPUT
	      if [ "$INPUT" = "[" ] ;then
	        read -rsn1 -t 0.1 INPUT
	      #  echo $INPUT
	        REFRESH=0
	        case "$INPUT" in
		        A) let FROM-=STEP; REFRESH=1 ;; #UP
		        B) let FROM+=STEP; REFRESH=1 ;; #DOWN
		        5) let FROM-=HEIGHT; REFRESH=1 ;; #PAGEUP
		        6) let FROM+=HEIGHT; REFRESH=1 ;; #PAGEDOWN
		        C) let SELECTED_ITEM++ ; let FROM=0; REFRESH=1 ;; #RIGHT
		        D) let SELECTED_ITEM-- ; let FROM=0; REFRESH=1 ;; #LEFT
		        Q) exit 0; ;;
      	  esac
	        if [ $SELECTED_ITEM -lt 0 ] ; then
	          let  SELECTED_ITEM=0
	        fi
	        if [ $SELECTED_ITEM -ge ${#MENU_ITEMS[@]} ] ; then
	          let SELECTED_ITEM=${#MENU_ITEMS[@]}-1
	        fi
	        if [ $FROM -lt 0 ] ; then
	          let FROM=0
	        fi
	        SIZE_Y=$(${MENU_ITEMS[$SELECTED_ITEM]} | wc  -l)
	        if [ $((FROM+HEIGHT)) -gt $SIZE_Y ] ; then
	          let FROM=SIZE_Y-HEIGHT
   	      fi
   	      if [ "$REFRESH" = '0' ] ; then
   	        continue
   	      else
   	        clear
   	      fi
	       # echo -n "$((FROM+HEIGHT))  $SIZE_Y  "
	        if [[  "${MENU_ITEMS[$SELECTED_ITEM]}" =~ ^hint ]] ; then
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}/$HINTS"
	        else
	          echo "${MENU_ITEMS[$SELECTED_ITEM]}"
	        fi
	        ${MENU_ITEMS[$SELECTED_ITEM]} |  head -n $((FROM+HEIGHT)) | tail -n $HEIGHT
        fi
	      read -rsn5 -t 0.1 ;;
	   q) break ;;
	   *) echo -n ;;
    esac
  done
}

menu 'start' 'content' 'hint1' 'hint2' 'hint3' 'hint4' 'hint5' 'hint6' 'hint7' 'hint8' 'hint9' 'hint10' 'hint11' 'hint12' 'hint13' 'hint14' 'hint15' 'hint16' 'hint17' 'hint18' 'hint19' 'hint20' 'hint21' 'hint22' 'hint23' 'hint24' 'hint25' 'hint26' 'hint27' 'hint28' 'hint29' 'solution' 'homework1' 

exit 0